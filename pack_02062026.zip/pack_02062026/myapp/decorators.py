import os,json
from django.http import HttpResponseForbidden
from django.contrib.auth import get_user_model
from functools import wraps

User = get_user_model()
UNAUTHORIZED_MSG = "You are not authorised. Pl contact Product costing team"
ALLOWED_LEVELS = {"edit", "review", "admin"}
ADMIN_ALLOWED_LEVELS = {"admin"}

def normalize_access_levels(access_level_value):
    """
    Handles these cases:
      - ["Edit", "Review"]           (list)
      - "admin"                     (string)
      - "Edit,Review,admin"         (comma-separated string)
      - '["Edit","Review"]'         (JSON string)
    Returns: set of lowercase strings
    """
    if not access_level_value:
        return set()

    if isinstance(access_level_value, (list, tuple, set)):
        items = access_level_value

    elif isinstance(access_level_value, str):
        s = access_level_value.strip()

        if (s.startswith("[") and s.endswith("]")) or (s.startswith('"') and s.endswith('"')):
            try:
                parsed = json.loads(s)
                if isinstance(parsed, list):
                    items = parsed
                else:
                    items = [parsed]
            except json.JSONDecodeError:
                items = [x for x in s.split(",") if x.strip()]
        else:
            items = [x for x in s.split(",") if x.strip()]

    else:
        items = [access_level_value]

    return {str(x).strip().strip(",").lower() for x in items if str(x).strip()}



def system_user_required_home(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        system_user = (os.environ.get("USERNAME") or "").strip().lower()
        if not system_user:
            return HttpResponseForbidden(UNAUTHORIZED_MSG)

        user = User.objects.filter(username__iexact=system_user).first()
        if not user:
            return HttpResponseForbidden(UNAUTHORIZED_MSG)

        print('system_user',system_user)

        return view_func(request, *args, **kwargs)

    return _wrapped

def system_user_required_mycsc(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):

        system_user = (os.environ.get("USERNAME") or "").strip().lower()
        user = User.objects.filter(username__iexact=system_user).first()

        levels_normalized = normalize_access_levels(user.access_level)

        # Debug (temporary)
        # print("RAW:", repr(user.access_level), "TYPE:", type(user.access_level))
        # print("NORMALIZED:", levels_normalized)

        if levels_normalized.isdisjoint(ALLOWED_LEVELS):
            return HttpResponseForbidden(UNAUTHORIZED_MSG)

        return view_func(request, *args, **kwargs)

    return _wrapped

def system_user_required_admin(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):

        system_user = (os.environ.get("USERNAME") or "").strip().lower()
        user = User.objects.filter(username__iexact=system_user).first()

        levels_normalized = normalize_access_levels(user.access_level)

        if levels_normalized.isdisjoint(ADMIN_ALLOWED_LEVELS):
            return HttpResponseForbidden(UNAUTHORIZED_MSG)

        return view_func(request, *args, **kwargs)

    return _wrapped

