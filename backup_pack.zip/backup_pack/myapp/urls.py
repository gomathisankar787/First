from django.contrib import admin
from django.urls import include, path

from myapp import views

urlpatterns = [
    path('home',views.home,name="home"),
    path('createcsc',views.createcsc,name="createcsc"),
    path('updatecsc',views.updatecsc,name="updatecsc"),
    path('mycsc',views.mycsc,name="mycsc"),
    path('deletecsc',views.deletecsc,name="deletecsc"),
    path('bom',views.bom,name="bom"),
    path('updatebom',views.updatebom,name="updatebom"),
    path('sm_material',views.sm_material,name="sm_material"),
    path('rm_base',views.rm_base,name="rm_base"),
    path('oh_profit',views.oh_profit,name="oh_profit"),
    path('process_base',views.process_base,name="process_base"),
    path('ratio_chart',views.ratio_chart,name='ratio_chart'),
    path('bomsumry',views.bomsumry,name="bomsumry"),
    path('admin',views.admin,name="admin"),
    path('viewcsc/<int:id>/',views.viewcsc,name='viewcsc'),
    path('sm_process',views.sm_process,name='sm_process'),
    path('download_oh_profit_template/', views.download_oh_profit_csv_template, name='download_oh_profit_template'),
    path('get_process_types/', views.get_process_types, name='get_process_types'),
    path('download_process_base_csv_template/', views.download_process_base_csv_template, name='download_process_base_csv_template'),
    path('get_pbase_process_types/', views.get_pbase_process_types, name='get_pbase_process_types'),
    path('download_rm_base_csv_template/', views.download_rm_base_csv_template, name='download_rm_base_template'),
    path('get_rm_process_types/', views.get_rm_process_types, name='get_rm_process_types'),
    path('add_project/', views.add_project, name='add_project'),
    path('add_parttype/', views.add_parttype, name='add_parttype'),
    path('ajax/material_rates/', views.get_material_rates, name='material_rates'),
    path('ajax/machine_norms/', views.get_process_norms, name='machine_norms'),
    path('ajax/sm_material/<int:id>/', views.showbomSmMaterial, name='sm_material_by_id'),
    path('bom_details/<int:id>/', views.bomdetails, name='bom_details')
]