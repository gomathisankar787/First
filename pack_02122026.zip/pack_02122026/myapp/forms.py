from django import forms
from .models import OH_ProfitData,PARTTYPETBL,PROJECTLISTTBL
 
class OHOtherProfitForm(forms.ModelForm):
    class Meta:
        model = OH_ProfitData 
        fields = '__all__'

class ParttypeForm(forms.Form):
    parttype = forms.ModelChoiceField(queryset=PARTTYPETBL.objects.all(), label="Part type", empty_label="Select Part Type")

class ProjectForm(forms.Form):
    project = forms.ModelChoiceField(queryset=PROJECTLISTTBL.objects.all(), label="Projects")