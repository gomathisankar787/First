import os
import csv
from django.http import HttpResponse, JsonResponse

def create_csv_template(columns, filename):
    # Create a CSV file with the specified columns
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(columns)

def download_csv_template(request, columns, filename):
    create_csv_template(columns, filename)
    if os.path.exists(filename):
        with open(filename, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type="application/vnd.ms-excel")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(filename)
            return response
    return JsonResponse({'error': 'File not found.'}, status=404)

def get_process_types(model):
    process_types = model.objects.values_list('process_type', flat=True).distinct()
    return JsonResponse(list(process_types), safe=False)