from django.contrib import admin
from .models import *

# Register your models here.

# Register the CREATECSC model to make it manageable via the admin interface
# admin.site.register(CREATE_CSCTBL)
admin.site.register(BOMSheet)
admin.site.register(OH_ProfitData)