# Install required libraries:
# pip install django plotly dash django-plotly-dash pandas
 
import os
from django.conf import settings
from django.http import HttpResponse
from django.urls import path
from django.core.management import execute_from_command_line
from django.shortcuts import render
from django_plotly_dash import DjangoDash
from dash import dcc, html
import plotly.graph_objects as go
 
# Django settings
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
 
settings.configure(
    DEBUG=True,
    SECRET_KEY='django-insecure-key',
    ROOT_URLCONF=__name__,
    ALLOWED_HOSTS=['*'],
    MIDDLEWARE=[
        'django.middleware.common.CommonMiddleware',
    ],
    INSTALLED_APPS=[
        'django.contrib.staticfiles',
        'django_plotly_dash.apps.DjangoPlotlyDashConfig',
        'dpd_static_support',
    ],
    STATIC_URL='/static/',
)
 
# Django view
def index(request):
    return render(request, 'index.html')
 
# Plotly Dash app
app = DjangoDash('CostBreakdown')  # Create a Dash app
 
# Data for the chart
x_labels = [
    'Direct RM Cost', 'Allowance Cost', 'BOF Cost', 'Total RM Cost',
    'Process Cost', 'OH & Others', 'Profit', 'Total Basic Cost',
    'Amortization', 'Packing and Transport', 'Total Cost'
]
y_values = [337.38, 84.43, 0, 421.81, 75.47, 22.92, 29.84, 550.04, 0, 0, 550.04]
 
# Define the layout and chart
app.layout = html.Div([
    html.H1("Cost Breakdown Waterfall Chart", style={'textAlign': 'center'}),
    dcc.Graph(
        id='waterfall-chart',
        figure=go.Figure(
            data=[
                go.Waterfall(
                    name="Cost Breakdown",
                    orientation="v",
                    measure=[
                        "relative", "relative", "relative", "absolute",
                        "relative", "relative", "relative", "absolute",
                        "relative", "relative", "absolute"
                    ],
                    x=x_labels,
                    y=y_values,
                    text=[str(val) for val in y_values],
                    textposition="outside",
                    connector=dict(line=dict(color="gray")),
                )
            ],
            layout=go.Layout(
                title="Cost Breakdown Waterfall Chart",
                xaxis_title="Cost Heads",
                yaxis_title="Cost Amount",
                plot_bgcolor="white",
                font=dict(size=12)
            )
        )
    )
])
 
# Django URL configuration
urlpatterns = [
    path('', index, name='index'),
]
 
# Django HTML Template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cost Breakdown</title>
</head>
<body>
    <h1 style="text-align: center;">Django Dash Integration</h1>
    <div>
        {% load plotly_dash %}
        {% plotly_app name="CostBreakdown" %}
    </div>
</body>
</html>
"""
 
# Write the template to the filesystem
os.makedirs(os.path.join(BASE_DIR, 'templates'), exist_ok=True)
with open(os.path.join(BASE_DIR, 'templates/index.html'), 'w') as f:
    f.write(HTML_TEMPLATE)
 
# Run the Django server
if __name__ == "__main__":
    execute_from_command_line(['manage.py', 'runserver'])


