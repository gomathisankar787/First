import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'csc_project.settings')
django.setup()

from myapp.models import PROJECTLISTTBL

project_names = [
    "Falcon 11M & 12M", "Air Suspension on AVTR_Stage1", "Boss 11T_12T CSC", "320HP SCR on AVTR",
    "Ecomet Features", "Oyster EATS ECU type ACU", "Falcon EATS ECU type ACU", "H4 160 HP_ICV Trucks",
    "OYSTER E4 LWB LHD", "MEP 1915 32ft", "280HP SCR on AVTR", "Ecomet 1915 32ft", "AC introduction in Trucks",
    "Oyster E6 UAE and ukraine", "Sunshine ESC project", "Boss 915 IO", "IRT Tender - Cheetah, Viking & 12M",
    "360HP SCR on AVTR", "1922 32ft LNG dual tank", "Oyster lite Diesel", "Oyster lite CNG",
    "Viking CNG NA WEV-WEV", "Captain 2823 Haulage West Africa", "AVTR CNG 2822", "1916 G45 FES",
    "11M Falcon E5 SASO", "H6 TC CNG-222 viking BS6", "H64V 12 mtr", "A6 320HP EGR", "Air Suspension on AVTR",
    "Lynx smart Lite", "Ecomet new feature", "15M FEMAC", "AMT in TNSTC and KSRTC", "12m and 13.5 mtr H64V",
    "1925 Tipper", "4825 HD", "Ecomet 1615 Tipper", "Ecomet 11T NA CNG_V1", "2820 FE Improvement",
    "2820 SES", "AVTR Features1", "G45 6X2 SES", "4x2 TT ESC", "6x2 DTLA ESC", "Lynx truck", "Garuda",
    "Boss 1115 LEH", "ULE IRT Stage 2", "Oyster E5 SASO", "Boss 1215", "Boss 1115", "12m Falcon E5 SASO",
    "MBP CNG", "Ecomet 1815/1915 CNG", "Bus body Lynx smart wide", "Lynx smart H4 NA", "Boss 16-18T",
    "E+2 NA CNG", "ESC on Bus", "Ecomet 1915 POL", "G45 2820", "Ecomet 1015", "Partner I/O", "Falcon IO",
    "Oyster IO", "AVTR Features", "ULE", "H64V 13.5 mtr", "4825 DTLA OL", "E+2 Diesel", "Lynx strong 5639 CNG TC",
    "13.5m Air - Air", "G45 1920", "Cargo RMC", "Cheetah CNG", "ED PTO", "11T NA", "13.5M Bus", "ESC On Trucks",
    "H64V AC", "AMT", "Partner","Others"
]

for projects_name in project_names:
    PROJECTLISTTBL.objects.get_or_create(projects_name=projects_name)

print("Project names have been successfully added to the database.")