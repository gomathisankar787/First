import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./csc.css";

interface CscItem {
  partName: string;
  partRev: string;
  desc: string;
  type: string;
  estimatedOn: string;
  estimatedBy: string;
  cscId: string;
  status: string;
}

const Csc: React.FC = () => {
  const data: CscItem[] = Array.from({ length: 23 }, (_, i) => ({
    partName: `F4J0371${i}`,
    partRev: "#",
    desc: "BRACKET-AIR TANK - 276 mm Dia",
    type: "Sheetmetal",
    estimatedOn: "Dec-25",
    estimatedBy: "parthiban.c1",
    cscId: `F4J0371${i}-#-1-Jan-26`,
    status: "In-progress",
  }));

  const [showModal, setShowModal] = useState(false);

  const closeModal = () => setShowModal(false);
  const openModal = () => setShowModal(true);
  const navigate = useNavigate();

  const itemsPerPage = 20;
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(data.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentData = data.slice(startIndex, startIndex + itemsPerPage);
  const getPageNumbers = () => {
  const pages: (number | string)[] = [];

  if (totalPages <= 5) {
    for (let i = 1; i <= totalPages; i++) pages.push(i);
  } else {
    if (currentPage <= 3) {
      pages.push(1, 2, 3, "...", totalPages);
    } else if (currentPage >= totalPages - 2) {
      pages.push(1, "...", totalPages - 2, totalPages - 1, totalPages);
    } else {
      pages.push(
        1,
        "...",
        currentPage - 1,
        currentPage,
        currentPage + 1,
        "...",
        totalPages
      );
    }
  }
  return pages;
  };
  return (
    <div className="csc-page">
      <div className="csc-card">
        <div className="csc-header">
          <h1>CSC List</h1>
          <button className="btn btn-primary" onClick={openModal}>
            Create New CSC
          </button>
        </div>

        <div className="csc-table-wrapper">
          <table className="csc-table">
            <thead>
              <tr>
                <th>Part Name</th>
                <th>Rev</th>
                <th>Description</th>
                <th>Type</th>
                <th>Estimated On</th>
                <th>Estimated By</th>
                <th>CSC ID</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {currentData.map((item, index) => (
                <tr key={index}>
                  <td>{item.partName}</td>
                  <td>{item.partRev}</td>
                  <td>{item.desc}</td>
                  <td>{item.type}</td>
                  <td>{item.estimatedOn}</td>
                  <td>{item.estimatedBy}</td>
                  <td>{item.cscId}</td>
                  <td>
                    <span className="status in-progress">
                      {item.status}
                    </span>
                  </td>
                  <td className="action-cell">
                    {/* View */}
                    <button
                      className="action-btn action-view"
                      data-tooltip="Bom" onClick={() => navigate(`/bom/${item.cscId}`)}>
                      {/* onClick={() => console.log("View", item.cscId)} */}
                      <svg viewBox="0 0 24 24" fill="none">
                        <path
                          d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"
                          stroke="currentColor"
                          strokeWidth="2"
                        />
                        <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="2" />
                      </svg>
                    </button>

                    {/* Edit */}
                    <button
                      className="action-btn action-edit"
                      data-tooltip="Edit"
                      onClick={() => console.log("Edit", item.cscId)}>
                      <svg viewBox="0 0 24 24" fill="none">
                        <path
                          d="M4 20h4l10-10-4-4L4 16v4z"
                          stroke="currentColor"
                          strokeWidth="2"
                        />
                      </svg>
                    </button>

                    {/* Delete */}
                    <button
                      className="action-btn action-delete"
                      data-tooltip="Delete"
                      onClick={() => console.log("Delete", item.cscId)}>
                      <svg viewBox="0 0 24 24" fill="none">
                        <path
                          d="M3 6h18M8 6v12m8-12v12M5 6l1 14h12l1-14"
                          stroke="currentColor"
                          strokeWidth="2"
                        />
                      </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="pagination-bar">
          <span>
            Showing {startIndex + 1}–
            {Math.min(startIndex + itemsPerPage, data.length)} of {data.length}
          </span>

          <div className="pagination">
            <button
              className="page-btn"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Prev
            </button>

            {getPageNumbers().map((page, index) =>
              page === "..." ? (
                <span key={index} className="page-dots">…</span>
              ) : (
                <button
                  key={index}
                  className={`page-btn ${
                    currentPage === page ? "active" : ""
                  }`}
                  onClick={() => setCurrentPage(page as number)}
                >
                  {page}
                </button>
              )
            )}

            <button
              className="page-btn"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* create csc modal */}

      {showModal && (
        <div className="modal-backdrop">
          <div className="modal-container">
            {/* Header */}
            <div className="modal-header">
              <h2>Create CSC</h2>
              <button className="modal-close" onClick={closeModal}>×</button>
            </div>

            {/* Body */}
            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group">
                  <label>Part Number</label>
                  <input type="text" />
                </div>

                <div className="form-group">
                  <label>Revision</label>
                  <input type="text" />
                </div>

                <div className="form-group full">
                  <label>Description</label>
                  <textarea rows={3}></textarea>
                </div>

                <div className="form-group">
                  <label>Part Type</label>
                  <select>
                    <option>Select</option>
                    <option>Sheetmetal</option>
                    <option>Machining</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Project</label>
                  <select>
                    <option>Select</option>
                    <option>Project A</option>
                    <option>Project B</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>RM Base Date</label>
                  <select>
                    <option>Select</option>
                    <option>Dec 2024</option>
                    <option>Dec 2025</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Process Base Date</label>
                  <select>
                    <option>Select</option>
                    <option>Dec 2024</option>
                    <option>Dec 2025</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>OH / Profit / Other Cost Base</label>
                  <select>
                    <option>Select</option>
                    <option>Dec 2024</option>
                    <option>Dec 2025</option>
                  </select>
                </div>

                <div className="form-group full">
                  <label>Remarks</label>
                  <textarea rows={2}></textarea>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={closeModal}>
                Cancel
              </button>
              <button className="btn btn-primary">
                Save CSC
              </button>
            </div>

          </div>
        </div>
      )}
    </div>

  );
};

export default Csc;