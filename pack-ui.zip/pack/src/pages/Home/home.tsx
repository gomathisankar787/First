
import React from 'react';
import image from '../../assets/new_bg.jpg';

const Home: React.FC = () => {
  return (
    <section className="page page-home">
      <div>
        <img className='bg-logo' src={String(image)}></img>
      </div>
    </section>
  );
};

export default Home;
