import React, { useState } from "react";
import { useParams } from "react-router-dom";
// import { useNavigate } from "react-router-dom";
import "./bom.css";
import BomModal from "./Bom_modal/bom_modal";

const Bom: React.FC = () => {
  const { cscId } = useParams();

  const [currentPage, setCurrentPage] = useState(1);
//   const navigate = useNavigate();

  const [showModal, setShowModal] = useState(false);

  const [rows, setRows] = useState(
    Array.from({ length: 22 }, (_, i) => ({
      sno: i + 1,
      level: "",
      partNo: "",
      rev: "",
      desc: "",
      qty: "",
      processType: "",
      scope: "",
      method: "",
      nesting: ""
    }))
  );

  const ITEMS_PER_PAGE = 15;

  const totalPages = Math.ceil(rows.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentRows = rows.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const addRow = () => {
    setRows([
      ...rows,
      {
        sno: rows.length + 1,
        level: "",
        partNo: "",
        rev: "",
        desc: "",
        qty: "",
        processType: "",
        scope: "",
        method: "",
        nesting: ""
      }
    ]);
  };

  const deleteRow = (index: number) => {
    const actualIndex = startIndex + index;
    setRows(rows.filter((_, i) => i !== actualIndex));
  };

  const getPages = () => {
    const pages: (number | string)[] = [];
    if (totalPages <= 5) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (currentPage <= 3) pages.push(1, 2, 3, "...", totalPages);
      else if (currentPage >= totalPages - 2)
        pages.push(1, "...", totalPages - 2, totalPages - 1, totalPages);
      else
        pages.push(
          1,
          "...",
          currentPage - 1,
          currentPage,
          currentPage + 1,
          "...",
          totalPages
        );
    }
    return pages;
  };

    type TabType = "BOM" | "SUMMARY" | "GRAPH";
    const [activeTab, setActiveTab] = useState<TabType>("BOM");

    const summaryData = Array.from({ length: 26 }, (_, i) => ({
    sno: i + 1,
    parentPart: "F4J03714",
    level: "1",
    partNo: `PART-${i + 1}`,
    rev: "#",
    desc: "Bracket Assembly",
    qty: 1,
    processType: "Laser",
    scope: "In",
    method: "Make",
    directRm: 36.6,
    allowance: 2.81,
    processCost: 53.27,
    surfaceCost: 0,
    oh: 1.73,
    profit: 3.44,
    cpu: 12.4,
    cpa: 10.2,
    weight: 2.3,
    totalWeight: 5.6,
    rateKg: 42.3
    }));

    const SUMMARY_PER_PAGE = 15;
    const [summaryPage, setSummaryPage] = useState(1);

    const summaryTotalPages = Math.ceil(summaryData.length / SUMMARY_PER_PAGE);
    const summaryStart = (summaryPage - 1) * SUMMARY_PER_PAGE;
    const currentSummary = summaryData.slice(
    summaryStart,
    summaryStart + SUMMARY_PER_PAGE
    );

    const costData = [
    { label: "Direct RM", amount: 36.6, ratio: "37%" },
    { label: "Allowance", amount: 2.81, ratio: "3%" },
    { label: "Process Cost", amount: 53.27, ratio: "54%" },
    { label: "Surface Protection", amount: 0, ratio: "0%" },
    { label: "Overhead", amount: 1.73, ratio: "2%" },
    { label: "Profit", amount: 3.44, ratio: "4%" },
    { label: "Total Basic Cost", amount: 97.86, ratio: "100%" },
    { label: "Packaging", amount: 0, ratio: "10%" },
    { label: "Transport", amount: 0, ratio: "124%" },
    { label: "Amortization", amount: 0, ratio: "10%" },
    { label: "Total Cost", amount: 98, ratio: "244%" }
    ];

  return (
    <div className="bom-page">

      {/* TOP CARDS */}
      <div className="bom-top">
        <div className="bom-csc-card">
          {/* <h3>CSC Details</h3> */}
          <div className="bom-info-grid">
            <div><b>CSC ID:</b> {cscId}</div>
            <div><b>Part No:</b> F4J03714</div>
            <div><b>Rev:</b> #</div>
            <div><b>Description:</b> BRACKET-AIR TANK</div>
            <div><b>Estimated By:</b> parthiban.c1</div>
            <div><b>RM Base:</b> 2025</div>
            <div><b>Process Base:</b> 2025</div>
            <div><b>OH Profit Base:</b> 2025</div>
          </div>
        </div>

        <div className="bom-cost-card">
          <span>Total Estimated Cost</span>
          <h2>₹ 97.68</h2>
        </div>
      </div>

      {/* TABS */}
      <div className="bom-tabs">
        <button className={`tab ${activeTab === "BOM" ? "active" : ""}`} onClick={() => setActiveTab("BOM")}>BOM</button>
        <button className={`tab ${activeTab === "SUMMARY" ? "active" : ""}`} onClick={() => setActiveTab("SUMMARY")}>BOM Summary</button>
        <button className={`tab ${activeTab === "GRAPH" ? "active" : ""}`} onClick={() => setActiveTab("GRAPH")}>Graph View</button>
      </div>

      {/* BOM TABLE */}
      {activeTab === "BOM" && (
      <div className="bom-table-card">
        <div className="bom-table-header">
          <h3>BOM List</h3>
          <div className="bom-actions">
            <button className="btn btn-primary">Save BOM Data</button>
            <button className="btn btn-outline">Update BOM Data</button>
          </div>
        </div>

        <div className="bom-table-wrapper">
          <table className="bom-table">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Level</th>
                <th>Part No</th>
                <th>Rev</th>
                <th>Description</th>
                <th>Qty</th>
                <th>Process Type</th>
                <th>Scope</th>
                <th>Method</th>
                <th>Nesting</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {currentRows.map((_, index) => (
                <tr key={index}>
                  <td>{startIndex + index + 1}</td>
                  <td><input className="tbl-input" /></td>
                  <td><input className="tbl-input" /></td>
                  <td><input className="tbl-input" /></td>
                  <td><input className="tbl-input" /></td>
                  <td><input className="tbl-input" /></td>

                  <td>
                    <select className="tbl-select">
                      <option>Select</option>
                      <option>Laser</option>
                      <option>Bending</option>
                    </select>
                  </td>

                  <td>
                    <select className="tbl-select">
                      <option>Select</option>
                      <option>In Scope</option>
                      <option>Out Scope</option>
                    </select>
                  </td>

                  <td>
                    <select className="tbl-select">
                      <option>Select</option>
                      <option>Make</option>
                      <option>Buy</option>
                    </select>
                  </td>

                  <td>
                    <select className="tbl-select">
                      <option>Select</option>
                      <option>Yes</option>
                      <option>No</option>
                    </select>
                  </td>

                  <td className="action-cell">
                    <button
                      className="icon-btn add"
                      title="Add"
                      onClick={addRow}
                    >
                    <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    >
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                    </button>
                    <button className="icon-btn edit" title="Edit" onClick={() => setShowModal(true)}>
                    <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    >
                    <path d="M12 20h9" />
                    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" />
                    </svg>
                    </button>
                    <button
                      className="icon-btn delete"
                      title="Delete"
                      onClick={() => deleteRow(index)}
                    >
                    <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    >
                    <polyline points="3 6 5 6 21 6" />
                    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
                    <path d="M10 11v6" />
                    <path d="M14 11v6" />
                    <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" />
                    </svg>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && (
            <BomModal onClose={() => setShowModal(false)} />
        )}

        {/* PAGINATION */}
        <div className="bom-pagination-bar">
          <button
            className="page-btn"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(currentPage - 1)}
          >
            Prev
          </button>

          {getPages().map((p, i) =>
            p === "..." ? (
              <span key={i} className="page-dots">…</span>
            ) : (
              <button
                key={i}
                className={`page-btn ${currentPage === p ? "active" : ""}`}
                onClick={() => setCurrentPage(p as number)}
              >
                {p}
              </button>
            )
          )}

          <button
            className="page-btn"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(currentPage + 1)}
          >
            Next
          </button>
        </div>
      </div>)}
      {activeTab === "SUMMARY" && (
        <div className="bom-summary-card">
            <h3>BOM Summary</h3>

            <div className="bom-table-wrapper">
            <table className="bom-summary-table">
                <thead>
                <tr>
                    <th>S.No</th>
                    <th>Parent Part No</th>
                    <th>Level</th>
                    <th>Part No</th>
                    <th>Rev</th>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Process</th>
                    <th>Scope</th>
                    <th>Method</th>
                    <th>Direct RM</th>
                    <th>Allowance</th>
                    <th>Process Cost</th>
                    <th>Surface Cost</th>
                    <th>OH & Others</th>
                    <th>Profit</th>
                    <th>CPU</th>
                    <th>CPA</th>
                    <th>Weight</th>
                    <th>Total Weight</th>
                    <th>Rate/Kg</th>
                </tr>
                </thead>
                <tbody>
                {currentSummary.map((row) => (
                    <tr key={row.sno}>
                    <td>{row.sno}</td>
                    <td>{row.parentPart}</td>
                    <td>{row.level}</td>
                    <td>{row.partNo}</td>
                    <td>{row.rev}</td>
                    <td>{row.desc}</td>
                    <td>{row.qty}</td>
                    <td>{row.processType}</td>
                    <td>{row.scope}</td>
                    <td>{row.method}</td>
                    <td>{row.directRm}</td>
                    <td>{row.allowance}</td>
                    <td>{row.processCost}</td>
                    <td>{row.surfaceCost}</td>
                    <td>{row.oh}</td>
                    <td>{row.profit}</td>
                    <td>{row.cpu}</td>
                    <td>{row.cpa}</td>
                    <td>{row.weight}</td>
                    <td>{row.totalWeight}</td>
                    <td>{row.rateKg}</td>
                    </tr>
                ))}
                </tbody>
            </table>
            </div>

            <div className="pagination-bar">
            <button
                className="page-btn"
                disabled={summaryPage === 1}
                onClick={() => setSummaryPage(summaryPage - 1)}
            >
                Prev
            </button>

            <span>
                Page {summaryPage} / {summaryTotalPages}
            </span>

            <button
                className="page-btn"
                disabled={summaryPage === summaryTotalPages}
                onClick={() => setSummaryPage(summaryPage + 1)}
            >
                Next
            </button>
            </div>
        </div>
        )}

        {activeTab === "GRAPH" && (
        <div className="graph-card">
            <h3>Cost Breakdown</h3>

            <table className="graph-table">
            <thead>
                <tr>
                <th>Cost Head</th>
                {costData.map((c) => (
                    <th key={c.label}>{c.label}</th>
                ))}
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>Amount</td>
                {costData.map((c) => (
                    <td key={c.label}>{c.amount}</td>
                ))}
                </tr>
                <tr>
                <td>Ratio</td>
                {costData.map((c) => (
                    <td key={c.label}>{c.ratio}</td>
                ))}
                </tr>
            </tbody>
            </table>

            {/* WATERFALL GRAPH */}
            <div className="waterfall-chart">
            <svg viewBox="0 0 1200 300">
                {costData.map((item, i) => {
                const barHeight = item.amount * 2;
                return (
                    <rect
                    key={i}
                    x={i * 105 + 40}
                    y={250 - barHeight}
                    width={60}
                    height={barHeight}
                    rx={6}
                    fill="#24968f"
                    />
                );
                })}
            </svg>
            </div>
        </div>
        )}
    </div>
  );
};

export default Bom;