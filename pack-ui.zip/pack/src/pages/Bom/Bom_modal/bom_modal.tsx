import React, { useState } from "react";
import "./bom_modal.css";

const BomModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  /** === Table 1: SM Material === */
//   console.log('onclose',onClose)
  const [smMaterial, setSmMaterial] = useState([
    {
      partNo: "",
      description: "",
      estimation: "",
      method: "",
      materialGrade: "",
      length: "",
      width: "",
      thick: "",
      cuttingType: "",
      finishWeight: "",
      rmPrice: "",
      sheetLength: "",
      sheetWidth: "",
      sheetWeight: "",
      blanksPerSheet: "",
      blankWeight: "",
      inputWeight: "",
      yieldPct: "",
      surfaceArea: "",
      scrapWeight: "",
      scrapPrice: "",
      recovery: "",
      pricePerUnit: "",
      directRmCost: "",
      allowanceCost: "",
      remarks: "",
    },
  ]);

  /** === Table 2: SM Process === */
  const [smProcess, setSmProcess] = useState([
    {
      partNo: "",
      processPlace: "",
      partDesc: "",
      processDesc: "",
      mechHyd: "",
      cutLenFormula: "",
      cutFrmgLen: "",
      machineType: "",
      noOfOpe: "",
      partPerCycle: "",
      norms: "",
      processCostUnit: "",
      remarks: "",
    },
  ]);

  /** === Table 3: OH Profit === */
  const [ohProfit, setOhProfit] = useState([
    {
      processType: "",
      iccRm: "",
      iccConv: "",
      iccBof: "",
      rejRm: "",
      rejConv: "",
      rejBof: "",
      inspRm: "",
      inspConv: "",
      inspBof: "",
      tmcRm: "",
      tmcConv: "",
      tmcBof: "",
      designRm: "",
      designConv: "",
      designBof: "",
      ohRm: "",
      ohConv: "",
      ohBof: "",
      profitRm: "",
      profitConv: "",
      profitBof: "",
      warrantyCost: "",
      inboundLogistics: "",
      effectiveFrom: "",
      base: "",
      source: "",
      remarks: "",
    },
  ]);

  /** === Add/Delete Row for SM Process === */
  const addSmProcessRow = () => {
    setSmProcess([
      ...smProcess,
      {
        partNo: "",
        processPlace: "",
        partDesc: "",
        processDesc: "",
        mechHyd: "",
        cutLenFormula: "",
        cutFrmgLen: "",
        machineType: "",
        noOfOpe: "",
        partPerCycle: "",
        norms: "",
        processCostUnit: "",
        remarks: "",
      },
    ]);
  };

  const deleteSmProcessRow = (index: number) => {
    setSmProcess(smProcess.filter((_, i) => i !== index));
  };

  return (
    <div className="bom-modal-overlay">
      <div className="bom-modal">
        <div className="bom-modal-header">
          <h2>Create / Edit BOM</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>

        <div className="bom-modal-body">
          {/* === SM Material Table === */}
          <div className="bom-table-section">
            <h3>SM Material</h3>
            <div className="table-wrapper">
              <table className="bom-modal-table">
                <thead>
                  <tr>
                    {Object.keys(smMaterial[0]).map((key) => (
                      <th key={key}>{key.replace(/([A-Z])/g, " $1")}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {smMaterial.map((row, idx) => (
                    <tr key={idx}>
                      {Object.entries(row).map(([k, val]) => (
                        <td key={k}>
                          {["materialGrade", "cuttingType"].includes(k) ? (
                            <select
                              value={val}
                              onChange={(e) =>
                                setSmMaterial((prev) => {
                                  const newRows = [...prev];
                                  newRows[idx][k] = e.target.value;
                                  return newRows;
                                })
                              }
                            >
                              <option value="">Select</option>
                              <option>Option 1</option>
                              <option>Option 2</option>
                            </select>
                          ) : (
                            <input
                              value={val}
                              onChange={(e) =>
                                setSmMaterial((prev) => {
                                  const newRows = [...prev];
                                  newRows[idx][k] = e.target.value;
                                  return newRows;
                                })
                              }
                            />
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* === SM Process Table === */}
          <div className="bom-table-section">
            <h3>SM Process</h3>
            <div className="table-wrapper">
              <table className="bom-modal-table">
                <thead>
                  <tr>
                    {Object.keys(smProcess[0]).map((key) => (
                      <th key={key}>{key.replace(/([A-Z])/g, " $1")}</th>
                    ))}
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {smProcess.map((row, idx) => (
                    <tr key={idx}>
                      {Object.entries(row).map(([k, val]) => (
                        <td key={k}>
                          {["processDesc", "mechHyd", "machineType"].includes(k) ? (
                            <select
                              value={val}
                              onChange={(e) => {
                                const newRows = [...smProcess];
                                newRows[idx][k] = e.target.value;
                                setSmProcess(newRows);
                              }}
                            >
                              <option value="">Select</option>
                              <option>Option 1</option>
                              <option>Option 2</option>
                            </select>
                          ) : (
                            <input
                              value={val}
                              onChange={(e) => {
                                const newRows = [...smProcess];
                                newRows[idx][k] = e.target.value;
                                setSmProcess(newRows);
                              }}
                            />
                          )}
                        </td>
                      ))}
                      <td className="action-cell">
                        <button className="modal-icon-btn add" onClick={addSmProcessRow}>+</button>
                        <button className="modal-icon-btn delete" onClick={() => deleteSmProcessRow(idx)}>−</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* === OH Profit Table === */}
          <div className="bom-table-section">
            <h3>OH Profit</h3>
            <div className="table-wrapper">
              <table className="bom-modal-table">
                <thead>
                  <tr>
                    {Object.keys(ohProfit[0]).map((key) => (
                      <th key={key}>{key.replace(/([A-Z])/g, " $1")}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {ohProfit.map((row, idx) => (
                    <tr key={idx}>
                      {Object.entries(row).map(([k, val]) => (
                        <td key={k}>
                          <input
                            value={val}
                            onChange={(e) => {
                              const newRows = [...ohProfit];
                              newRows[idx][k] = e.target.value;
                              setOhProfit(newRows);
                            }}
                          />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="bom-modal-footer">
          <button className="btn btn-primary" onClick={onClose}>Save</button>
          <button className="btn btn-outline" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default BomModal;