
import React from 'react';
import { NavLink, Routes, Route } from 'react-router-dom';
import './App.css';
import logo from './assets/KMC_logo.png';
import Home from './pages/Home/home';
import Csc from './pages/Csc/csc';
import Bom from './pages/Bom/bom';

const App: React.FC = () => {
  return (
      <div className="app">
        <header className="app-header">
          <nav className="header-nav" aria-label="Primary">
            <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              HOME
            </NavLink>
            <NavLink to="/csc" className={({ isActive }) =>`nav-link ${isActive ? 'active' : ''}`}>
              CSC
            </NavLink>
          </nav>

          <div className="header-left">
              <img alt="Company Logo" className="logo" src={String(logo)}></img>
          </div>

        </header>
        <main className="app-main" role="main">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/csc" element={<Csc />} />
            <Route path="/bom/:cscId" element={<Bom />} />
          </Routes>
        </main>
      </div>
  );
};

export default App;
