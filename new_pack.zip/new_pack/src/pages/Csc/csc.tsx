import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  getCscList,
  createCsc,
  updateCsc,
  deleteCsc,
  getPartTypes,
  getProjects,
} from "../../api/cscApi";
import "./csc.css";

interface Dropdown {
  id: number;
  name: string;
}

interface CscItem {
  id: number;
  part_num: string;
  rev: string;
  desc: string;
  part_typ: number | null;
  projects: number | null;
  rm_base: string;
  process_base: string;
  oh_profit_base: string;
  remarks: string;
  unique_csc_id: string;
  csc_status: string;
}

const Csc: React.FC = () => {
  const navigate = useNavigate();

  const [data, setData] = useState<CscItem[]>([]);
  const [partTypes, setPartTypes] = useState<Dropdown[]>([]);
  const [projects, setProjects] = useState<Dropdown[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    part_num: "",
    rev: "",
    desc: "",
    part_typ: "",
    projects: "",
    rm_base: "",
    process_base: "",
    oh_profit_base: "",
    remarks: "",
    updated_by: "parthiban.c1",
  });

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    try {
      const [cscRes] = await Promise.all([
        getCscList(),
        // getPartTypes(),
        // getProjects(),
      ]); //, typeRes, projectRes
      console.log('data',cscRes)
      setData(cscRes);
      // setPartTypes(typeRes.data);
      // setProjects(projectRes.data);
    } catch (err) {
      console.error("API error", err);
    }
  };

  const openModal = () => {
    setEditId(null);
    setFormData({
      part_num: "",
      rev: "",
      desc: "",
      part_typ: "",
      projects: "",
      rm_base: "",
      process_base: "",
      oh_profit_base: "",
      remarks: "",
      updated_by: "parthiban.c1",
    });
    setShowModal(true);
  };

  const closeModal = () => setShowModal(false);

  const openEdit = (item: CscItem) => {
    setEditId(item.id);
    setFormData({
      part_num: item.part_num,
      rev: item.rev,
      desc: item.desc,
      part_typ: item.part_typ ? String(item.part_typ) : "",
      projects: item.projects ? String(item.projects) : "",
      rm_base: item.rm_base,
      process_base: item.process_base,
      oh_profit_base: item.oh_profit_base,
      remarks: item.remarks,
      updated_by: "parthiban.c1",
    });
    setShowModal(true);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    const payload = {
      ...formData,
      part_typ: formData.part_typ || null,
      projects: formData.projects || null,
    };

    try {
      if (editId) {
        await updateCsc(editId, payload);
      } else {
        await createCsc(payload);
      }
      closeModal();
      fetchAll();
    } catch (err) {
      console.error("Save failed", err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Are you sure you want to delete this CSC?")) return;
    try {
      await deleteCsc(id);
      fetchAll();
    } catch (err) {
      console.error("Delete failed", err);
    }
  };

  return (
    <div className="csc-page">
      <div className="csc-card">
        <div className="csc-header">
          <h1>CSC List</h1>
          <button className="btn btn-primary" onClick={openModal}>
            Create New CSC
          </button>
        </div>

        <div className="csc-table-wrapper">
          <table className="csc-table">
            <thead>
              <tr>
                <th>Part Name</th>
                <th>Rev</th>
                <th>Description</th>
                <th>CSC ID</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {data.map(item => (
                <tr key={item.id}>
                  <td>{item.part_num}</td>
                  <td>{item.rev}</td>
                  <td>{item.desc}</td>
                  <td>{item.unique_csc_id}</td>
                  <td>
                    <span className="status in-progress">
                      {item.csc_status || "In-progress"}
                    </span>
                  </td>
                  <td className="action-cell">
                    <button
                      className="action-btn action-view"
                      data-tooltip="Bom"
                      onClick={() => navigate(`/bom/${item.unique_csc_id}`)}
                    >
                      👁
                    </button>

                    <button
                      className="action-btn action-edit"
                      data-tooltip="Edit"
                      onClick={() => openEdit(item)}
                    >
                      ✎
                    </button>

                    <button
                      className="action-btn action-delete"
                      data-tooltip="Delete"
                      onClick={() => handleDelete(item.id)}
                    >
                      🗑
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT CSC MODAL */}
      {showModal && (
        <div className="modal-backdrop">
          <div className="modal-container">
            <div className="modal-header">
              <h2>{editId ? "Edit CSC" : "Create CSC"}</h2>
              <button className="modal-close" onClick={closeModal}>×</button>
            </div>

            <div className="modal-body">
              <div className="form-grid">
                <div className="form-group">
                  <label>Part Number</label>
                  <input name="part_num" value={formData.part_num} onChange={handleChange} />
                </div>

                <div className="form-group">
                  <label>Revision</label>
                  <input name="rev" value={formData.rev} onChange={handleChange} />
                </div>

                <div className="form-group full">
                  <label>Description</label>
                  <textarea name="desc" rows={3} value={formData.desc} onChange={handleChange} />
                </div>

                <div className="form-group">
                  <label>Part Type</label>
                  <select name="part_typ" value={formData.part_typ} onChange={handleChange}>
                    <option value="">Select</option>
                    {partTypes.map(pt => (
                      <option key={pt.id} value={pt.id}>{pt.name}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>Project</label>
                  <select name="projects" value={formData.projects} onChange={handleChange}>
                    <option value="">Select</option>
                    {projects.map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>RM Base Date</label>
                  <input name="rm_base" value={formData.rm_base} onChange={handleChange} />
                </div>

                <div className="form-group">
                  <label>Process Base Date</label>
                  <input name="process_base" value={formData.process_base} onChange={handleChange} />
                </div>

                <div className="form-group">
                  <label>OH / Profit / Other Cost Base</label>
                  <input name="oh_profit_base" value={formData.oh_profit_base} onChange={handleChange} />
                </div>

                <div className="form-group full">
                  <label>Remarks</label>
                  <textarea name="remarks" rows={2} value={formData.remarks} onChange={handleChange} />
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button className="btn btn-outline" onClick={closeModal}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSave}>
                {editId ? "Update CSC" : "Save CSC"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Csc;