const API_BASE = "http://10.8.29.165:8081/myapp";

const jsonHeaders = {
  "Content-Type": "application/json",
};

const handleResponse = async (res: Response) => {
  if (!res.ok) {
    const error = await res.text();
    throw new Error(error || "API Error");
  }
  return res.json();
};

export const getCscList = async () => {
  const res = await fetch(`${API_BASE}/csc/`);
//   console.log('res',res.json())
  return handleResponse(res);
};

export const createCsc = async (data: any) => {
  const res = await fetch(`${API_BASE}/csc/create/`, {
    method: "POST",
    headers: jsonHeaders,
    body: JSON.stringify(data),
  });
  return handleResponse(res);
};

export const updateCsc = async (id: number, data: any) => {
  const res = await fetch(`${API_BASE}/csc/update/${id}/`, {
    method: "PUT",
    headers: jsonHeaders,
    body: JSON.stringify(data),
  });
  return handleResponse(res);
};

export const deleteCsc = async (id: number) => {
  const res = await fetch(`${API_BASE}/csc/delete/${id}/`, {
    method: "DELETE",
  });
  return handleResponse(res);
};

export const getPartTypes = async () => {
  const res = await fetch(`${API_BASE}/part-types/`);
  return handleResponse(res);
};

export const getProjects = async () => {
  const res = await fetch(`${API_BASE}/projects/`);
  return handleResponse(res);
};