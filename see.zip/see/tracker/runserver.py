from waitress import serve

from tracker.wsgi import application
# documentation: https://docs.pylonsproject.org/projects/waitress/en/stable/api.html

if __name__ == '__main__':
    print('Started')
    # serve(application, host='localhost', port='8581', threads=8) #uncommend for 8.25
    serve(application, host='localhost', port='8586', threads=8)