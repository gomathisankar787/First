from django.urls import path
from knox.views import LogoutView
from knox import views as knox_views


from . import views



urlpatterns = [
    path('user_list/', views.UserList.as_view()),
    path('user_list/user_by_id', views.UserListById.as_view()),
    path('act_user_list/', views.ActUserList.as_view()),
    path('password_encryption/',views.PwdEncryption.as_view()),
    path('register/',views.UserRegister.as_view()),
    path('login/',views.LoginApi.as_view()),
    path('logout/', knox_views.LogoutView.as_view(), name='knox_logout'),
    path('logoutall/', knox_views.LogoutAllView.as_view(), name='knox_logoutall'),
    path('rolelist/',views.RoleList.as_view()),
    path('usr_shift_info/',views.UserShiftInfo.as_view()),
    path('dept_create/', views.DeptCreate.as_view()),
    path('dept_update/', views.DeptUpdate.as_view()),
    path('dept_list/', views.Deptlist.as_view()),
    path('user_update/', views.UserUpdation.as_view()),
    path('add_holiday/', views.AddHoliday.as_view()),
    path('update_holiday/', views.UpdateHoliday.as_view()),
    path('holiday_list/', views.Holidaylist),
    path('holidaylist_actdeact/', views.HolidayListActDeact.as_view()),
    path('yearly_holyday_list/', views.YearlyHolidayList.as_view()),
    path('get_user_biomet_details/', views.GetUserBiometDetails.as_view()),
    path('get_first_biomet_date/', views.GetFirstBiometDate.as_view()),
    path('act_deact/', views.ActiveDeactive.as_view()),
    path('notif_sys_list/', views.NotificationSystemInfo),
    path('notif_sys_update/', views.NotifSystemUpdate.as_view()),
    path('bio_database_config/', views.BioDbConfig.as_view()),
    path('timeshtlist_act_deact/', views.TimeshtListact_deact.as_view()),
    path('dept_user_list/', views.DeptUserList.as_view()),
    path('user_profile_view/', views.UserProfileView.as_view()),
    path('tkn_usr_info/', views.TknUsrInfo.as_view()),
    path('upd_profile_by_user/', views.UpdProfileByUser.as_view()),
    path('leave_policy/file_upload/',views.DocFileUpload.as_view()),
    path('leave_policy/file_list/',views.LeavePolicyFileList.as_view()),
    path('leave_policy/file_download/',views.LeavePolicyFileDownload.as_view())
]