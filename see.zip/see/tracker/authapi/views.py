from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import F, Q
from django.db import connections
from rest_framework.decorators import api_view, permission_classes
from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import BasicAuthentication
from rest_framework.authtoken.serializers import AuthTokenSerializer
from datetime import date, datetime, timezone
import logging
logger = logging.getLogger(__name__)
import base64
import json,mimetypes


from drf_yasg.utils import swagger_auto_schema
from knox.models import AuthToken
from knox.auth import TokenAuthentication
from knox.views import LoginView as KnoxLoginView
from rest_framework.parsers import MultiPartParser


from .models import *
from .serializers import *
from tracker.settings import DATABASES
from tracker.custom_permissions import IsAdmin, IsBasicUser,IsManager
from ticketingsystem.models import TicketDetails,TicketStatus
from django.db.models import Prefetch

# Create your views here.


class UserList(generics.GenericAPIView):
    permission_classes = []
    # def get(self, request):
    #     try:
    #         user_info = User.objects.all().values(
    #             'username', 'id', 'email', 'first_name', 'last_name', 'role_id',
    #             'pseudo_name', 'user_info', 'timeshtlist_sts', 'shift_id', 'shift_frm',
    #             'shift_to', 'timechk_sts', 'dept_id', 'bm_usr_id', 'entry_date', 'date_joined',
    #             'gender', 'is_active'
    #         ).annotate(dept_name=F('dept__name'))
    #         return Response(user_info, status=status.HTTP_200_OK)
    #     except Exception as e:
    #         print('UserList Error: ', str(e))
    #         return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    def get(self, request):
        try:
            # Prefetch children linked to personal info
            children_qs = UserChildInformation.objects.all()

            # Prefetch personal info, including its children
            user_info_qs = UserPersonalInformation.objects.all().prefetch_related(
                Prefetch('rn_user_parent_id', queryset=children_qs, to_attr='prefetched_children')
            )

            # Prefetch personal info into User
            users = User.objects.all().select_related('dept', 'shift').prefetch_related(
                Prefetch('rn_user_id', queryset=user_info_qs, to_attr='prefetched_user_info')
            )

            user_data = []
            for user in users:
                personal_info = user.prefetched_user_info[0] if user.prefetched_user_info else None

                children_data = []
                if personal_info and hasattr(personal_info, 'prefetched_children'):
                    for child in personal_info.prefetched_children:
                        children_data.append({
                            'name': child.name,
                            'age': child.age,
                            'aadhar_number': child.aadhar_number,
                            'pan_number': child.pan_number,
                            'date_of_birth': child.date_of_birth,
                            'relation_type': child.relation_type
                        })

                user_data.append({
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                    'role_id': user.role_id,
                    'pseudo_name': user.pseudo_name,
                    'timeshtlist_sts': user.timeshtlist_sts,
                    'shift_id': user.shift_id,
                    'shift_frm': user.shift_frm,
                    'shift_to': user.shift_to,
                    'timechk_sts': user.timechk_sts,
                    'dept_id': user.dept_id,
                    'dept_name': user.dept.name if user.dept else None,
                    'bm_usr_id': user.bm_usr_id,
                    'entry_date': user.entry_date,
                    'date_joined': user.date_joined,
                    'gender': user.gender,
                    'is_active': user.is_active,
                    'user_info': {
                        'address': personal_info.address if personal_info else None,
                        'phone_number': personal_info.phone_number if personal_info else None,
                        'alternate_phone_number': personal_info.alternate_phone_number if personal_info else None,
                        'aadhar_number': personal_info.aadhar_number if personal_info else None,
                        'marital_status': personal_info.marital_status if personal_info else None,
                        'spouse_name': personal_info.spouse_name if personal_info else None,
                        'number_of_children': personal_info.number_of_children if personal_info else None,
                        'blood_group': personal_info.blood_group if personal_info else None,
                        'date_of_birth': personal_info.date_of_birth if personal_info else None,
                        'pan_number': personal_info.pan_number if personal_info else None,
                        'insurance_required': personal_info.insurance_required if personal_info else None,
                        'insurance_provider': personal_info.insurance_provider if personal_info else None,
                        'insurance_policy_number': personal_info.insurance_policy_number if personal_info else None,
                        'children': children_data
                    }
                })

            return Response(user_data, status=status.HTTP_200_OK)

        except Exception as e:
            print('UserList Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UserListById(generics.GenericAPIView):
    permission_classes = []
    @swagger_auto_schema(request_body=UserListByIdSerializer)
    def post(self, request):
        try:
            user_id = request.data.get('user_id')
            if not user_id:
                return Response({'error': 'user_id is required'}, status=status.HTTP_400_BAD_REQUEST)

            # Prefetch children linked to personal info
            children_qs = UserChildInformation.objects.all()

            # Prefetch personal info, including its children
            user_info_qs = UserPersonalInformation.objects.prefetch_related(
                Prefetch('rn_user_parent_id', queryset=children_qs, to_attr='prefetched_children')
            )

            # Get the specific user
            user = (
                User.objects
                .filter(id=user_id)
                .select_related('dept', 'shift')
                .prefetch_related(
                    Prefetch('rn_user_id', queryset=user_info_qs, to_attr='prefetched_user_info')
                )
                .first()
            )

            if not user:
                return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

            personal_info = user.prefetched_user_info[0] if user.prefetched_user_info else None

            children_data = []
            if personal_info and hasattr(personal_info, 'prefetched_children'):
                for child in personal_info.prefetched_children:
                    children_data.append({
                        'name': child.name,
                        'age': child.age,
                        'aadhar_number': child.aadhar_number,
                        'pan_number': child.pan_number,
                        'date_of_birth': child.date_of_birth
                    })

            user_data = {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role_id': user.role_id,
                'pseudo_name': user.pseudo_name,
                'timeshtlist_sts': user.timeshtlist_sts,
                'shift_id': user.shift_id,
                'shift_frm': user.shift_frm,
                'shift_to': user.shift_to,
                'timechk_sts': user.timechk_sts,
                'dept_id': user.dept_id,
                'dept_name': user.dept.name if user.dept else None,
                'bm_usr_id': user.bm_usr_id,
                'entry_date': user.entry_date,
                'date_joined': user.date_joined,
                'gender': user.gender,
                'is_active': user.is_active,
                'user_info': {
                    'address': personal_info.address if personal_info else None,
                    'phone_number': personal_info.phone_number if personal_info else None,
                    'alternate_phone_number': personal_info.alternate_phone_number if personal_info else None,
                    'aadhar_number': personal_info.aadhar_number if personal_info else None,
                    'marital_status': personal_info.marital_status if personal_info else None,
                    'spouse_name': personal_info.spouse_name if personal_info else None,
                    'number_of_children': personal_info.number_of_children if personal_info else None,
                    'blood_group': personal_info.blood_group if personal_info else None,
                    'date_of_birth': personal_info.date_of_birth if personal_info else None,
                    'pan_number': personal_info.pan_number if personal_info else None,
                    'insurance_required': personal_info.insurance_required if personal_info else None,
                    'insurance_provider': personal_info.insurance_provider if personal_info else None,
                    'insurance_policy_number': personal_info.insurance_policy_number if personal_info else None,
                    'children': children_data
                }
            }

            return Response(user_data, status=status.HTTP_200_OK)

        except Exception as e:
            print('UserListById Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ActUserList(generics.GenericAPIView):
    def get(self, request):
        try:
            user_info = User.objects.filter(is_active=True).all().values(
                'username', 'id', 'email', 'first_name', 'last_name', 'role_id',
                'pseudo_name', 'user_info', 'timeshtlist_sts', 'shift_id', 'shift_frm',
                'shift_to', 'timechk_sts', 'dept_id', 'bm_usr_id', 'entry_date', 'date_joined',
                'gender', 'is_active').annotate(dept_name=F('dept__name'))
            return Response(user_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('ActUserList Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def serialize_user_info(user):
    return {
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'first_name': user.first_name,
        'role': user.role_id,
        'user_info': user.user_info,
        'pseudo_name': user.pseudo_name,
        'timeshtlist_sts': user.timeshtlist_sts,
        'shift_id': user.shift_id,
        'shift_frm': user.shift_frm,
        'shift_to': user.shift_to,
        'timechk_sts': user.timechk_sts,
        'dept_id': user.dept_id,
        'dept_name': user.dept.name
    }

class UserRegister(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UserRegisterSerializer)
    def post(self, request):
        authentication_classes = (TokenAuthentication,)
        permission_classes = (IsAuthenticated,)
        try:
            request.data['password'] = base64.b64decode(request.data['password']).decode('utf-8')
            request.data['email'] = request.data['email'].lower()
            serializer = UserRegisterSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            user = serializer.save()
            _, token = AuthToken.objects.create(user)
            return Response({
                'user_inform': serialize_user_info(user),
                'token': token
            })
        except Exception as e:
            print('UserRegister Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def usr_upd_data(user_update):
    return {
        'id': user_update.id,
        'first_name': user_update.first_name,
        'last_name': user_update.last_name,
        'role': user_update.role.role_name,
        'gender': user_update.gender,
        'user_info': user_update.user_info,
        'pseudo_name': user_update.pseudo_name,
        'timeshtlist_sts': user_update.timeshtlist_sts,
        'shift_id': user_update.shift_id,
        'shift_frm': user_update.shift_frm,
        'shift_to': user_update.shift_to,
        'timechk_sts': user_update.timechk_sts,
        'bm_usr_id': user_update.bm_usr_id,
        'dept_id': user_update.dept_id,
        'dept_name': user_update.dept.name if user_update.dept != None else None,
        'verified_profile' : user_update.verified_profile
    }

class UserUpdation(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    @swagger_auto_schema(request_body=UserUpdateSerializer)
    def post(self,request):
        try:
            request.data['password'] = base64.b64decode(request.data['password']).decode('utf-8')
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Request": "Encryption error"}, status=status.HTTP_400_BAD_REQUEST)
        userdetail_queryset = User.objects.get(pk=request.data['id'])
        current_dept = userdetail_queryset.dept_id
        updated_dept = int(request.data.get('dept')) if request.data.get('dept') else current_dept

        if updated_dept != current_dept:
            ticket_object = TicketDetails.objects.filter(
                assigned_by_id=request.user.id if request.user.id == request.data['id'] else request.data['id'],
                status_id__in=[
                    TicketStatus.StatusStage.INPROGRESS,
                    TicketStatus.StatusStage.ONHOLD,
                    TicketStatus.StatusStage.REOPEN
                ]
            )
            if ticket_object.exists():
                raise Exception('This user is currently associated with active tickets. Please ensure all tickets are either resolved or reassigned before changing the department.')

        serializer = UserUpdateSerializer(userdetail_queryset, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        user_update = serializer.save()
        try:
            usr_rle = UserRole.objects.get(pk=user_update.role_id)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Userrole not found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        usr_info = usr_upd_data(user_update)
        return Response({
            'user_info': usr_info
        })

class LoginApi(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    authentication_classes = [BasicAuthentication]    
    @swagger_auto_schema(request_body=AuthTokenSerializer)
    def post(self,request):
        try:
            # usr = User.objects.get(username=request.data['username']) 
            usr = User.objects.get(username__iexact=request.data['username']) # need to verify
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Credentials": "User is not exist"}, status=status.HTTP_400_BAD_REQUEST)
        if usr.is_active == False:
            return Response({"Account Error": "User Account Is Inactive.Contact Your Administrator"}, status=status.HTTP_400_BAD_REQUEST)
        request.data['password'] = base64.b64decode(request.data['password']).decode('utf-8')
        request.data['username'] = usr.username # need to verify
        serializer = AuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        _, token = AuthToken.objects.create(user)
        try:
            usr_rle = UserRole.objects.get(pk=user.role_id)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Userrole not found":str(e)},status=status.HTTP_400_BAD_REQUEST)
        usr_info = {
            'id': user.id,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'role':  usr_rle.role_name,
            'gender': user.gender,
            'department':user.dept_id,
            'user_info': user.user_info,
            'verified_profile' : user.verified_profile
        }
        enc_str = json.dumps(usr_info)
        enc_usr_info = base64.b64encode(enc_str.encode('utf-8'))
        return Response({
            'info': enc_usr_info,
            'token': token
        })

class PwdEncryption(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    authentication_classes = [BasicAuthentication]    
    @swagger_auto_schema(request_body=PasswordEncSerializer)
    def post(self,request):
        enc_pass_info = base64.b64encode(request.data['password'].encode('utf-8'))
        return HttpResponse(enc_pass_info)

class RoleList(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    def get(self, request):
        clientinfo = UserRole.objects.all()
        serializer = UserRoleSerializer(clientinfo, many=True)
        return Response(serializer.data)

class UserShiftInfo(generics.GenericAPIView):
    @swagger_auto_schema(methods=['GET'])
    def get(self, request):
        usershift_info = UserShiftDetails.objects.all().values().order_by("order_id")
        return Response(usershift_info)

class DeptCreate(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    @swagger_auto_schema(request_body=DeptCreateSerializer)
    def post(self, request):
        try:
            serializer_data = DeptCreateSerializer(data=request.data)
            serializer_data.is_valid(raise_exception=True)
            data_obj = serializer_data.save()
            out_data = DeptSerializer(data_obj).data
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('DeptCreate Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DeptUpdate(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    @swagger_auto_schema(request_body=DeptCreateSerializer)
    def post(self, request):
        try:
            dept_instance = Department.objects.get(pk=request.data['id'])
            if dept_instance:
                serializer_data = DeptCreateSerializer(instance=dept_instance, data=request.data)
                serializer_data.is_valid(raise_exception=True)
                data_obj = serializer_data.save()
                out_data = DeptSerializer(data_obj).data
                return Response(out_data, status=status.HTTP_200_OK)
            else:
                raise Exception('No data found!')
        except Exception as e:
            print('DeptUpdate Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class Deptlist(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    def get(self, request):
        try:
            dept_data = Department.objects.all()
            out_data = DeptSerializer(dept_data, many=True).data
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('Deptlist Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AddHoliday(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=HolidaySerializer)
    def post(self,request):
        serializer = HolidaySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            invent = serializer.save() 
            Holiday_serialized_data = HolidayListserializer(invent, many=True)
        except Exception as e:        
            logger.warning(f": Bad Request: {request.path}: {request.data}")        
            return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(Holiday_serialized_data.data, status=status.HTTP_200_OK)

class UpdateHoliday(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=HolidaySerializer)
    def post(self,request):
        # if datetime.strptime(request.data['holiday_date'], '%Y-%m-%d').date() < datetime.now().date():
        #     raise Exception('Holiday date not able to update!')
        try:
            update_holiday = HolidayList.objects.get(pk=request.data['id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Id Not Found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        serializer = HolidaySerializer(update_holiday, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        holiday_update = serializer.save()
        return Response(HolidayListserializer(holiday_update).data)

@permission_classes([IsAdmin])
@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def Holidaylist(request):
    today = date.today()
    holidaylist_info = HolidayList.objects.filter(holiday_date__gte=today).values().order_by("holiday_date")
    return Response(holidaylist_info)

class HolidayListActDeact(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=HolidayactdeactSerializer)
    def post(self, request):
        try:
            holiday_info = HolidayList.objects.get(id=request.data['id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Id not Found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        if holiday_info.status == True:
            holiday_info.status = False
        else:
            holiday_info.status = True
        holiday_info.save()
        return Response({
            "id": holiday_info.id,
            "timeshtlist_sts": holiday_info.status,
            'status': "Success"
        })

class YearlyHolidayList(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=YearlyHolidayListSerializer)
    def post(self, request):
        try:
            year = request.data['year']
            filters = {}
            filters['holiday_date__year'] = year
            if request.data['shift_id']:
                filters['shift_id'] = request.data['shift_id']
            filter_qry = Q(**filters)
            holiday_data = HolidayList.objects.filter(filter_qry).values().order_by('holiday_date')
            return Response(holiday_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('YearlyHolidayList Error: ', str(e))
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class GetUserBiometDetails(generics.GenericAPIView):
    def bio_db_query(self):
        with connections['biomet_db'].cursor() as cursor:
            cursor.execute("SELECT UserID, UserName FROM Mx_VEW_UserDetails WHERE ActiveFlag=1") # DeptName!='RCM' and
            usr_biomet = cursor.fetchall()
        return usr_biomet

    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=GetUserBiometDetailsSerializer)
    def post(self, request):
        usr_biomet = []
        biomet_details = []
        user_data_list = []
        # print(request.data, 'data')
        try:
            user_creation_flag = request.data['user_creation_flag']
            if user_creation_flag:
                usr_biomet = self.bio_db_query()
                user_data = User.objects.all().values('bm_usr_id')
                for data in user_data:
                    user_data_list.append(data['bm_usr_id'])
                # print(user_data_list, 'user_data_list')
                for i in usr_biomet:
                    if i[0] not in user_data_list:
                        data = {}
                        data['id'] = i[0]
                        data['name'] = i[1]
                        biomet_details.append(data)
            else:
                usr_biomet = self.bio_db_query()
                for i in usr_biomet:
                    data = {}
                    data['id'] = i[0]
                    data['name'] = i[1]
                    biomet_details.append(data)
                # print(biomet_details)
            usr_bio_info = sorted(biomet_details, key=lambda i: i['name'])
            return Response(usr_bio_info, status=status.HTTP_200_OK)
        except Exception as ex:
            print('biomet_db error: ',str(ex)) 
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Request": str(ex)}, status=status.HTTP_400_BAD_REQUEST)

class GetFirstBiometDate(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=FirstBiometSerializer)
    def post(self, request):
        try:
            biomet_id = request.data['biomet_id']
            try:
                # user_biomet = []
                with connections['biomet_db'].cursor() as cursor:
                    cursor.execute("SELECT min(convert(date, ProcessDate, 103)) FROM Mx_VEW_APIDailyAttendance " +
                    "WHERE department_name!='RCM' and WorkTime>0 and UserID='"+ biomet_id + "'")
                    user_biomet = cursor.fetchall()
            except Exception as ex:
                print('biomet_db error: ',str(ex)) 
            if user_biomet != []:
                first_bio_date = {}
                first_bio_date['date'] = user_biomet[0][0].strftime("%m-%d-%Y")
                return Response(first_bio_date)
            else:
                return Response({"Invalid Request": 'No data found'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print("error:", str(e))
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ActiveDeactive(generics.GenericAPIView):
    permission_classes = (permissions.AllowAny,)
    authentication_classes = [BasicAuthentication]
    @swagger_auto_schema(request_body=UserIdSerializer)
    def post(self, request):
        try:
            usr = User.objects.get(pk=request.data['user_id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"user not Exist": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        if usr.is_active:
            usr.is_active=False
        else:
            usr.is_active=True
        usr.save()
        return Response({'usr_id': usr.id, 'is_active': usr.is_active})

@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def NotificationSystemInfo(request):
    notifsysinfo = NotificationSystem.objects.all().order_by('order_id').values()
    for i in notifsysinfo:
        try:
            i['cc_list'] = json.loads(i['cc_list'].replace("'",'"'))
        except Exception as e:
            print(str(e), "cc_list error")
        try:
            i['to_list'] = json.loads(i['to_list'].replace("'",'"'))
        except Exception as e:
            print(str(e), "to_list error")
    return Response(notifsysinfo)

class NotifSystemUpdate(generics.GenericAPIView):
    @swagger_auto_schema(request_body=NotifSysUpdateSerializer)
    def post(self,request):
        try:
            notifsysupdate = NotificationSystem.objects.get(pk=request.data['id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Id not Found":str(e)},status=status.HTTP_400_BAD_REQUEST)
        request.data['cc_list'] = str(request.data['cc_list'])
        request.data['to_list'] = str(request.data['to_list'])
        serializer = NotifSysUpdateSerializer(notifsysupdate,data=request.data,partial=True)
        serializer.is_valid(raise_exception=True)
        nofif_sys_update = serializer.save()
        return Response(NotifSystemUpdateserializer(nofif_sys_update).data)

class BioDbConfig(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    def get(self, request):
        bio_database = {}
        bio_database['db_name'] = DATABASES['biomet_db']['NAME']
        bio_database['db_host'] = DATABASES['biomet_db']['HOST']
        return Response(bio_database, status=status.HTTP_200_OK)

class TimeshtListact_deact(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=TimeshtListActDeactSerializer)
    def post(self, request):
        try:
            usr_instance = User.objects.get(id=request.data['usr_id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Id not Found":str(e)},status=status.HTTP_400_BAD_REQUEST)
        if usr_instance.timeshtlist_sts == True:
            usr_instance.timeshtlist_sts = False
        else:
            usr_instance.timeshtlist_sts = True
        usr_instance.save()
        return Response({
            "id": usr_instance.id,
            "timeshtlist_sts": usr_instance.timeshtlist_sts,
            'status': "success"}
            )

class DeptUserList(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager]
    def get(self, request):
        try:
            is_manager =True if request.user.role_id == UserRole.RoleStatus.MANAGER else False
            if is_manager:
                dept_id = request.user.dept_id
                filter = {'status':True,'id':dept_id}
            else:
                filter = {'status':True}

            user_filter = User.objects.filter(is_active=True)
            prefetch1 = Prefetch('user_dept',queryset=user_filter)
            dept_obj = Department.objects.prefetch_related(prefetch1).filter(**filter)
            serializer = DeptUserSerializer(dept_obj, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            print('DeptUserList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UserProfileView(generics.GenericAPIView):
    def post(self, request):
        try:
            user_prof_info = User.objects.filter(pk=request.user.id).values(
                'first_name', 'last_name', 'role', 'gender', 'user_info', 'bm_usr_id', 'email',
                'username', 'dept_id', 'id','verified_profile').annotate(dept_name=F('dept__name'))
            return Response(user_prof_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserProfileView error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TknUsrInfo(generics.GenericAPIView):
    authentication_classes = (TokenAuthentication,)
    @swagger_auto_schema(request_body=TknUsrInfoSerializer)
    def post(self, request):
        try:
            tkn_usr_info = User.objects.filter(pk=request.user.id).values('id', 'first_name', 'last_name', 'role_id',
                'gender', 'user_info','verified_profile').annotate(role=F('role__role_name'))
            usr_info = {
                'id': tkn_usr_info[0]['id'],
                'first_name': tkn_usr_info[0]['first_name'],
                'last_name': tkn_usr_info[0]['last_name'],
                'role': tkn_usr_info[0]['role'],
                'gender': tkn_usr_info[0]['gender'],
                'user_info': tkn_usr_info[0]['user_info'],
                'verified_profile': tkn_usr_info[0]['verified_profile']
            }
            enc_str = json.dumps(usr_info)
            enc_usr_info = base64.b64encode(enc_str.encode('utf-8'))
            return Response(enc_usr_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('TknUsrInfo error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UpdProfileByUser(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UpdProfileByUserSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            if request.data['id'] != user_id:
                raise Exception('Access denied to update user profile!')
            try:
                request.data['password'] = base64.b64decode(request.data['password']).decode('utf-8')
            except Exception as e:
                return Response({"Invalid Request": "Encryption error"}, status=status.HTTP_400_BAD_REQUEST)
            user_data = User.objects.get(id=user_id)
            serializer = UpdProfileByUserSerializer(instance=user_data, data=request.data)
            serializer.is_valid(raise_exception=True)
            user_update = serializer.save()
            try:
                usr_rle = UserRole.objects.get(pk=user_update.role_id)
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Userrole not found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
            usr_info = usr_upd_data(user_update)
            return Response(usr_info, status=status.HTTP_200_OK)                
        except Exception as e:
            print('UserPwdUpdate error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DocFileUpload(generics.GenericAPIView):
    parser_classes = ([MultiPartParser,])
    permission_classes = []
    @swagger_auto_schema(request_body=DocFileUploadSerializer)
    def post(self, request):
        try:
            # print(request.data,'request.data')
            user_id = request.user.id
            serializer = DocFileUploadSerializer(data=request.data,context={'user_id': user_id})
            serializer.is_valid(raise_exception=True)
            doc_info = serializer.save()
            doc_info = LeavePolicyFiles.objects.get(id=doc_info.id)
            return Response(DocFileUploadDetailsSerializer(doc_info).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            print('DocFileUpload Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class LeavePolicyFileList(generics.GenericAPIView):
    permission_classes = []
    def get(self, request):
        try:
            file_list = LeavePolicyFiles.objects.values().order_by('id')
            return Response(file_list, status=status.HTTP_200_OK)
        except Exception as e:
            print('LeavePolicyFileList Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class LeavePolicyFileDownload(generics.GenericAPIView):
    permission_classes = []
    # @swagger_auto_schema(request_body=LeavePolicyFileDownloadSerializer)
    # def get(self, request):
    #     try:
    #         id = request.data['file_id']
    #         latest_history = LeavePolicyFiles.objects.filter(id=id).first()
    #         file_name = latest_history.file_name
    #         file_path = latest_history.file_path

    #         full_file_path= os.path.join(LEAVE_FILE_PATH,file_path,file_name)
    #         mime_type, _ = mimetypes.guess_type(full_file_path)
    #         if not mime_type:
    #             mime_type = "application/octet-stream"

    #         with open(full_file_path, 'rb') as file:
    #             response = HttpResponse(file.read(), content_type=mime_type)
    #             response['Content-Disposition'] = f'attachment; filename="{file_name}"'
    #             return response

    #     except Exception as e:
    #         print('LeavePolicyFileDownload Error: ', str(e))
    #         return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    def get(self, request):
        try:
            active_path = os.path.join(LEAVE_FILE_PATH, 'Active File')

            # Ensure folder exists
            if not os.path.exists(active_path):
                return Response({'error': 'Active File folder does not exist'}, status=status.HTTP_404_NOT_FOUND)

            # Pick the only file in Active File folder (since old ones are deleted)
            files = os.listdir(active_path)
            if not files:
                return Response({'error': 'No active file found'}, status=status.HTTP_404_NOT_FOUND)

            file_name = files[0]  # Only one file should be present
            full_file_path = os.path.join(active_path, file_name)

            mime_type, _ = mimetypes.guess_type(full_file_path)
            if not mime_type:
                mime_type = "application/octet-stream"

            with open(full_file_path, 'rb') as file:
                response = HttpResponse(file.read(), content_type=mime_type)
                response['Content-Disposition'] = f'attachment; filename="{file_name}"'
                return response

        except Exception as e:
            print('LeavePolicyFileDownload Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)