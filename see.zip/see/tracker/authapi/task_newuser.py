from __future__ import absolute_import, unicode_literals
from celery import shared_task
from django.core.mail import EmailMessage
from django.apps import apps
import ast
from collections import OrderedDict
from tracker.settings import WEB_URL
from django.template.loader import get_template


from tracker.settings import EMAIL_HOST_USER


def get_cc_list(cc_json):
    usr_id = []
    cc_list = []  
    cc_list_ord = OrderedDict()
    for cc_ind in cc_json:
        usr_id.append(cc_ind["usr_id"])
        cc_list_ord[cc_ind["usr_id"]] = ''
    if len(usr_id) > 0:
        user_obj = apps.get_model(app_label='authapi', model_name='User')
        usr_list = user_obj.objects.filter(id__in=usr_id)                
        for usr_in in usr_list:
            cc_list_ord[usr_in.id]=usr_in.email                
        for key,value in cc_list_ord.items():
            cc_list.append(value)
    return cc_list

@shared_task
def send_newuser_email(user_details):
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        notify_status = NotificationSystem.objects.filter(schedular_name='New User').values()
        notify_enable = False
        cc_json = {}
        if notify_status:
            if notify_status[0]['status'] == True:
                correspondance_name = notify_status[0]['correspondance_name']
                notify_enable = True
                cc_json = ast.literal_eval(notify_status[0]['cc_list'])
        first_name = user_details['first_name']
        last_name = user_details['last_name']
        user_name = user_details['username']
        email = user_details['email']
        password = user_details['password']
        if notify_enable:
            ctx = {
                'first_name':first_name,
                'last_name':last_name,
                'user_name':user_name,
                'password':password,
                'type':"Created",
                'portal_url':WEB_URL
            }
            message = get_template('new_user_tmpl.html').render(ctx)
            # message = f'''<p style="font-size:0.8rem;">Hi {first_name} {last_name},</p>
            # <p style="font-size:0.8rem;">Greetings! Your account has been successfully created. You can access your account using the following credentials:</p>
            # <p style="font-size:0.8rem;">   Username: {user_name}</p>
            # <p style="font-size:0.8rem;">   Password: {password}</p>
            # <p style="font-size:0.8rem;">Please click the following link to log in and view more details...</p>
            # <span style="font-size:0.8rem;"><a href="{WEB_URL}" target="_blank">Login</a></span>
            # <br>
            # <p style="font-size:0.8rem;">- SE Notification System</p>''' #"http:\\192.168.15.160:8585"
            from_email = EMAIL_HOST_USER
            recipient_list = email
            cc_list = get_cc_list(cc_json)

            msg = EmailMessage(
                'Welcome to SE Tracker -  Account Information',
                message,
                f'{correspondance_name} <do_not_reply@solvedge.in>',
                [recipient_list,], 
                cc=cc_list
            )
            msg.content_subtype ="html"# Main content is now text/html
            msg.send()
            print('User creation email triggered')
        else:
            print('New User Notification Disabled')
        return 'email triggered'
    except Exception as ex:
        print('New User Creation Error',ex)

@shared_task
def send_user_pwd_reset_email(user_details):
    try:
        first_name = user_details['first_name']
        last_name = user_details['last_name']
        user_name = user_details['username']
        email = user_details['email']
        password = user_details['password']
        ctx = {
            'first_name':first_name,
            'last_name':last_name,
            'user_name':user_name,
            'password':password,
            'type':"Reset",
            'portal_url':WEB_URL
        }
        message = get_template('new_user_tmpl.html').render(ctx)
        # message = f'''<p style="font-size:0.8rem;">Hi {first_name} {last_name},</p>
        #     <p style="font-size:0.8rem;">Your account password was reset successfully. You can access your account using the following credentials:</p>
        #     <p style="font-size:0.8rem;">   Username: {user_name}</p>
        #     <p style="font-size:0.8rem;">   Password: {password}</p>
        #     <p style="font-size:0.8rem;">Please click the following link to log in and view more details...</p>
        #     <span style="font-size:0.8rem;"><a href="{WEB_URL}" target="_blank">Login</a></span>
        #     <br>
        #     <p style="font-size:0.8rem;">- SE Notification System</p>''' #"http:\\192.168.15.160:8585"
        from_email = EMAIL_HOST_USER
        recipient_list = email
        correspondance_name = 'Password Reset'
        msg = EmailMessage(
            'Password Reset Notification',
            message,
            f'SE Tracker - {correspondance_name} <do_not_reply@solvedge.in>',
            [recipient_list]
        )
        msg.content_subtype ="html"
        msg.send()
    except Exception as e:
        print('password Reset email error: ', str(e))
        return 'password Reset email error'
