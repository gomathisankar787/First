from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import AbstractUser
from tracker.settings import LEAVE_FILE_PATH

# Create your models here.

class UserRole(models.Model):
    class RoleStatus(models.IntegerChoices):
        ADMIN = 1
        BASIC = 2
        STAFF = 3
        MANAGER = 4
    role_name = models.CharField(max_length=250, blank=False, default='', null=True)
    role_desc = models.CharField(max_length=150, default='', null=True, blank=True)
    role_status = models.BooleanField(default=True, null=True, blank=True)

class UserShiftDetails(models.Model):
    shift_name = models.CharField(max_length=400, null=True, blank=True)
    shift_timing_from = models.CharField(max_length=400, null=True, blank=True)
    shift_timing_to = models.CharField(max_length=400, null=True, blank=True)
    status = models.BooleanField(default=True)
    desc = models.CharField(max_length=400, null=True, blank=True)
    order_id = models.IntegerField(null=True,blank=True)
    expected_hours = models.DurationField(null=True, blank=True)

class Department(models.Model):
    name = models.CharField(max_length=250, blank=False, default='', null=True)
    description = models.CharField(max_length=150, default='', null=True, blank=True)
    status = models.BooleanField(default=True, null=True, blank=True)
    is_ticket = models.BooleanField(default=False, null=True, blank=True)
    created = models.DateTimeField(auto_created=True, null=True, blank=True)
    updated = models.DateTimeField(null=True, blank=True)

class User(AbstractUser):
    gender = models.CharField(max_length=1, blank=False, default='M')
    role = models.ForeignKey(UserRole, on_delete=models.CASCADE, default=1)
    user_info = models.TextField(null=True, blank=True)
    pseudo_name = models.CharField(max_length=300, blank=True, null=True)
    timeshtlist_sts = models.BooleanField(default=False)
    shift = models.ForeignKey(UserShiftDetails, on_delete=models.CASCADE, null=True, blank=True)
    shift_frm = models.CharField(max_length=200, null=True, blank=True, default='10:00 AM')
    shift_to = models.CharField(max_length=200, null=True, blank=True, default='7:00 PM')
    timechk_sts = models.BooleanField(null=True, default=False)
    bm_usr_id = models.CharField(max_length=250, null=True, blank=True)
    entry_date = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_on = models.DateTimeField(null=True, blank=True)
    dept = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='user_dept', null=True, blank=True)
    verified_profile = models.BooleanField(default=False, null=True, blank=True)
    
    def __str__(self):
        return self.username

class UserPersonalInformation(models.Model):
    user = models.ForeignKey(User, related_name='rn_user_id', on_delete=models.CASCADE, null=True, blank=True)
    address = models.TextField(blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    alternate_phone_number = models.CharField(max_length=15, blank=True, null=True)
    aadhar_number = models.CharField(max_length=12, unique=True, blank=True, null=True)
    MARITAL_STATUS_CHOICES = [
        ('single', 'Single'),
        ('married', 'Married'),
        ('divorced', 'Divorced'),
        ('widowed', 'Widowed'),
    ]
    marital_status = models.CharField(max_length=10, choices=MARITAL_STATUS_CHOICES, blank=True, null=True)
    spouse_name = models.CharField(max_length=250, blank=True, null=True)
    number_of_children = models.PositiveIntegerField(blank=True, null=True)
    blood_group = models.CharField(max_length=3, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    pan_number = models.CharField(max_length=10, blank=True, null=True)
    insurance_required = models.BooleanField(default=False)
    insurance_provider = models.CharField(max_length=250, blank=True, null=True)
    insurance_policy_number = models.CharField(max_length=250, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class UserChildInformation(models.Model):
    user = models.ForeignKey(UserPersonalInformation, related_name='rn_user_parent_id', on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=250, blank=True, null=True)
    age = models.PositiveIntegerField(default=0, null=True)
    aadhar_number = models.CharField(max_length=12, unique=True, blank=True, null=True)
    pan_number = models.CharField(max_length=10, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    RELATION_TYPE_CHOICES = [
        (0, 'Father'),
        (1, 'Mother'),
        (2, 'Wife'),
        (3, 'Children'),
    ]
    relation_type = models.IntegerField(choices=RELATION_TYPE_CHOICES, blank=True, null=True)

class DeptTlMapper(models.Model):
    dept_info = models.ForeignKey(Department, related_name='rn_dept_id', on_delete=models.CASCADE, null=True, blank=True)
    tl_info = models.ForeignKey(User, related_name='rn_tl_id', on_delete=models.CASCADE, null=True, blank=True)
    tl_gc_info = models.ForeignKey(User, related_name='rn_tl_gc_id', on_delete=models.CASCADE, null=True, blank=True)
    status = models.BooleanField(default=True, blank=True, null=True)
    created = models.DateTimeField(auto_created=True, null=True, blank=True)
    updated = models.DateTimeField(null=True, blank=True)

class NotificationSystem(models.Model):
    schedular_name = models.CharField(max_length=100, null=True)
    cc_list =  models.TextField(null=True)
    to_list = models.TextField(null=True)
    frequency = models.TextField(null=True)
    status = models.BooleanField(default=True)
    is_department_basis = models.BooleanField(default=False, null=True, blank=True)
    order_id = models.IntegerField(null=True, blank=True)
    display_name = models.CharField(max_length=250, null=True)
    is_to_list = models.BooleanField(default=False, null=True, blank=True)
    correspondance_name = models.CharField(max_length=300, null=True, blank=True)

class HolidayList(models.Model):
    holiday_date = models.DateField(null=True)
    holiday = models.CharField(max_length=400, null=True)
    desc = models.CharField(max_length=300)
    status = models.BooleanField(default=True, null=True)
    shift = models.ForeignKey(UserShiftDetails, on_delete=models.CASCADE, related_name='usershiftdetails', default=1, null=True, blank=True)

class LeavePolicyFiles(models.Model):
    file_path = models.FilePathField(path=LEAVE_FILE_PATH, null=True, blank=True)
    file_name = models.CharField(max_length=250, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    created_by = models.ForeignKey(User, related_name='leavefile_user_id', on_delete=models.CASCADE, null=True, blank=True)