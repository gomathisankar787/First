from rest_framework import serializers, validators
from django.db import transaction
from datetime import datetime, timedelta, timezone
import json,os,re
from pathlib import Path
from django.core.files.storage import FileSystemStorage
from django.core.files.base import ContentFile


from .models import *
from workportal.models import BiometricDetails
from tracker.settings import EMAIL_TRIGGER
from tracker.celery import app
from .task_newuser import *
from workportal.models import UserAttandance
from django.db.models import Max, Q, Sum,When,F,Case
from datetime import date
# from .helpers import holiday_info,get_biomet_details,create_usr_attend_entry

# class UserChildInformationSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = UserChildInformation
#         fields = ['name', 'age', 'aadhar_number', 'pan_number', 'date_of_birth','relation_type']
#         # extra_kwargs = {
#         #     'aadhar_number': {'min_length': 12, 'max_length': 12, 'required': False},
#         #     'pan_number': {'required': False}
#         # }


# class UserPersonalInformationSerializer(serializers.ModelSerializer):
#     children = UserChildInformationSerializer(many=True, required=False)

#     class Meta:
#         model = UserPersonalInformation
#         fields = [
#             'address',
#             'phone_number',
#             'alternate_phone_number',
#             'aadhar_number',
#             'marital_status',
#             'spouse_name',
#             'number_of_children',
#             'blood_group',
#             'date_of_birth',
#             'pan_number',
#             'insurance_required',
#             'insurance_provider',
#             'insurance_policy_number',
#             'children'
#         ]
        # extra_kwargs = {
        #     'aadhar_number': {'min_length': 12, 'max_length': 12, 'required': False},
        #     'phone_number': {'required': False,'min_length': 10, 'max_length': 10},
        #     'alternate_phone_number': {'required': False,'min_length': 10, 'max_length': 10},
        #     'number_of_children': {'required': False},
        #     'insurance_required': {'required': False},
        #     'insurance_provider': {'required': False},
        #     'insurance_policy_number': {'required': False},
        # }


class UserRegisterSerializer(serializers.ModelSerializer):
    bio_date_flag = serializers.BooleanField()
    # user_info = UserPersonalInformationSerializer(required=False)
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password', 'first_name', 'last_name', 'role',
            'gender',  'user_info', 'pseudo_name', 'timeshtlist_sts', 'shift', 'dept',
            'shift_frm', 'shift_to', 'bm_usr_id', 'date_joined', 'bio_date_flag')
        extra_kwargs = {
            'password':{'write_only':True},
            'email': {
                'required':True,
                'allow_blank':False,
                'validators':[
                    validators.UniqueValidator(
                        User.objects.all(), 'A user already registered with given email!'
                    )
                ]
            },
            'username': {
                'required':True,
                'allow_blank':False,
                'validators':[
                    validators.UniqueValidator(
                        User.objects.all(), 'A user already registered with given username!'
                    )
                ]
            }
        }

    def create(self, validated_data):
        password = validated_data['password']
        # user_info_data = validated_data.pop('user_info', None)
        shiftfrom = validated_data['shift_frm'].split(' ')[-1]
        shiftto = validated_data['shift_to'].split(' ')[-1]
        if shiftfrom == 'PM' and shiftto == 'AM':
            timechk_sts = True
        else:
            timechk_sts = False
        user = User(
            username = validated_data['username'],
            email = validated_data['email'],
            first_name = validated_data['first_name'],
            last_name = validated_data['last_name'],
            role = validated_data['role'],
            gender = validated_data['gender'],
            # user_info = validated_data['user_info'],
            pseudo_name = validated_data['pseudo_name'],
            timeshtlist_sts = validated_data['timeshtlist_sts'],
            shift = validated_data['shift'],
            shift_frm = validated_data['shift_frm'],
            shift_to = validated_data['shift_to'],
            timechk_sts = timechk_sts,
            bm_usr_id = validated_data['bm_usr_id'],
            date_joined = validated_data['date_joined'],
            dept = validated_data['dept']
        )
        user.set_password(password)
        user.save()

        # Save personal info if available
        # if user_info_data:
        #     children_data = user_info_data.pop('children', [])
        #     personal_info, _ = UserPersonalInformation.objects.update_or_create(
        #         user=user,
        #         defaults=user_info_data
        #     )

        #     # Clear existing children and recreate
        #     UserChildInformation.objects.filter(user=personal_info).delete()
        #     for child in children_data:
        #         UserChildInformation.objects.create(user=personal_info, **child)

        if EMAIL_TRIGGER:
            try:
                result = app.control.broadcast('ping', reply=True, limit=1)
                if result:
                    trans_data = {}
                    trans_data['username'] = validated_data['username']
                    trans_data['email'] = validated_data['email']
                    trans_data['first_name'] = validated_data['first_name']
                    trans_data['last_name'] = validated_data['last_name']
                    trans_data['password'] = validated_data['password']
                    send_newuser_email.delay(trans_data)
                else:
                    print('Celery process not responding')
            except Exception as e:
                print('Allocation email error',e) 
        print(validated_data['bio_date_flag'], 'bio_date_flag')

        try:
            if validated_data['bio_date_flag'] == True: 
                usr_data = User.objects.filter(first_name=validated_data['first_name'], last_name=validated_data['last_name']).values('id', 'bm_usr_id', 'entry_date', 'date_joined')
                for data in usr_data:
                    biomet_id = data['bm_usr_id']
                    user_id = data['id']
                biomet_update = BiometricDetails.objects.filter(bio_id=biomet_id, user_id__isnull=True)
                if biomet_update.exists():
                    biomet_update.update(user_id=user_id)
                else:
                    print('No data found')
                biomet_updated = BiometricDetails.objects.filter(bio_id=biomet_id, user_id=user_id)
                if biomet_updated.exists():
                    for data in usr_data:
                        user_joined_date = data['date_joined']
                    today = datetime.now().date()
                    req_date = date(2024, 6, 1)
                    if user_joined_date.date() == today:
                        print('No need to update attendance details')
                    if user_joined_date.date() > req_date:
                        req_date = user_joined_date.date()
                    attendance_data = get_attendance_report_data(biomet_id,user_id,req_date)
                else:
                    print('Attendance details is not updated for corresponded user')
            else:
                print('bio_date_flag:', validated_data['bio_date_flag'])
        except Exception as e:
            print('BiometricDetails Error:', str(e))
        return user


def get_attendance_report_data(biomet_id, user_id, req_date):
    try:
        # req_date = date(req_date.year, req_date.month, req_date.date)
        print('rea',req_date)
        end_date = datetime.now() - timedelta(days=1)
        holiday_data = holiday_info(req_date=req_date, end_date=end_date)
        biomet_info = get_biomet_details(req_date=req_date, end_date=end_date, holiday_data=holiday_data,user_id = user_id,bio_id=biomet_id)
        attandance_data = create_usr_attend_entry(biomet_info)
        return 'Attendance Report updated successfuly'
    except Exception as e:
        print('UserAttendReport error:', str(e))

def create_usr_attend_entry(user_bio_info):
        # print(user_bio_info, 'user_bio_info')
        updated_list = []
        for user_data in user_bio_info:
            if 'data' in user_data:
                for attendance in user_data['data']:
                    bio_diff = cal_hrs_diff(attendance)
                    attend_obj = UserAttandance(
                        None,
                        month = attendance['process_date'],
                        user_id = attendance['user'],
                        tot_hrs = attendance['tot_hrs'],
                        tot_leaves = attendance['abs_count'],
                        hrs_diff = bio_diff,
                        is_joined_month = attendance['is_joinded'],
                        leave_dates = attendance['abs_date'],
                        tot_work_days = attendance['total_work_days'],
                        woh_dates = attendance['woh_date'],
                        woh_tot_hrs = attendance['woh_hrs'] if attendance['woh_hrs'] > 0 else None
                    )
                    updated_list.append(attend_obj)
        with transaction.atomic():
            if updated_list:
                usr_attend_create = UserAttandance.objects.bulk_create(
                    objs=updated_list, 
                    update_conflicts= True, 
                    update_fields=['tot_hrs', 'tot_leaves', 'hrs_diff', 'leave_dates', 'tot_work_days', 'woh_dates', 'woh_tot_hrs'],
                    unique_fields=['user_id', 'month'])

def cal_hrs_diff(req_info):
        work_days = 0
        work_days = req_info['total_work_days'] - req_info['abs_count']
        bio_diff = 0
        if work_days:
            if req_info['user__shift_id'] in [1, 2]:
                bio_diff = (work_days * 510) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
            elif req_info['user__shift_id'] == 3:
                bio_diff = (work_days * 480) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
        return bio_diff

def holiday_info(req_date, end_date):
        """Returns requested month's shift vise Solvedge holiday list
        day_holiday_list, mid_holiday_list, ngt_holiday_list
        """
        day_holiday_list = []
        mid_holiday_list = []
        ngt_holiday_list = []
        holiday_qry = HolidayList.objects.filter(
            holiday_date__year__range=[req_date.year, end_date.year], status=True)
        if holiday_qry.exists():
            for holiday in holiday_qry:
                if holiday.shift_id == 1:
                    day_holiday_list.append(holiday.holiday_date)
                elif holiday.shift_id == 2:
                    mid_holiday_list.append(holiday.holiday_date)
                else:
                    ngt_holiday_list.append(holiday.holiday_date)
        # print(day_holiday_list, 'day_holiday_list',
        #         mid_holiday_list, 'mid_holiday_list',
        #         ngt_holiday_list, 'ngt_holiday_list')
        return day_holiday_list, mid_holiday_list, ngt_holiday_list

def get_biomet_details(req_date, end_date, holiday_data, user_id, bio_id):
        out_data = []
        biomet_data = BiometricDetails.objects.values('user',
            'process_date__month', 'process_date__year', 'user__shift_id').filter(
            user_id=user_id, bio_id=bio_id, process_date__range=[req_date, end_date]).annotate(
            tot_hrs=Sum('work_time'), joined_date=F('user__date_joined'),
            is_joinded=Case(When(
                Q(user__date_joined__year=F('process_date__year')) & Q(user__date_joined__month=F('process_date__month')), 
                then=True), default=False)
                ).order_by('user_id', 'process_date__year', 'process_date__month')
        print(biomet_data, 'biomet_data')
        biomet_absent = get_absent_info(req_date, end_date, holiday_data, user_id, bio_id)
        woh_data = work_holiday_data(req_date, end_date, holiday_data, user_id, bio_id)
        user_bio_info = {}
        for bio_info in biomet_data:
            process_date = date(bio_info['process_date__year'], bio_info['process_date__month'], 1)
            if bio_info['is_joinded']:
                new_join = score_wrk_day(bio_info['joined_date'].strftime("%Y-%m-%d"))
                if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                    new_join = get_cur_mon_work_day(new_join)
            else:
                new_join = score_wrk_day(process_date.strftime("%Y-%m-%d"))
                if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                    new_join = get_cur_mon_work_day(new_join)
            # print('user_id: ', bio_info['user'])
            # print('new_join: ', new_join)
            tot_work_days = get_tot_work_days(new_join[0], holiday_data, bio_info['user__shift_id'], process_date)
            bio_info['process_date'] = process_date
            bio_info['abs_count'] = 0
            bio_info['abs_date'] = []
            bio_info['woh_date'] = []
            bio_info['woh_hrs'] = 0
            bio_info['total_work_days'] = tot_work_days
            temp_dict = {}
            if bio_info['user'] in user_bio_info:
                user_bio_info[bio_info['user']]['data'].append(bio_info)
            else:
                user_bio_info[bio_info['user']] = temp_dict
                temp_dict['user_id'] = bio_info['user']
                temp_dict['data'] = [bio_info]
        if biomet_absent:
            for abs_data in biomet_absent:
                if abs_data['user'] in user_bio_info:
                    usr_info = user_bio_info[abs_data['user']]
                    # print(usr_info, 'usr_info')
                    user_data = get_abs_count(usr_info['data'], abs_data)
                    usr_info['data'] = user_data
        if woh_data:
            for woh_details in woh_data:
                if woh_details['user'] in user_bio_info:
                    usr_old_info = user_bio_info[woh_details['user']]
                    user_upd_data = get_woh_method(usr_old_info['data'], woh_details)
                    usr_old_info['data'] = user_upd_data
        for bio_info in user_bio_info:
            out_data.append(user_bio_info[bio_info])
        return out_data

def get_absent_info(req_date, end_date, holiday_data, user_id, bio_id):
        week_day_sun = 1
        week_day_sat = 7
        biomet_absent = BiometricDetails.objects.select_related('user').filter(
            Q(work_time_hhmm=None)|Q(work_time=0), user_id = user_id, bio_id = bio_id,
            process_date__week_day__gt=week_day_sun, process_date__week_day__lt=week_day_sat,
            process_date__range=[req_date, end_date]).values('user',
            'process_date', 'user__shift_id').order_by('user_id')
        biomet_absent = list(biomet_absent)
        for abs_data in list(biomet_absent):
            if abs_data['user__shift_id'] == 1:
                if abs_data['process_date'] in holiday_data[0]:
                    biomet_absent.remove(abs_data)
            elif abs_data['user__shift_id'] == 2:
                if abs_data['process_date'] in holiday_data[1]:
                    biomet_absent.remove(abs_data)
            elif abs_data['user__shift_id'] == 3:
                if abs_data['process_date'] in holiday_data[2]:
                    biomet_absent.remove(abs_data)
        return biomet_absent

def get_woh_method(old_data, woh_data):
        # print(abs_data, 'abs_data')
        for bio_data in old_data:
            # print(bio_data, 'bio_data')
            if bio_data['process_date__month'] == woh_data['process_date'].month and bio_data['process_date__year'] == woh_data['process_date'].year:
                bio_data['tot_hrs'] -= int(woh_data['work_time'])
                bio_data['woh_hrs'] += int(woh_data['work_time'])
                bio_data['woh_date'].append(woh_data['process_date'].day)
                # bio_data['woh_date'].append(f"{woh_data['process_date'].day}:{woh_data['work_time']}")
        return old_data

def get_abs_count(data, abs_data):
        # print(abs_data, 'abs_data')
        for bio_data in data:
            # print(bio_data, 'bio_data')
            if bio_data['process_date__month'] == abs_data['process_date'].month and bio_data['process_date__year'] == abs_data['process_date'].year:
                bio_data['abs_count'] += 1
                bio_data['abs_date'].append(abs_data['process_date'].day)
        return data

def get_tot_work_days(tot_work_days, holiday_data, shift_id, process_date):
        if shift_id == 1:
            for holi_date in holiday_data[0]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        elif shift_id == 2:
            for holi_date in holiday_data[1]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        elif shift_id == 3:
            for holi_date in holiday_data[2]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        return tot_work_days

def get_cur_mon_work_day(work_days_list):
        print(work_days_list, 'work_days_list')
        work_day_count = 0
        new_list = []
        for work_days in work_days_list[1]:
            if work_days < datetime.now().date():
                work_day_count+=1
                new_list.append(work_days)
        return work_day_count, new_list

def work_holiday_data(req_date, end_date, holiday_data, user_id, bio_id):
        holiday_list = list(set(holiday_data[0] + holiday_data[1] + holiday_data[2]))
        week_day_sun = 1
        week_day_sat = 7
        woh_info = BiometricDetails.objects.select_related('user').filter(
            Q(process_date__week_day__in=[week_day_sat, week_day_sun])|Q(process_date__in=holiday_list),
            work_time__gt=0, user_id = user_id, bio_id= bio_id, process_date__range=[req_date, end_date]
            ).values('user', 'process_date', 'user__shift_id', 'work_time').order_by('user_id')
        # print(list(woh_info), 'woh_infowoh_info')
        return woh_info

def score_wrk_day(request):
    """To calculate workday count & workday date list from given date string

    :Parameters

    request - date string

    :Result

    returns workday count & workday date list
    """
    req_date = request#'2022-12-05'
    req_date = datetime.strptime(req_date, "%Y-%m-%d")
    join_date = int(req_date.strftime('%d'))
    # print(join_date, type(join_date), 'join_dateeeee')
    holiday_list = []
    businessdays = 0
    businessdays_list = []
    for i in range(join_date, 32):
        try:
            thisdate = date(req_date.year, req_date.month, i)
        except(ValueError):
            break
        if thisdate.weekday() < 5 and thisdate not in holiday_list: # Monday == 0, Sunday == 6 
            businessdays_list.append(thisdate)
            businessdays += 1
    return (businessdays, businessdays_list)

class UserUpdateSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()
    pwd_flag = serializers.BooleanField(default=False)
    bio_date_flag = serializers.BooleanField()
    # user_info = UserPersonalInformationSerializer(required=False)
    # user_info = serializers.DictField(write_only=True, required=False)
    # children = serializers.ListField(child=serializers.DictField(), write_only=True, required=False)
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password', 'first_name',
            'last_name', 'role', 'gender', 'dept', 'user_info', 'pwd_flag',
            'pseudo_name', 'timeshtlist_sts', 'shift', 'shift_frm',
            'shift_to', 'bm_usr_id', 'bio_date_flag')

        extra_kwargs = {
            'password':{'write_only':True, 'allow_blank':True},
            'email': {
                'required':False,
                'allow_blank':True,
                'validators':[
                    validators.UniqueValidator(
                        User.objects.all(), 'A user already registered with given email!'
                    )
                ]
            },
            'username': {
                'required':True,
                'allow_blank':False,
                'validators':[
                    validators.UniqueValidator(
                        User.objects.all(), 'A user already registered with given username!'
                    )
                ]
            }
        }

    def update(self, instance, validated_data):
        shiftfrom = validated_data['shift_frm'].split(' ')[-1]
        shiftto = validated_data['shift_to'].split(' ')[-1]
        # user_info_data = validated_data.pop('user_info', None)
        # children_data = user_info_data.pop('children', [])
        if shiftfrom == 'PM' and shiftto == 'AM':
            timechk_sts = True
        else:
            timechk_sts = False
        password = validated_data['password']
        #update portion   
        with transaction.atomic():
            instance.username = validated_data['username']
            instance.email = validated_data['email']
            instance.first_name = validated_data['first_name']
            instance.last_name = validated_data['last_name']
            instance.role = validated_data['role']
            instance.gender = validated_data['gender']
            instance.user_info = validated_data['user_info']
            instance.pseudo_name = validated_data['pseudo_name']
            instance.timeshtlist_sts = validated_data['timeshtlist_sts']
            instance.shift = validated_data['shift']
            instance.shift_frm = validated_data['shift_frm']
            instance.shift_to = validated_data['shift_to']
            instance.bm_usr_id = validated_data['bm_usr_id']
            instance.timechk_sts = timechk_sts
            instance.dept = validated_data['dept']
            if validated_data['pwd_flag'] == True:
                instance.set_password(password) 
            instance.save()
            # if user_info_data:
            #     UserPersonalInformation.objects.update_or_create(
            #         user=instance,
            #         defaults=user_info_data
            #     )

            # # Update children info
            # if children_data is not None:
            #     # Remove existing children (optional, depending on requirements)
            #     UserChildInformation.objects.filter(user=user_info_data).delete()
            #     # Create new children records
            #     for child in children_data:
            #         UserChildInformation.objects.create(user=user_info_data, **child)
            try:
                if validated_data['bio_date_flag'] == True: 
                    usr_data = User.objects.filter(first_name=validated_data['first_name'], last_name=validated_data['last_name']).values('id', 'bm_usr_id', 'entry_date', 'date_joined')
                    for data in usr_data:
                        biomet_id = data['bm_usr_id']
                        user_id = data['id']
                    biomet_update = BiometricDetails.objects.filter(bio_id=biomet_id, user_id__isnull=True)
                    if biomet_update.exists():
                        biomet_update.update(user_id=user_id)
                    else:
                        print('No data found')
                else:
                    print('bio_date_flag:', validated_data['bio_date_flag'])
            except Exception as e:
                print('BiometricDetails Error:', str(e))

            notifications = NotificationSystem.objects.all()
            department = Department.objects.filter(id=validated_data['dept'].id).first()
            department_name = department.name

            for notification in notifications:
                # Handle cc_list
                try:
                    cc_list = json.loads(notification.cc_list) if notification.cc_list else []
                except json.JSONDecodeError:
                    try:
                        cc_list = ast.literal_eval(notification.cc_list) if notification.cc_list else []
                    except (ValueError, SyntaxError):
                        return [], False

                cc_updated = False
                for entry in cc_list:
                    if entry.get('usr_id') == instance.id:
                        if (entry.get('email') != validated_data['email'] or
                            entry.get('department') != department_name or
                            entry.get('name') != f"{validated_data['first_name']} {validated_data['last_name']}"):
                            entry.update({
                                'email': validated_data['email'],
                                'department': department_name,
                                'name': f"{validated_data['first_name']} {validated_data['last_name']}"
                            })
                            cc_updated = True

                if cc_updated:
                    notification.cc_list = json.dumps(cc_list)

                # Handle to_list
                if notification.is_to_list:
                    try:
                        to_list = json.loads(notification.to_list) if notification.to_list else []
                    except json.JSONDecodeError:
                        try:
                            to_list = ast.literal_eval(notification.to_list) if notification.to_list else []
                        except (ValueError, SyntaxError):
                            return [], False

                    to_updated = False
                    for entry in to_list:
                        if entry.get('usr_id') == instance.id:
                            if (entry.get('email') != validated_data['email'] or
                                entry.get('department') != department_name or
                                entry.get('name') != f"{validated_data['first_name']} {validated_data['last_name']}"):
                                entry.update({
                                    'email': validated_data['email'],
                                    'department': department_name,
                                    'name': f"{validated_data['first_name']} {validated_data['last_name']}"
                                })
                                to_updated = True

                    if to_updated:
                        notification.to_list = json.dumps(to_list)

                notification.save()

            if validated_data['pwd_flag']:
                if EMAIL_TRIGGER:
                    try:
                        result = app.control.broadcast('ping', reply=True, limit=1)
                        if result:
                            trans_data = {}
                            trans_data['username'] = validated_data['username']
                            trans_data['email'] = validated_data['email']
                            trans_data['first_name'] = validated_data['first_name']
                            trans_data['last_name'] = validated_data['last_name']
                            trans_data['password'] = validated_data['password']
                            send_user_pwd_reset_email.delay(trans_data)
                        else:
                            print('Celery process not responding')
                    except Exception as e:
                        print('Allocation email error',e) 
        return instance

class PasswordEncSerializer(serializers.Serializer):
    password = serializers.CharField()

class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = ('id', 'role_name', 'role_status')

class DeptCreateSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = Department
        fields = "__all__"
        extra_kwargs = {
            'created': {'required': False},
            'updated': {'required': False}
        }

    def create(self, validated_data):
        dept_obj = Department.objects.create(
            name = validated_data['name'],
            description = validated_data['description'],
            status = True,
            is_ticket = validated_data['is_ticket'],
            created = datetime.now(timezone.utc)
        )
        return dept_obj

    def update(self, instance, validated_data):
        with transaction.atomic():
            instance.name = validated_data['name']
            instance.description = validated_data['description']
            instance.status = validated_data['status']
            instance.is_ticket = validated_data['is_ticket']
            instance.updated = datetime.now(timezone.utc)
            instance.save()
        return instance

class DeptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'

class HolidaySerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    shift = serializers.ListField(
        child=serializers.IntegerField()
    )
    class Meta:
        model = HolidayList
        fields = '__all__'

    def create(self,validated_data):
        if validated_data['shift'] == []:
            shift_data = UserShiftDetails.objects.all()
            holiday = []
            for shift in shift_data:
                holiday_list = HolidayList(None,
                holiday_date = validated_data['holiday_date'],
                holiday = validated_data['holiday'],
                desc = validated_data['desc'],
                status = validated_data['status'],
                shift = shift
                )
                holiday.append(holiday_list)
            holiday_data = HolidayList.objects.bulk_create(holiday)
        else:
            shift_data = UserShiftDetails.objects.filter(id__in=(validated_data['shift']))
            holiday = []
            for shift in shift_data:
                holiday_list = HolidayList(None,
                holiday_date = validated_data['holiday_date'],
                holiday = validated_data['holiday'],
                desc = validated_data['desc'],
                status = validated_data['status'],
                shift = shift
                )
                holiday.append(holiday_list)
            holiday_data = HolidayList.objects.bulk_create(holiday)
        return holiday_data

    def update(self,instance,validated_date):
        shift_data = UserShiftDetails.objects.filter(id__in=(validated_date['shift']))
        for shift in shift_data:
            with transaction.atomic():
                instance.holiday_date = validated_date['holiday_date']
                instance.holiday = validated_date['holiday']
                instance.desc = validated_date['desc']
                instance.status = validated_date['status']
                instance.shift = shift
                instance.save()
        return instance

class HolidayListserializer(serializers.ModelSerializer):
    class Meta:
        model = HolidayList
        fields = "__all__"

class HolidayactdeactSerializer(serializers.Serializer):
    id = serializers.IntegerField()

class YearlyHolidayListSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    shift_id = serializers.IntegerField()

class GetUserBiometDetailsSerializer(serializers.Serializer):
    user_creation_flag = serializers.BooleanField()

class FirstBiometSerializer(serializers.Serializer):
    biomet_id = serializers.CharField()

class UserIdSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()

class NotifSysUpdateSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()
    class Meta:
        model = NotificationSystem
        fields =('id', 'status', 'cc_list', 'status', 'to_list', 'correspondance_name')

    def update(self,instance,validated_date):
        with transaction.atomic():
            # print(validated_date, 'validated_date')
            instance.cc_list = validated_date['cc_list']
            instance.status = validated_date['status']
            instance.to_list = validated_date['to_list']
            instance.correspondance_name = validated_date['correspondance_name']
            instance.save()
        return instance

class NotifSystemUpdateserializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationSystem
        fields = '__all__'

class TimeshtListActDeactSerializer(serializers.Serializer):
    usr_id = serializers.IntegerField()

class UserObjSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'is_active', 'email')

class DeptUserSerializer(serializers.ModelSerializer):
    user_info = UserObjSerializer(many=True, source='user_dept')
    class Meta:
        model = Department
        fields = '__all__'

class TknUsrInfoSerializer(serializers.Serializer):
    token = serializers.CharField()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class UpdProfileByUserSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()
    pwd_flag = serializers.BooleanField()
    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'user_info', 'gender', 'password', 'pwd_flag')
        extra_kwargs = {
            'password': {'write_only':True, 'allow_blank':True}
        }

    def update(self, instance, validated_data):
        password = validated_data['password']
        with transaction.atomic():
            instance.user_info = validated_data['user_info']
            instance.gender = validated_data['gender']
            instance.first_name = validated_data['first_name']
            instance.last_name = validated_data['last_name']
            instance.verified_profile = True if instance.verified_profile == False else instance.verified_profile
            if validated_data['pwd_flag'] == True:
                instance.set_password(password)
            instance.save()
        return instance

class UserListByIdSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()

def clean_name(name):
        """Remove special characters except spaces and underscores, and replace spaces with underscores."""
        name = re.sub(r'[^a-zA-Z0-9 _]', '', name)
        return name.replace(" ", "_").lower()

class DocFileUploadSerializer(serializers.Serializer):
    doc_file = serializers.FileField(required=True)

    def create(self, validated_data):
        file_path = ''
        file_name = ''
        file_content = validated_data.get('doc_file', None)

        with transaction.atomic():
            if file_content:
                date_object = datetime.now().date()
                year = str(date_object.year)
                month = str(date_object.month)
                day = str(date_object.day)

                relative_path = os.path.join(year, month, day)
                file_path = os.path.join(LEAVE_FILE_PATH, relative_path)
                Path(file_path).mkdir(parents=True, exist_ok=True)

                # Active folder path
                active_path = os.path.join(LEAVE_FILE_PATH, 'Active File')
                Path(active_path).mkdir(parents=True, exist_ok=True)

                raw_file_name, file_ext = os.path.splitext(file_content.name)
                user_id = self.context['user_id'] #validated_data['created_by']

                cleaned_file_name = clean_name(raw_file_name)
                file_name = f"{cleaned_file_name}{file_ext}"
            ticket = LeavePolicyFiles(
            file_path=relative_path if file_content else '',
            file_name=file_name if file_content else '',
            created_by_id= user_id
            )
            ticket.save()
        if file_content:
                fs = FileSystemStorage(location=file_path)
                fs.save(file_name, ContentFile(file_content.read()))

                # Clear old file(s) in active folder
                for old_file in os.listdir(active_path):
                    old_file_path = os.path.join(active_path, old_file)
                    if os.path.isfile(old_file_path):
                        os.remove(old_file_path)

                # Save the latest file in active folder
                fs_active = FileSystemStorage(location=active_path)
                file_content.seek(0)  # Reset pointer to start
                fs_active.save(file_name, ContentFile(file_content.read()))
        return ticket

class DocFileUploadDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = LeavePolicyFiles
        fields = '__all__'

class LeavePolicyFileDownloadSerializer(serializers.Serializer):
    file_id = serializers.IntegerField()