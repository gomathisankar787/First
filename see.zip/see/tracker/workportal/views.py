from operator import getitem
from django.shortcuts import render
from django.db.models import Value, BooleanField, F, CharField, Q, Count, Max, Avg
from django.db.models.functions import Concat
from django.db import connections
from openpyxl import Workbook
from rest_framework import generics, status
from rest_framework.response import Response
from django.http import HttpResponse
from rest_framework.decorators import api_view, permission_classes
from datetime import datetime, date,timedelta
import calendar
from knox.models import AuthToken
# import pytz
# time_zone = pytz.timezone('Asia/Kolkata')
from zoneinfo import ZoneInfo
from django.db.models import F, Case, When, Value, ExpressionWrapper, DurationField
import datetime


from drf_yasg.utils import swagger_auto_schema
import logging
logger = logging.getLogger(__name__)
from openpyxl.workbook.protection import WorkbookProtection
from openpyxl.worksheet.dimensions import ColumnDimension, DimensionHolder
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.styles.borders import Border, Side


from .models import *
from authapi.models import HolidayList
from .serializers import *
from tracker.tasks_status import *
from tracker.celery import app
from tracker.custom_permissions import IsAdmin, IsBasicUser,IsManager
from tracker.settings import EMAIL_TRIGGER, EMAIL_HOST_USER
from tracker.dx_datagrid import DxModelViewSet, DxAPIView, DxModelViewSetQuery

# Create your views here.

class ProjectList(generics.GenericAPIView):
    def get(self, request):
        try:
            out_list = []
            pro_list = Projects.objects.all().filter(Q(order_id__gte=0)|Q(order_id__isnull=True)).select_related('department').values().annotate(department_name=F('department__name')).order_by('order_id')
            last_list = Projects.objects.all().filter(order_id__lt=0).values().order_by('order_id')
            for proj in pro_list:
                out_list.append(proj)
            for la_proj in last_list:
                out_list.append(la_proj)
            return Response(out_list, status=status.HTTP_200_OK)
        except Exception as e:
            print('Projects list error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ActProjectList(generics.GenericAPIView):
    def get(self, request):
        try:
            out_list = []
            pro_list = Projects.objects.all().filter(Q(order_id__gte=0)|Q(order_id__isnull=True), status=True).values().order_by('order_id')
            last_list = Projects.objects.all().filter(order_id__lt=0, status=True).values().order_by('order_id')
            for proj in pro_list:
                out_list.append(proj)
            for la_proj in last_list:
                out_list.append(la_proj)
            return Response(out_list, status=status.HTTP_200_OK)
        except Exception as e:
            print('ActProjectList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ActiveProjectList(generics.GenericAPIView):
    @swagger_auto_schema(request_body=ActiveProjectAndUserListSerializer)
    def post(self, request):
        try:
            user_dept = request.user.dept_id
            show_all_flag = request.data.get('is_show_all')
            filter = {'status':True}
            if show_all_flag:
                filter['department_id'] = user_dept
            project_filter = Projects.objects.filter(**filter).values()
            # serializer = ProjectObjSerializer(project_filter)
            return Response(project_filter, status=status.HTTP_200_OK)
        except Exception as e:
            print('ActProjectandUserList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ActiveUserList(generics.GenericAPIView):
    @swagger_auto_schema(request_body=ActiveProjectAndUserListSerializer)
    def post(self, request):
        try:
            user_dept = request.user.dept_id
            show_all_flag = request.data.get('is_show_all')
            filter = {'is_active':True}
            if show_all_flag:
                filter['dept_id'] = user_dept
            user_filter = User.objects.filter(**filter).values('id', 'first_name', 'last_name', 'is_active', 'email')
            # serializer = UserObjSerializer(user_filter)
            return Response(user_filter, status=status.HTTP_200_OK)
        except Exception as e:
            print('ActProjectandUserList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CreateProject(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=CreateProjectSerializer)
    def post(self, request):
        try:
            serializer = CreateProjectSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            serializer_obj = serializer.save()
            out_data = projectListSerializer(serializer_obj).data
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print("Create Project error: ", str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UpdateProject(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=CreateProjectSerializer)
    def post(self, request):
        try:
            proj_instance = Projects.objects.get(pk=request.data['id'])
            if proj_instance:
                serializer = CreateProjectSerializer(instance=proj_instance, data=request.data)
                serializer.is_valid(raise_exception=True)
                serializer_obj = serializer.save()
                out_data = projectListSerializer(serializer_obj).data
            else:
                raise Exception('No data found to update!')
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print("Create Project error: ", str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def get_last_three_date(user_id):
    task_date_list = ProdTimeSheet.objects.values('task_date').filter(user_id=user_id).annotate(
        d_count=Count('id')).order_by('-task_date').values('task_date')[:3]
    date_list = []
    if task_date_list:
        for data in task_date_list:
            date_list.append(data['task_date'])
    return date_list

def timesheet_permission(request, prodtimesheet_info, today, upd_flag):
    try:
        req_sta_dte = request['task_date']
        # allowingdate = 3
        req_sta_dte = datetime.strptime(req_sta_dte, "%Y-%m-%d")
        if today.date() == req_sta_dte.date():
            return True, {"Invalid Request": 'Date is Today'}
        elif today.date() < req_sta_dte.date():
            return False, {"Invalid task date - EC038": "Kindly contact your Administrator. Future date You can't add."}
        else:
            if prodtimesheet_info:
                db_st_date = prodtimesheet_info[0]['task_date']
            else:
                db_st_date = req_sta_dte.date()
            if db_st_date == req_sta_dte.date():
                return True, {'msg': 'Success'}
                # previous_date = db_st_date + timedelta(days=allowingdate)
                # # print(previous_date, "previous_date")
                # if today.date() <= previous_date:
                #     return True, {'msg': 'success'}
                # else:
                #     print("inner else")
                #     print({"Invalid task date": "Kindly contact your Administrator to add/edit this task. You can only add/edit today's or previous date task entry."})
                #     return False, {"Invalid task date - EC028": "Kindly contact your Administrator to add/edit this task. You can only add/edit today or previous date task entry."}
            else:
                return False, {"Invalid task date - EC018": " Kindly contact your Administrator to add/edit this task. You can only add/edit today's or previous task entry."}
    except Exception as e:
        print('timesheet_permission error: ', str(e))
        return False, str(e)

class CreateTask(generics.GenericAPIView):
    @swagger_auto_schema(request_body=CreateTaskSerializer)
    def post(self, request):
        try:
            request.data['task_date'] = datetime.now().date().strftime('%Y-%m-%d')
            if datetime.strptime(request.data['start_date'], "%Y-%m-%d") > datetime.strptime(request.data['end_date'], "%Y-%m-%d"):
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Date Info": "Startdate is always less than enddate. Please check your startdate"}, status=status.HTTP_400_BAD_REQUEST)
            try:
                usr_info = User.objects.get(id=request.user.id)
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Not Found": "User Id not found"},status=status.HTTP_400_BAD_REQUEST)
            # dt_time = datetime.now(time_zone)
            dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
            today_date = dt_time.strftime("%Y-%m-%d")
            today_date = datetime.strptime(today_date,"%Y-%m-%d")
            am_pm =dt_time.strftime('%p')
            if usr_info.timechk_sts:
                if am_pm == "PM":
                    prodtimesheet_info = ProdTimeSheet.objects.filter(
                        user=request.data['user'], task_date__lt=today_date
                        ).values('task_date','id').order_by('-task_date')[:1]
                else:
                    today_date = today_date-timedelta(days=1)
                    prodtimesheet_info = ProdTimeSheet.objects.filter(
                        user=request.data['user'], task_date__lt=today_date
                        ).values('task_date','id').order_by('-task_date')[:1]
            else:
                prodtimesheet_info = ProdTimeSheet.objects.filter(
                    user=request.data['user'], task_date__lt=today_date
                    ).values('task_date','id').order_by('-task_date')[:1]
            request1=request.data
            timesht_access, val_message = timesheet_permission(request1, prodtimesheet_info, today_date, upd_flag=False)
            if timesht_access:
                serializer = CreateTaskSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                try:
                    task_obj = serializer.save()
                    out_data = TaskSerializer(task_obj).data
                    return Response(out_data, status=status.HTTP_200_OK)
                except Exception as e:
                    logger.warning(f": Bad Request: {request.path}: {request.data}")        
                    return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)
            else:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                # return Response(val_message, status=status.HTTP_400_BAD_REQUEST)
                return Response('Add timesheet error!', status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('CreateTask Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class EditTimeSheet(generics.GenericAPIView):
    @swagger_auto_schema(request_body=CreateTaskSerializer)
    def post(self, request):
        if datetime.strptime(request.data['start_date'], "%Y-%m-%d") > datetime.strptime(request.data['end_date'],"%Y-%m-%d"):
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Date Info": "Startdate is always less than enddate. Please check your startdate"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            usr_info = User.objects.get(id=request.user.id)
            request.data['user'] = request.user.id
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Not Found": "Id not found"}, status=status.HTTP_400_BAD_REQUEST)
        # dt_time = datetime.now(time_zone)
        dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        today_date = dt_time.strftime("%Y-%m-%d")
        today_date = datetime.strptime(today_date, "%Y-%m-%d")
        am_pm = dt_time.strftime('%p')
        if usr_info.timechk_sts:
            if am_pm == "PM":
                prodtimesheet_info = ProdTimeSheet.objects.filter(
                    user=request.data['user'], task_date__lt=today_date
                    ).values('task_date', 'id').order_by('-task_date')[:1]
            else:
                today_date = today_date-timedelta(days=1)
                prodtimesheet_info = ProdTimeSheet.objects.filter(
                    user=request.data['user'], task_date__lt=today_date
                    ).values('task_date', 'id').order_by('-task_date')[:1]
        else:
            prodtimesheet_info = ProdTimeSheet.objects.filter(
                user=request.data['user'], task_date__lt=today_date
                ).values('task_date', 'id').order_by('-task_date')[:1]
        request1 = request.data
        timesht_access, val_message = timesheet_permission(request1, prodtimesheet_info, today_date, upd_flag=True)
        if timesht_access:
            try:
                prodtimesht_edit = ProdTimeSheet.objects.get(id=request.data['id'])
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"ProdTimesheet id not found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
            serializer = CreateTaskSerializer(instance=prodtimesht_edit, data=request.data)
            serializer.is_valid(raise_exception=True)
            try:
                task_obj = serializer.save()
                out_data = TaskSerializer(task_obj).data
                return Response(out_data, status=status.HTTP_200_OK)
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")   
                return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            # return Response(val_message, status=status.HTTP_400_BAD_REQUEST)
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

def prv_edit_permission(req_date, prv_date_list):
    if req_date in prv_date_list:
        return True, 'Success'
    else:
        return False, "Can't edit. Contact your Administrator."
    '''allowingdate = 3
    today = date.today()
    if today == req_date:
        return True, 'Date is Today'
    elif today < req_date:
        print('feature date')
        return False, "Future date You can't add.Contact your Administrator."
    else:
        previous_date = req_date + timedelta(days=allowingdate)
        if today <= previous_date:
            return True, 'Success'
        else:
            return False, "Can't edit.Contact your Administrator."'''

class TodaytimesheetList(generics.GenericAPIView):
    @swagger_auto_schema(request_body=TodaytimesheetListSerializer)
    def post(self,request):
        try:
            usr_info = User.objects.get(id=request.data['user_id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Not Found": "Id not found"}, status=status.HTTP_400_BAD_REQUEST)
        # dt_time = datetime.now(time_zone)
        dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        today_date = dt_time.strftime("%Y-%m-%d")
        today_date = datetime.strptime(today_date, "%Y-%m-%d")
        am_pm =dt_time.strftime('%p')
        if usr_info.timechk_sts:
            if am_pm == "PM":
                prodtimesht_list = ProdTimeSheet.objects.filter(
                    user_id=request.data['user_id'], task_date=today_date
                    ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                    peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), project_name=F('project__name'),
                    task_assigned_fname=F('user_id__first_name'), task_assigned_lname=F('user_id__last_name'), 
                    tasksts_name=F('task_status_id__name'), flag=Value(True, output_field=BooleanField())).values().order_by("-task_date", '-id')
            else:
                today_date = today_date-timedelta(days=1)
                prodtimesht_list = ProdTimeSheet.objects.filter(
                    user_id =request.data['user_id'], task_date=today_date
                    ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                    peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), project_name=F('project__name'),
                    task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'), tasksts_name=F('task_status_id__name'),
                    flag=Value(True, output_field=BooleanField())
                    ).values().order_by("-task_date", '-id')
            return Response(prodtimesht_list)
        else:
            prodtimesht_list = ProdTimeSheet.objects.filter(
                user_id =request.data['user_id'], task_date=today_date
                ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), project_name=F('project__name'),
                task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'), tasksts_name=F('task_status_id__name'),
                flag=Value(True, output_field=BooleanField())
                ).values().order_by("-task_date", '-id')
            return Response(prodtimesht_list)

# class PrvSelectedTimesheetList(generics.GenericAPIView):
#     @swagger_auto_schema(request_body=PrvTimeSheetListSerializer)
#     def post(self, request):
class SelectedTimesheetListView(DxAPIView):
    @swagger_auto_schema(request_body=SelectedTsListSerializer)
    def get_queryset(self):
        try:
            request = self.request
            user_id = request.user.id
            usr_info = User.objects.get(id=user_id)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Not Found": "Id not found"}, status=status.HTTP_400_BAD_REQUEST)
        # dt_time = datetime.now(time_zone)
        dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        today = dt_time.strftime("%Y-%m-%d")
        today = datetime.strptime(today,"%Y-%m-%d")
        am_pm = dt_time.strftime('%p')
        date_rage = request.data['date_range']
        filters = {}
        filters['task_date__range'] = [date_rage['start_date'], date_rage['end_date']]
        filters['user_id'] = user_id
        if request.data['status']:
            filters['task_status__in'] = request.data['status']
        qry_filter = Q(**filters)
        if usr_info.timechk_sts:
            if am_pm == "PM":
                prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter #request.data['time_sht_date']
                    ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                    peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                    flag=Value(False, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
                    project_name=F('project__name')).values().order_by("-task_date", '-id')
            else:
                # selected_date = selected_date-timedelta(days=1) """can not backtrac the object selected date"""
                prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter
                    ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                    peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                    flag=Value(False, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
                    project_name=F('project__name')).values().order_by("-task_date", '-id')
        else:
            prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter
                ).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                flag=Value(False, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), 
                task_assigned_lname=F('task_assigned_by__last_name'), project_name=F('project__name', '-id')
                ).values().order_by("-task_date")
        # prv_date_list = get_last_three_date(user_id=user_id)
        # for i in prodtimesht_list:
        #     i['flag'] = False
        #     timesht_access, val_message = prv_edit_permission(i['task_date'], prv_date_list)
        #     if timesht_access:
        #         i['flag'] = True
        #     else:
        #         i['flag'] = False
        return prodtimesht_list
        # return Response(prodtimesht_list)

class AdmTimesheetAdd(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=CreateTaskSerializer)
    def post(self, request):
        # dt_time = datetime.now(time_zone)
        dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        today = dt_time.strftime("%Y-%m-%d")
        today = datetime.strptime(today,"%Y-%m-%d")
        tsk_date = datetime.strptime(request.data['task_date'], "%Y-%m-%d").date()
        if today.date() < tsk_date:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Futute Date you can't add. Please Check your Start Time."}, status=status.HTTP_400_BAD_REQUEST)
        if datetime.strptime(request.data['start_date'], "%Y-%m-%d") > datetime.strptime(request.data['end_date'], "%Y-%m-%d"):
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Startdate is always less than enddate. Please check your startdate"}, status=status.HTTP_400_BAD_REQUEST)
        usr_info = User.objects.get(id=request.data['user'])
        if datetime.strptime(request.data['start_date'], '%Y-%m-%d').date() < usr_info.date_joined.date():
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Task date is lower than account created date. Please check your task date"}, status=status.HTTP_400_BAD_REQUEST)
        serializer = CreateTaskSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            invent = serializer.save()
            return Response(TaskSerializer(invent).data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")        
            return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdmTimesheetEdit(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=CreateTaskSerializer)
    def post(self, request):
        # dt_time = datetime.now(time_zone)
        dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
        today = dt_time.strftime("%Y-%m-%d")
        today = datetime.strptime(today,"%Y-%m-%d")
        tsk_date = datetime.strptime(request.data['task_date'],"%Y-%m-%d").date()
        if today.date() < tsk_date:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Startdate is always less than enddate. Please check your startdate"}, status=status.HTTP_400_BAD_REQUEST)

        if date.today() < datetime.strptime(request.data['start_date'], "%Y-%m-%d").date():
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Futute Date you can't add. Please Check your Start Time."}, status=status.HTTP_400_BAD_REQUEST)

        usr_info = User.objects.get(id=request.data['user'])
        if datetime.strptime(request.data['task_date'], '%Y-%m-%d').date() < usr_info.date_joined.date():
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Date": "Task date is lower than account created date. Please check your task date"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            prodtimesht_edit = ProdTimeSheet.objects.get(id=request.data['id'])
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"ProdTimesheet id not found": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        serializer = CreateTaskSerializer(prodtimesht_edit, data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            invent = serializer.save()
            return Response(TaskSerializer(invent).data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")        
            return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TaskStatusInfo(generics.GenericAPIView):
    def get(self, request):
        try:
            tsk_sts_info = TasKStatus.objects.all().values()
            return Response(tsk_sts_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('TaskStatusInfo Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class GetTodayDate(generics.GenericAPIView):
    def get(self, request):
        return Response({'today_date': datetime.now().date()})

class GetPrvTaskDate(generics.GenericAPIView):
    def prv_wrk_date(self, user_id):
        wrk_date = ProdTimeSheet.objects.filter(user_id=user_id, task_date__lt=datetime.now().date()).order_by('-task_date').values('task_date').first()
        if wrk_date:
            last_wrk_date = wrk_date['task_date']
            return last_wrk_date
        else:
            raise Exception('No data found in requested user!')

    @swagger_auto_schema(request_body=TodaytimesheetListSerializer)
    def post(self, request):
        try:
            tkn_user = request.user.id
            user_id = request.data['user_id']
            if tkn_user == user_id:
                prv_wrk_date = self.prv_wrk_date(user_id=user_id)
                # print(prv_wrk_date, type(prv_wrk_date), 'prv_wrk_date')
                return Response({'last_work_date': prv_wrk_date})
            else:
                raise Exception('Invalid user id!')
        except Exception as e:
            print('GetLastTaskDate Error: ', str(e))
            return Response({'Invalid Request' : str(e)}, status=status.HTTP_400_BAD_REQUEST)

# class UsrReportPreview(generics.GenericAPIView):
#     @swagger_auto_schema(request_body=ReportPreviewSerializer)
#     def post(self, request):
class UsrReportPreview(DxAPIView):
    @swagger_auto_schema(request_body=ReportPreviewSerializer)
    def get_queryset(self):
        try:
            request = self.request
            start_date = request.data['date_range']['start_date']
            end_date = request.data['date_range']['end_date']
            filters = {}
            filters['user'] = request.user.id
            if request.data['sts_list']:
                filters['task_status__in'] = request.data['sts_list']
            filter_query = Q(**filters)
            prod_timesht_info = ProdTimeSheet.objects.filter(filter_query, task_date__range=[start_date, end_date]).values().annotate(
            project_name=F('project__name'), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
            task_sts_name=F('task_status__name'), user_fname=F('user__first_name'), user_lname=F('user__last_name'),
            peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'),
            user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()))
            return prod_timesht_info
            return Response(prod_timesht_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('UsrReportPreview error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

# class AdmTimesheetList(generics.GenericAPIView):
#     @swagger_auto_schema(request_body=AdmTimesheetListSerializer)
#     def post(self, request):
class AdmTimesheetList(DxAPIView):
    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AdmTimesheetListSerializer)
    def get_queryset(self):
        try:
            request = self.request
            date_range = request.data['date_range']
            filters = {}
            filters['task_date__range'] = [date_range['start_date'], date_range['end_date']]
            if request.data['user_lst']:
                filters['user__in'] = request.data['user_lst']
            if request.data['status']:
                filters['task_status__in'] = request.data['status']
            qry_filter = Q(**filters)
            timesheet_info = ProdTimeSheet.objects.filter(qry_filter).annotate(user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                flag=Value(False, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
                project_name=F('project__name'), dept_name=F('user__dept__name')).values().order_by("-task_date", '-id')
            return timesheet_info
            # return Response(timesheet_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('AdmTimesheetList error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class BiometModel():
    def __init__(self, bio_id=None, bio_name=None, process_date=None, first_punch=None,
            work_time=None, work_time_hhmm=None, out_punch=None, department_name=None,
            id=None, user_id=None, entry_time=None, updated_on=None):
        self.id = id
        self.bio_id = bio_id
        self.bio_name = bio_name
        self.process_date = process_date
        self.first_punch = first_punch
        self.work_time = work_time
        self.work_time_hhmm = work_time_hhmm
        self.out_punch = out_punch
        self.department_name = department_name
        self.user_id = user_id
        self.entry_time = entry_time
        self.updated_on = updated_on

permission_classes = [IsAdmin]
class GetBiometData(generics.GenericAPIView):
    def get(self, request):
        try:
            req_date = datetime.strptime(request.data['date'], "%Y-%m-%d") #date(2024,6,4)
            holiday_qry = HolidayList.objects.filter(holiday_date__year=req_date.strftime("%Y"), status=True)
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if req_date in holiday_list:
                return 'email skipped for holiday'      
            prv_task_day = req_date - timedelta(days=1)
            while (prv_task_day.strftime("%Y-%m-%d") in holiday_list) or (prv_task_day.weekday() >= 5):
                prv_task_day -= timedelta(days=1) 
            usr_biomet = []
            try:
                with connections['biomet_db'].cursor() as cursor:
                    cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 120), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 120), department_name FROM Mx_VEW_APIDailyAttendance " +
                    "WHERE department_name !='RCM' AND ProcessDate = '" + prv_task_day.strftime("%d/%m/%Y") + "'")
                    usr_biomet = cursor.fetchall()
            except Exception as ex:
                print('biomet_db error: ',str(ex)) 
            user_bio_id_list = User.objects.all().values('id', 'bm_usr_id')
            user_data = {}
            for usr_data in user_bio_id_list:
                user_data[usr_data['bm_usr_id']] = usr_data
            model_list = []
            for prs in usr_biomet:
                bio_model_data = BiometModel(*prs)
                bio_model_data.entry_time = datetime.now(timezone.utc)
                if bio_model_data.bio_id in user_data:
                    bio_model_data.user_id = user_data[bio_model_data.bio_id]['id']
                model_list.append(bio_model_data)
            # print(model_list, 'model_list', len(model_list))

            # """Use bulk create method"""
            bio_data = []
            for usr_bio in model_list: 
                bio_data_obj = BiometricDetails(
                    None,
                    bio_id = usr_bio.bio_id,
                    bio_name = usr_bio.bio_name,
                    process_date = usr_bio.process_date,
                    first_punch = usr_bio.first_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")),
                    out_punch =usr_bio.out_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")),
                    work_time = usr_bio.work_time,
                    work_time_hhmm = usr_bio.work_time_hhmm,
                    department_name = usr_bio.department_name,
                    user_id = usr_bio.user_id
                    )
                bio_data.append(bio_data_obj)
            # print(bio_data, 'bio_data', len(bio_data))
            biomet_detais = BiometricDetails.objects.bulk_create(bio_data)
            return Response("Success")
        except Exception as e:
            print('GetBiometData Error: ', str(e))
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({'Invalid Request': str(e)})

class UserDeleteTask(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UserDeleteTaskSerializer)
    def post(self, request):
        try:
            prv_date_list = get_last_three_date(user_id=request.user.id)
            ts_info = ProdTimeSheet.objects.filter(pk=request.data['prod_id'])
            timesht_access, val_message = prv_edit_permission(ts_info[0].task_date, prv_date_list)
            if timesht_access:
                ts_info.delete()
            else:
                raise Exception('Access denied, Please contact your administrator!')
            return Response("Deleted Successfully", status=status.HTTP_200_OK)
        except Exception as e:
            print('DeleteTask error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

permission_classes = [IsAdmin]
class GetUserProdDetails(generics.GenericAPIView):
    def post(self, request):
        try:
            max_date = BiometricDetails.objects.aggregate(Max('process_date'))
            print(max_date, 'max_date')
            if max_date['process_date__max'] == None:
                try:
                    usr_biomet = []
                    with connections['biomet_db'].cursor() as cursor:# Need to change query
                        # cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                        # "WHERE department_name!='RCM'and convert(date, ProcessDate, 103) BETWEEN '2024-06-01' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                        cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                        "WHERE department_name in ('DEV', 'R&D') and convert(date, ProcessDate, 103) BETWEEN '2024-06-01' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                        usr_biomet = cursor.fetchall()
                except Exception as ex:
                    print('biomet_db error: ',str(ex)) 
            elif max_date['process_date__max'] != None:
                try:
                    usr_biomet = []
                    with connections['biomet_db'].cursor() as cursor: # Need to change query
                        # cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 120), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 120), department_name FROM Mx_VEW_APIDailyAttendance " +
                        # "WHERE department_name!='RCM'and convert(date, ProcessDate, 103) BETWEEN '"+ (max_date['process_date__max']+timedelta(days=1)).strftime("%Y-%m-%d")+"' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                        cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103) as processdate, convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                        "WHERE department_name in ('DEV', 'R&D') and convert(date, ProcessDate, 103) BETWEEN '"+ (max_date['process_date__max']+timedelta(days=1)).strftime("%Y-%m-%d")+"' AND '" + ((datetime.today()-timedelta(days=1)).date()).strftime("%Y-%m-%d") + "'")
                        usr_biomet = cursor.fetchall()
                except Exception as ex:
                    print('biomet_db error: ',str(ex)) 
            print('usr_biomet_len:', len(usr_biomet))
            user_bio_id_list = User.objects.all().values('id', 'bm_usr_id')
            user_data = {}
            for usr_data in user_bio_id_list:
                user_data[usr_data['bm_usr_id']] = usr_data
            model_list = []
            for prs in usr_biomet:
                bio_model_data = BiometModel(*prs)
                bio_model_data.entry_time = datetime.now(timezone.utc)
                if bio_model_data.bio_id in user_data:
                    bio_model_data.user_id = user_data[bio_model_data.bio_id]['id']
                model_list.append(bio_model_data)
            # print(model_list, 'model_list', len(model_list))

            """Use bulk create method"""
            bio_data = []
            for usr_bio in model_list: 
                bio_data_obj = BiometricDetails(
                    None,
                    bio_id = usr_bio.bio_id,
                    bio_name = usr_bio.bio_name,
                    process_date = usr_bio.process_date,
                    first_punch = usr_bio.first_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if usr_bio.first_punch != None else None,
                    out_punch =usr_bio.out_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if usr_bio.out_punch != None else None,
                    work_time = usr_bio.work_time if usr_bio.work_time!=0 and usr_bio.work_time!=None else None,
                    work_time_hhmm = usr_bio.work_time_hhmm if usr_bio.work_time_hhmm !='00:00' and usr_bio.work_time_hhmm != None else None,
                    department_name = usr_bio.department_name,
                    user_id = usr_bio.user_id
                    )
                bio_data.append(bio_data_obj)
            # print(bio_data, 'bio_data', len(bio_data))
            biomet_detais = BiometricDetails.objects.bulk_create(bio_data)
            return Response("Success", status=status.HTTP_200_OK)
        except Exception as e:
            print(str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def bak_db(request):
    try:
        result = app.control.broadcast('ping', reply=True, limit=1, timeout=2.5)
        if result:
            backup_dbs = get_user_biomet_details.delay("req")
        else:
            print('Celery process not responding')
    except Exception as e:
        print('celery api email error',e)
    return Response("success")    

def score_wrk_day(request):
    """To calculate workday count & workday date list from given date string

    :Parameters

    request - date string

    :Result

    returns workday count & workday date list
    """
    req_date = request#'2022-12-05'
    req_date = datetime.strptime(req_date, "%Y-%m-%d")
    join_date = int(req_date.strftime('%d'))
    # print(join_date, type(join_date), 'join_dateeeee')
    holiday_list = []
    businessdays = 0
    businessdays_list = []
    for i in range(join_date, 32):
        try:
            thisdate = date(req_date.year, req_date.month, i)
        except(ValueError):
            break
        if thisdate.weekday() < 5 and thisdate not in holiday_list: # Monday == 0, Sunday == 6 
            businessdays_list.append(thisdate)
            businessdays += 1
    return (businessdays, businessdays_list)

class UserAttendManualScheduler(generics.GenericAPIView):
    """Attendance report update by manual process user requested month

    :Parameters

    req_month - date string

    :Result

    returns - Success message for update
    """
    def holiday_info(self, req_date, end_date):
        """Returns requested month's shift vise Solvedge holiday list
        day_holiday_list, mid_holiday_list, ngt_holiday_list
        """
        day_holiday_list = []
        mid_holiday_list = []
        ngt_holiday_list = []
        holiday_qry = HolidayList.objects.filter(
            holiday_date__year__range=[req_date.year, end_date.year], status=True)
        if holiday_qry.exists():
            for holiday in holiday_qry:
                if holiday.shift_id == 1:
                    day_holiday_list.append(holiday.holiday_date)
                elif holiday.shift_id == 2:
                    mid_holiday_list.append(holiday.holiday_date)
                else:
                    ngt_holiday_list.append(holiday.holiday_date)
        # print(day_holiday_list, 'day_holiday_list',
        #         mid_holiday_list, 'mid_holiday_list',
        #         ngt_holiday_list, 'ngt_holiday_list')
        return day_holiday_list, mid_holiday_list, ngt_holiday_list

    def get_abs_count(self, data, abs_data):
        # print(abs_data, 'abs_data')
        for bio_data in data:
            # print(bio_data, 'bio_data')
            if bio_data['process_date__month'] == abs_data['process_date'].month and bio_data['process_date__year'] == abs_data['process_date'].year:
                bio_data['abs_count'] += 1
                bio_data['abs_date'].append(abs_data['process_date'].day)
        return data

    def get_tot_work_days(self, tot_work_days, holiday_data, shift_id, process_date):
        if shift_id == 1:
            for holi_date in holiday_data[0]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        elif shift_id == 2:
            for holi_date in holiday_data[1]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        elif shift_id == 3:
            for holi_date in holiday_data[2]:
                if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                    tot_work_days -= 1
        return tot_work_days

    def get_cur_mon_work_day(self, work_days_list):
        # print(work_days_list, 'work_days_list')
        work_day_count = 0
        new_list = []
        for work_days in work_days_list[1]:
            if work_days < datetime.now().date():
                work_day_count+=1
                new_list.append(work_days)
        return work_day_count, new_list

    def work_holiday_data(self, req_date, end_date, holiday_data):
        holiday_list = list(set(holiday_data[0] + holiday_data[1] + holiday_data[2]))
        week_day_sun = 1
        week_day_sat = 7
        woh_info = BiometricDetails.objects.select_related('user').filter(
            Q(process_date__week_day__in=[week_day_sat, week_day_sun])|Q(process_date__in=holiday_list),
            work_time__gt=0, user_id__isnull = False, process_date__range=[req_date, end_date]
            ).values('user', 'process_date', 'user__shift_id', 'work_time').order_by('user_id')
        # print(list(woh_info), 'woh_infowoh_info')
        return woh_info

    def get_absent_info(self, req_date, end_date, holiday_data):
        week_day_sun = 1
        week_day_sat = 7
        biomet_absent = BiometricDetails.objects.select_related('user').filter(
            Q(work_time_hhmm=None)|Q(work_time=0), user_id__isnull = False,
            process_date__week_day__gt=week_day_sun, process_date__week_day__lt=week_day_sat,
            process_date__range=[req_date, end_date]).values('user',
            'process_date', 'user__shift_id').order_by('user_id')
        biomet_absent = list(biomet_absent)
        for abs_data in list(biomet_absent):
            if abs_data['user__shift_id'] == 1:
                if abs_data['process_date'] in holiday_data[0]:
                    biomet_absent.remove(abs_data)
            elif abs_data['user__shift_id'] == 2:
                if abs_data['process_date'] in holiday_data[1]:
                    biomet_absent.remove(abs_data)
            elif abs_data['user__shift_id'] == 3:
                if abs_data['process_date'] in holiday_data[2]:
                    biomet_absent.remove(abs_data)
        return biomet_absent

    def get_woh_method(self, old_data, woh_data):
        # print(abs_data, 'abs_data')
        for bio_data in old_data:
            # print(bio_data, 'bio_data')
            if bio_data['process_date__month'] == woh_data['process_date'].month and bio_data['process_date__year'] == woh_data['process_date'].year:
                bio_data['tot_hrs'] -= int(woh_data['work_time'])
                bio_data['woh_hrs'] += int(woh_data['work_time'])
                bio_data['woh_date'].append(woh_data['process_date'].day)
                # bio_data['woh_date'].append(f"{woh_data['process_date'].day}:{woh_data['work_time']}")
        return old_data

    def get_biomet_details(self, req_date, end_date, holiday_data):
        out_data = []
        biomet_data = BiometricDetails.objects.values('user',
            'process_date__month', 'process_date__year', 'user__shift_id').filter(
            user_id__isnull=False, process_date__range=[req_date, end_date]).annotate(
            tot_hrs=Sum('work_time'), joined_date=F('user__date_joined'),
            is_joinded=Case(When(
                Q(user__date_joined__year=F('process_date__year')) & Q(user__date_joined__month=F('process_date__month')), 
                then=True), default=False)
                ).order_by('user_id', 'process_date__year', 'process_date__month')
        # print(biomet_data, 'biomet_data')
        biomet_absent = self.get_absent_info(req_date, end_date, holiday_data)
        woh_data = self.work_holiday_data(req_date, end_date, holiday_data)
        user_bio_info = {}
        for bio_info in biomet_data:
            process_date = date(bio_info['process_date__year'], bio_info['process_date__month'], 1)
            if bio_info['is_joinded']:
                new_join = score_wrk_day(bio_info['joined_date'].strftime("%Y-%m-%d"))
                if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                    new_join = self.get_cur_mon_work_day(new_join)
            else:
                new_join = score_wrk_day(process_date.strftime("%Y-%m-%d"))
                if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                    new_join = self.get_cur_mon_work_day(new_join)
            # print('user_id: ', bio_info['user'])
            # print('new_join: ', new_join)
            tot_work_days = self.get_tot_work_days(new_join[0], holiday_data, bio_info['user__shift_id'], process_date)
            bio_info['process_date'] = process_date
            bio_info['abs_count'] = 0
            bio_info['abs_date'] = []
            bio_info['woh_date'] = []
            bio_info['woh_hrs'] = 0
            bio_info['total_work_days'] = tot_work_days
            temp_dict = {}
            if bio_info['user'] in user_bio_info:
                user_bio_info[bio_info['user']]['data'].append(bio_info)
            else:
                user_bio_info[bio_info['user']] = temp_dict
                temp_dict['user_id'] = bio_info['user']
                temp_dict['data'] = [bio_info]
        if biomet_absent:
            for abs_data in biomet_absent:
                if abs_data['user'] in user_bio_info:
                    usr_info = user_bio_info[abs_data['user']]
                    # print(usr_info, 'usr_info')
                    user_data = self.get_abs_count(usr_info['data'], abs_data)
                    usr_info['data'] = user_data
        if woh_data:
            for woh_details in woh_data:
                if woh_details['user'] in user_bio_info:
                    usr_old_info = user_bio_info[woh_details['user']]
                    user_upd_data = self.get_woh_method(usr_old_info['data'], woh_details)
                    usr_old_info['data'] = user_upd_data
        for bio_info in user_bio_info:
            out_data.append(user_bio_info[bio_info])
        return out_data

    def cal_hrs_diff(self, req_info):
        work_days = 0
        work_days = req_info['total_work_days'] - req_info['abs_count']
        bio_diff = 0
        if work_days:
            if req_info['user__shift_id'] in [1, 2]:
                bio_diff = (work_days * 510) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
            elif req_info['user__shift_id'] == 3:
                bio_diff = (work_days * 480) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
        return bio_diff

    def create_usr_attend_entry(self, user_bio_info):
        # print(user_bio_info, 'user_bio_info')
        updated_list = []
        for user_data in user_bio_info:
            if 'data' in user_data:
                for attendance in user_data['data']:
                    bio_diff = self.cal_hrs_diff(attendance)
                    attend_obj = UserAttandance(
                        None,
                        month = attendance['process_date'],
                        user_id = attendance['user'],
                        tot_hrs = attendance['tot_hrs'],
                        tot_leaves = attendance['abs_count'],
                        hrs_diff = bio_diff,
                        is_joined_month = attendance['is_joinded'],
                        leave_dates = attendance['abs_date'],
                        tot_work_days = attendance['total_work_days'],
                        woh_dates = attendance['woh_date'],
                        woh_tot_hrs = attendance['woh_hrs'] if attendance['woh_hrs'] > 0 else None
                    )
                    updated_list.append(attend_obj)
        with transaction.atomic():
            if updated_list:
                usr_attend_create = UserAttandance.objects.bulk_create(
                    objs=updated_list, 
                    update_conflicts= True, 
                    update_fields=['tot_hrs', 'tot_leaves', 'hrs_diff', 'leave_dates', 'tot_work_days', 'woh_dates', 'woh_tot_hrs'],
                    unique_fields=['user_id', 'month'])

    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=UserAttendSerializer)
    def post(self, request):
        try:
            attend_date = datetime.strptime(request.data['req_month'], '%Y-%m-%d').date()
            if attend_date.month == datetime.now().month and attend_date.year == datetime.now().year:
                req_date = date(attend_date.year, attend_date.month, 1)
                end_date = (datetime.now() - timedelta(days=1)).date()
            elif attend_date.year == datetime.now().year and attend_date.month > datetime.now().month:
                raise Exception('Invalid request date!')
            elif attend_date.year > datetime.now().year:
                raise Exception('Invalid request date!')
            else:
                req_date = date(attend_date.year, attend_date.month, 1) # date(2024,4,1)
                res = calendar.monthrange(attend_date.year, attend_date.month)[1]
                end_date = date(attend_date.year, attend_date.month, res) #datetime.now() - timedelta(days=1)
            holiday_data = self.holiday_info(req_date=req_date, end_date=end_date)
            biomet_info = self.get_biomet_details(req_date=req_date, end_date=end_date, holiday_data=holiday_data)
            attandance_data = self.create_usr_attend_entry(biomet_info)
            return Response('Success', status=status.HTTP_200_OK)
        except Exception as e:
            print('UserAttendReport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class BiometricUpdateByUserList(generics.GenericAPIView):
    """Update Biometric entries for a request userlist & given range

    :Parameters

    user_list - list of users to update
    date_range - [start_date, end_date], dates in str format('YYYY-MM-DD) with in single month only

    :Result

    returns - Success message for update
    """
    def bio_id_list(self, user_list):
        user_info = User.objects.filter(id__in=user_list, is_active=True).values('id', 'bm_usr_id')
        bio_id_list = []
        for usr in user_info:
            bio_id_list.append(usr['bm_usr_id'])
        return user_info, bio_id_list

    def get_biomet_data(self, bio_id_list, date_range):
        start_date = date_range['start_date']
        end_date = date_range['end_date']
        try:
            usr_biomet = []
            with connections['biomet_db'].cursor() as cursor:
                id_tuple = tuple(bio_id_list)
                if len(id_tuple) > 1:
                    query = """SELECT UserID, UserName, convert(date, ProcessDate, 103), 
                    convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103),
                    department_name FROM Mx_VEW_APIDailyAttendance 
                    convert(date, ProcessDate, 103) BETWEEN '""" + str(start_date) + "' AND '" + str(end_date) + "' AND UserID in {}".format(id_tuple) #WHERE department_name!='RCM'
                else:
                    print('else condition worked')
                    query = """SELECT UserID, UserName, convert(date, ProcessDate, 103), 
                    convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103),
                    department_name FROM Mx_VEW_APIDailyAttendance WHERE 
                    convert(date, ProcessDate, 103) BETWEEN '""" + str(start_date) + "' AND '" + str(end_date) + "' AND UserID = '{}'".format(id_tuple[0])
                cursor.execute(query) # department_name!='RCM' and
                usr_biomet = cursor.fetchall()
        except Exception as ex:
            print('biomet_db error: ',str(ex)) 
        # print(usr_biomet, 'usr_biomet')
        return usr_biomet

    def bio_updation(self, bio_info, usr_info, date_range):
        start_date = date_range['start_date']
        end_date = date_range['end_date']
        try:
            user_list = []
            user_dict = {}
            for usr in usr_info:
                user_list.append(usr['id'])
                user_dict[usr['bm_usr_id']] = usr
            bio_data = {}
            for prs in bio_info:
                bio_model_data = BiometModel(*prs)
                bio_model_data.entry_time = datetime.now(timezone.utc)
                bio_data[bio_model_data.process_date, bio_model_data.bio_id] = bio_model_data
            updated_obj_list = []
            user_bio_obj = BiometricDetails.objects.filter(user_id__in=user_list,
                process_date__range=[start_date, end_date])
            with transaction.atomic():
                if user_bio_obj:
                    for bio_obj in user_bio_obj:    # Data from local table
                        if (bio_obj.process_date, bio_obj.bio_id) in bio_data:
                            Bio_model_class = bio_data[bio_obj.process_date, bio_obj.bio_id]
                            bio_obj.first_punch = Bio_model_class.first_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if Bio_model_class.first_punch!=None else None
                            bio_obj.out_punch = Bio_model_class.out_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if Bio_model_class.out_punch!=None else None
                            bio_obj.work_time = Bio_model_class.work_time if Bio_model_class.work_time!=0 and Bio_model_class.work_time!=None else None
                            bio_obj.work_time_hhmm = Bio_model_class.work_time_hhmm if Bio_model_class.work_time_hhmm!='00:00' and Bio_model_class.work_time_hhmm!=None else None
                            bio_obj.updated_on = datetime.now(timezone.utc)
                            updated_obj_list.append(bio_obj)
                else:
                    raise Exception('No biomet data to update!')
                if updated_obj_list:
                    updted_obj = BiometricDetails.objects.bulk_update(updated_obj_list, 
                    ['first_punch', 'out_punch', 'work_time', 'work_time_hhmm'])
                    return updted_obj
                else:
                    raise Exception('No data to update!')
        except Exception as e:
            raise Exception(str(e))

    def update_biomet(self, request):
        user_list = request['user_list']
        date_range = request['date_range']
        if not user_list:
            raise Exception('Selectd user list is empty!')
        user_data = self.bio_id_list(user_list)
        bio_info = self.get_biomet_data(user_data[1], date_range)
        update_data = self.bio_updation(bio_info, user_data[0], date_range)
        return update_data

    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=BiometricUpdateByUserListSerializer)
    def post(self, request):
        try:
            # print('req: ', request, datetime.now())
            date_range = request.data['date_range']
            # print(date_range['start_date'], date_range['end_date'])
            start_date = datetime.strptime(date_range['start_date'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_date'], '%Y-%m-%d').date()
            if start_date.month == end_date.month and start_date.year == end_date.year:
                print('if worked for updare')
                update_biomet = self.update_biomet(request.data)
                # try:
                #     req_data = {'req_month': date_range['start_date']}
                    # attend_rpt_upd = UserAttendReport.as_view(request=req_data)
                # except Exception as e:
                #     raise Exception('Biometric updated successfully but not update attendance report contact administrator!')
            else:
                raise Exception('Biomet date range in invalid, Kindly give the date range with in single month!')
            return Response('Success', status=status.HTTP_200_OK)
        except Exception as e:
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

# class AdmProdReport(generics.GenericAPIView):
class AdmProdReport(DxAPIView):
    def bio_time_diff(self, total_hours, bio_hours):
        hur_mins = '0:00'
        try:
            tot_date = datetime.strptime(total_hours,"%H:%M")
            bio_date = datetime.strptime(bio_hours,"%H:%M")
            min_sign = "+ "
            if tot_date > bio_date:
                delta = tot_date - bio_date
                min_sign = "- "
            else:
                delta = bio_date - tot_date 
            minutes = int(delta.total_seconds() / 60)
            if minutes > 0:
                hour = minutes // 60
                mins = minutes % 60
                if mins < 10:
                    hur_mins = "{}:0{}".format(hour,mins)
                else:
                    hur_mins = "{}:{}".format(hour,mins)
            if minutes > 10 and min_sign == '- ':
                return min_sign + hur_mins, 'lt10'
            else:
                return min_sign + hur_mins, 'gt10'
        except Exception as ex:
            print('bio_diff: ',str(ex))
        return hur_mins, 'er'

    def hour_to_min(self, mins_data):
        hur_mins = '0:00'
        if mins_data:
            if mins_data <= 0:
                return hur_mins
            hour = mins_data // 60
            mins = mins_data % 60
            if mins < 10:
                hur_mins = "{}:0{}".format(hour,mins)
            else:
                hur_mins = "{}:{}".format(hour,mins)
        return hur_mins

    def hrs_format(self, b_time):
        seconds = int(b_time.total_seconds())
        seconds = seconds % (24 * 3600)
        hour = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        bi_time = "{}:{}:{}".format(hour, minutes, seconds)
        return bi_time

    def con_user_production_report(self, user_info, prod_report, usr_biomet):
        prod_info = {}
        usr_info = {}
        for usr in user_info:
            try:
                for wrktime in usr_biomet:
                    usr_res = {}
                    usr_res['shift_name'] = usr['shift_name']
                    usr_res['shift_frm'] = usr['shift_frm']  #+ ' to ' + usr['shift_to']
                    usr_res['shift_to'] = usr['shift_to']
                    usr_res['user_id'] = usr['id']
                    usr_res['dept_name'] = usr['dept_name']
                    usr_res['user_name'] = usr['first_name'] + " " + usr['last_name']
                    usr_res['user_fulname'] = usr['first_name'] + " " + usr['last_name']
                    if wrktime["bio_id"] == usr['bm_usr_id']:
                        if len(wrktime):
                            if wrktime['work_time_hhmm'] is None or str(wrktime['work_time_hhmm']).startswith('0'):
                                usr_res['bio_time'] = '0:00'
                                usr_res['process_date'] = wrktime['process_date']
                            else:
                                b_time = wrktime['work_time_hhmm']
                                if type(b_time)!=str:
                                    bi_time = self.hrs_format(b_time)
                                    usr_res['bio_time'] = datetime.strptime(bi_time, "%H:%M:%S").strftime("%H:%M")
                                    usr_res['process_date'] = wrktime['process_date']
                                else:
                                    usr_res['bio_time'] = '0:00'
                                    usr_res['process_date'] = wrktime['process_date']
                                    usr_res['break_hours'] = wrktime['break_hours']
                                    usr_res['gross_work_hours'] = wrktime['gross_work_hours']
                                    usr_res['less_hours'] = wrktime['less_hours']
                                    
                        else:
                            usr_res['bio_time'] = '0:00'
                            usr_res['process_date'] = wrktime['process_date']
                        usr_info[usr['id'], wrktime['process_date'].strftime('%m-%d-%Y')] = usr_res
                        usr_res['break_hours'] = '0:00'
                        usr_res['gross_work_hours'] = '0:00'
                        usr_res['less_hours'] = '0:00'
                        
            except Exception as ex:
                print('usr_biomet err: ',str(ex))
        user_prod_info = {}
        if prod_report:
            for prod in prod_report:
                try:
                    prod_info[prod['user_id'], prod['task_date'].strftime('%m-%d-%Y')] = prod
                    prod['user_name'] = prod['usr_fname'] + ' ' + prod['usr_lname']
                    prod['user_fulname'] = prod['usr_fname'] + ' ' + prod['usr_lname']
                    prod['task_date'] = prod['task_date'].strftime('%m-%d-%Y')
                    prod['avg_prd_percent'] = round(prod['avg_prd_percent'], 2)
                    prod['total_time'] = self.hour_to_min(prod['tsk_tot_time'])
                    prod['gen_total_time'] = self.hour_to_min(prod['tsk_gen_time'])
                    prod['down_time'] = self.hour_to_min(prod['tsk_down_time']) if prod['tsk_down_time'] != None else '0:00'
                    try:
                        usr_addon = usr_info[prod['user_id'], prod['task_date']]
                        if usr_addon is None:
                            prod['shift_name'] = ''
                            prod['shift_frm'] = ''
                            prod['shift_to'] = ''
                            prod['bio_time'] = ''
                            prod['bio_diff'] = ''
                            prod['bio_diff_org'] = ''
                            prod['bio_diff_flag'] = ''
                        else:
                            prod['shift_name'] = usr_addon['shift_name']
                            prod['shift_frm'] = usr_addon['shift_frm']
                            prod['shift_to'] = usr_addon['shift_to']
                            prod['bio_time'] = usr_addon['bio_time']
                            prod['bio_diff_org'] = usr_addon['bio_time']
                            prod['bio_diff'], prod['bio_diff_flag'] = self.bio_time_diff(prod['total_time'], prod['bio_diff_org'])
                    except Exception as e:
                        print('error:', str(e))
                        for usr in user_info:
                            if usr['id'] == prod['user_id']:
                                prod['shift_name'] = usr['shift_name']
                                prod['shift_frm'] = usr['shift_frm']
                                prod['shift_to'] = usr['shift_to']
                                prod['bio_time'] = '0:00'
                                prod['bio_diff_org'] = '0:00'
                                prod['bio_diff'], prod['bio_diff_flag'] = self.bio_time_diff(prod['total_time'], prod['bio_diff_org'])
                    user_prod_info[prod['user_id'], prod['task_date']] = prod 
                    
                except Exception as ex:
                    print('Production time sheet e: ', ex)
        usr_prod_info = {}
        for user in usr_info:
            if user not in prod_info:
                if type(usr_info[user]['bio_time']) == str:
                    time1 = datetime.strptime(usr_info[user]['bio_time'], "%H:%M")
                    time2 = datetime(1900,1,1)
                if (time1-time2).total_seconds() / 60.0 > 0:
                    cur_prod = {}
                    usr_prod_info[user] = cur_prod
                    cur_prod['user_name'] = usr_info[user]['user_name']
                    cur_prod['user_fulname'] = usr_info[user]['user_fulname']
                    cur_prod['task_date'] = user[1] #.strftime("%m-%d-%Y")
                    cur_prod['user_id'] = user[0] #usr_info[user]['user_id']
                    cur_prod['inp_tsk_cnt'] = None
                    cur_prod['hold_tsk_cnt'] = None
                    cur_prod['cmp_tsk_cnt'] = None
                    cur_prod['tot_tsk_cnt'] = None
                    cur_prod['avg_prd_percent'] = None
                    cur_prod['total_time'] = '0:00'
                    cur_prod['down_time'] = '0:00'
                    cur_prod['gen_total_time'] = '0:00'
                    cur_prod['dept_name'] = usr_info[user]['dept_name']
                    cur_prod['shift_name']= usr_info[user]['shift_name']
                    cur_prod['shift_frm']= usr_info[user]['shift_frm']
                    cur_prod['shift_to']= usr_info[user]['shift_to']
                    cur_prod['bio_time']= usr_info[user]['bio_time']
                    cur_prod['bio_diff_org']= usr_info[user]['bio_time']
                    cur_prod['bio_diff'], cur_prod['bio_diff_flag'] = bio_time_diff('0:00', cur_prod['bio_diff_org'])
            prod_info.update(usr_prod_info)
        prod_info = OrderedDict(sorted(prod_info.items(),key = lambda x: getitem(x[1], 'task_date')))
        return prod_info

    def get_user_prod_report(self, start_date, end_date, filter_query, user_filter_query, active_flag):
        try:
            prod_report = ProdTimeSheet.objects.values(
                'user_id', 'task_date').prefetch_related('user_id', 'task_status').filter(
                filter_query, Q(user_id__is_active=active_flag),task_date__range=[start_date, end_date]).annotate(
                usr_fname=F('user_id__first_name'), usr_lname=F('user_id__last_name'), dept_name=F('user__dept__name'),
                inp_tsk_cnt=Count('id', filter=Q(task_status=1)), cmp_tsk_cnt=Count('id', filter=Q(task_status=3)),
                hold_tsk_cnt=Count('id', filter=Q(task_status=2)), tot_tsk_cnt=Count('id'), tsk_tot_time=Sum('total_time'),
                tsk_down_time=Sum('total_time', filter=Q(project__is_down_time=True)),
                tsk_gen_time=Sum('total_time', filter=~Q(project__is_down_time=True)),
                total_per=Sum('prod_percent'), avg_prd_percent=Avg('prod_percent')
                ).order_by('task_date')
            usr_info = User.objects.filter(user_filter_query, is_active=True).values(
                'id','first_name', 'last_name','bm_usr_id','shift','shift_frm','shift_to',
                shift_name = F('shift__shift_name'), usr_id = F('id'), dept_name=F('dept__name'))
            ideal_hours = datetime.timedelta(hours=8, minutes=30)

            usr_biomet = BiometricDetails.objects.prefetch_related('user_id').filter(
                filter_query, Q(user_id__is_active=active_flag), process_date__range=[start_date, end_date]
                ).values('bio_id', 'bio_name', 'process_date', 'work_time', 'work_time_hhmm', 'department_name', 'user_id','first_punch','out_punch').annotate(break_hours=(F('out_punch')-F('first_punch')-F('work_time_hhmm')))(gross_work_hours=(F('out_punch')-F('first_punch')))(less_hours=Case(
        When(
            work_timee_hhmm__lte=ideal_hours,
            then=ExpressionWrapper(
                Value(ideal_hours) - F("work_hrs"),
                output_field=DurationField()
            )
        ),
        default=Value(datetime.timedelta(0)),
        output_field=DurationField()
    )
)

            usr_prd_repport = self.con_user_production_report(usr_info, prod_report, usr_biomet)
            return usr_prd_repport
        except Exception as e:
            print('Production Timesheet error :',e)

    # permission_classes = [IsAdmin]
    # @swagger_auto_schema(request_body=UserProdReportSerializer)
    # def post(self, request):
    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=UserProdReportSerializer)
    # def get_queryset(self):
    def post(self,request):
        # request = self.request
        try:
            date_range = request.data['date_range']
            start_date = date_range['start_date']
            end_date = date_range['end_date']
            user_list = request.data['usr_list']
            active_flag = request.data['usr_active_flag']
            filters = {}
            usr_filter = {}
            if len(user_list) > 0:
                filters['user_id__in'] = user_list
                usr_filter['id__in'] = user_list
            filter_query = Q(**filters)
            user_filter_query = Q(**usr_filter)
            user_data = self.get_user_prod_report(start_date, end_date, filter_query, user_filter_query, active_flag)
            dict_obj = []
            for usr in user_data :
                dict_obj.append(user_data[usr])
            return Response (dict_obj)
            # return Response(dict_obj, status=status.HTTP_200_OK)
        except Exception as e:
            print('AdmProdReport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DeleteTaskByAdm(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=UserDeleteTaskSerializer)
    def post(self, request):
        try:
            data = ProdTimeSheet.objects.filter(id=request.data['prod_id']).delete()
            return Response("Deleted Successfully", status=status.HTTP_200_OK)
        except Exception as e:
            print('DeleteTask error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UserProdReport(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UserProdReportUsrSerializer)
    def post(self, request):
        try:
            date_range = request.data['date_range']
            user_id = request.user.id
            filters = {}
            usr_filter = {}
            filters['user_id'] = user_id
            usr_filter['id'] = user_id
            filter_query = Q(**filters)
            user_filter_query = Q(**usr_filter)
            user_data = AdmProdReport().get_user_prod_report(
                date_range['start_date'], date_range['end_date'], filter_query, user_filter_query,True)
            dict_obj = []
            for usr in user_data :
                dict_obj.append(user_data[usr])
            return Response(dict_obj, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserProdReport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

def month_list_info(start, end):
    start_date = start #date(2024,5,5)
    end_date = end #date(2024,10,8)
    month_list = []
    current_date = start_date.replace(day=1).date()  # Start from the first day of the start month
    while current_date <= end_date:
        month_list.append(current_date)
        current_date = current_date + timedelta(days=32)
        current_date = current_date.replace(day=1)
    return month_list

class AdmAttendanceReport(generics.GenericAPIView):
    def get_leave_date(self, date_list, prs_date):
        updated_list = []
        date_list = sorted(date_list)
        for date_val in date_list:
            format_date = date(prs_date.year, prs_date.month, date_val).strftime('%m.%d.%Y  %A')
            updated_list.append(format_date)
        updated_list = '\n'.join(updated_list)
        return updated_list

    def get_empty_val(self, month):
        temp = {}
        temp['month'] = month.strftime('%Y-%m-%d')
        temp['leave_days'] = None
        temp['hrs_diff'] = None
        temp['tot_hrs_diff'] = None
        temp['leave_dates'] = None
        temp['woh_days_cnt'] = None
        temp['woh_dates'] = None
        temp['woh_tot_hrs'] = None
        temp['extra_hrs'] = None
        return temp

    def add_empty_data(self, data_val, month_list):
        data_list = []
        data_dict = {}
        for data in data_val:
            data_dict[data['month']] = data
        # print(data_dict, 'data_dict')
        for month in month_list:
            temp_dict = {}
            if month.strftime('%Y-%m-%d') not in data_dict:
                data_dict[month] = self.get_empty_val(month)
        for out_data in data_dict:
            data_list.append(data_dict[out_data])
        data_list = sorted(data_list, key=lambda d: d['month'])
        return data_list

    def hrs_format(self, data):
        if data < 0:
            data = 0
        hour = data//60
        # h_min = (data*60) % 60
        h_min = data % 60
        shift_adherence = "{}:{}".format(f'{hour:02d}', f'{h_min:02d}')
        return shift_adherence

    def formated_data(self, data, month_list):
        out_data = []
        out_dict = {}
        for user_info in data:
            temp_dict = {}
            data_dict = {}
            leave_date_list = ast.literal_eval(user_info['leave_dates'])
            if leave_date_list:
                leave_date_list = self.get_leave_date(leave_date_list, user_info['month'])
            else:
                leave_date_list = None
            woh_date_list = ast.literal_eval(user_info['woh_dates'])
            woh_days_cnt = None
            if woh_date_list:
                woh_days_cnt = len(woh_date_list)
                woh_date_list = self.get_leave_date(woh_date_list, user_info['month'])
                woh_date_list = 'Total Hrs. ' + str(user_info['woh_tot_hrs']) + '\n' + woh_date_list
            else:
                woh_date_list = None
                woh_days_cnt = None

            if user_info['user_id'] in out_dict:
                temp_dict = out_dict[user_info['user_id']]
                data_dict['month'] = user_info['month'].strftime('%Y-%m-%d')
                data_dict['joined_month_flag'] = user_info['is_joined_month']
                data_dict['leave_days'] = user_info['tot_leaves']
                data_dict['hrs_diff'] = user_info['hrs_foramat']
                data_dict['leave_dates'] = leave_date_list #user_info['leave_dates']
                data_dict['woh_dates'] = woh_date_list
                data_dict['woh_days_cnt'] = woh_days_cnt
                data_dict['extra_hrs'] = user_info['extra_hrs']
                data_dict['woh_tot_hrs'] = user_info['woh_tot_hrs']
                data_dict['tot_hrs_diff'] = user_info['hrs_diff'] if user_info['hrs_diff'] >= 0 else 0
                temp_dict['data'].append(data_dict)
            else:
                out_dict[user_info['user_id']] = temp_dict
                temp_dict['user_id'] = user_info['user_id']
                temp_dict['user_fname'] = user_info['user_fname']
                temp_dict['user_lname'] = user_info['user_lname']
                temp_dict['dept_name'] = user_info['dept_name']
                temp_dict['date_joined'] = user_info['date_joined']
                data_dict['month'] = user_info['month'].strftime('%Y-%m-%d')
                data_dict['joined_month_flag'] = user_info['is_joined_month']
                data_dict['leave_days'] = user_info['tot_leaves']
                data_dict['leave_dates'] = leave_date_list #user_info['leave_dates']
                data_dict['woh_dates'] = woh_date_list
                data_dict['woh_days_cnt'] = woh_days_cnt
                data_dict['extra_hrs'] = user_info['extra_hrs']
                data_dict['woh_tot_hrs'] = user_info['woh_tot_hrs']
                data_dict['hrs_diff'] = user_info['hrs_foramat']
                data_dict['tot_hrs_diff'] = user_info['hrs_diff'] if user_info['hrs_diff'] >= 0 else 0
                temp_dict['data'] = [data_dict]
        for out_data_info in out_dict:
            out_data.append(out_dict[out_data_info])
        for val in out_data:
            out_data_info = self.add_empty_data(val['data'], month_list)
            val['data'] = out_data_info
        data_list = sorted(out_data, key=lambda d: d['user_fname'])
        return data_list

    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AdmAttendanceReportSerializer)
    def post(self, request):
        try:
            # print('req: ', request, datetime.now())
            start_date = date(request.data['year'], 7, 1).strftime('%Y-%m-%d')
            end_date = date(request.data['year'] + 1, 6, 1).strftime('%Y-%m-%d')
            month_list = month_list_info(datetime.strptime(start_date, '%Y-%m-%d'), datetime.strptime(end_date, '%Y-%m-%d').date())
            while len(month_list) > 12:
                month_list.pop()
            filters = {}
            usr_fitler = {}
            if request.data['user_list']:
                filters['user_id__in'] = request.data['user_list']
                usr_fitler['id__in'] = request.data['user_list']
            filters['month__range'] = [start_date, end_date]
            qry_filter = Q(**filters)
            attandance_data = UserAttandance.objects.select_related('user', 'user__dept').filter(
                qry_filter, user__is_active=True).annotate(
                date_joined=F('user__date_joined'),
                user_fname=F('user__first_name'),
                user_lname=F('user__last_name'),
                dept_name=F('user__dept__name')
                ).values()
            # print(attandance_data, 'attandance_data')
            attandance_data = list(attandance_data)
            for data in attandance_data:
                hrs_foramat = self.hrs_format(data['hrs_diff'])
                extra_hrs = self.hrs_format(abs(data['hrs_diff'])) if data['hrs_diff'] <= 0 else None
                woh_tot_hrs = None
                if data['woh_tot_hrs']:
                    woh_tot_hrs = self.hrs_format(data['woh_tot_hrs'])
                data['hrs_foramat'] = hrs_foramat
                data['extra_hrs'] = extra_hrs
                data['woh_tot_hrs'] = woh_tot_hrs if woh_tot_hrs else data['woh_tot_hrs']
            out_data = self.formated_data(attandance_data, month_list)
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserProdReport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UsrAttendanceReport(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UsrAttendanceReportSerializer)
    def post(self, request):
        try:
            start_date = date(request.data['year'], 7, 1).strftime('%Y-%m-%d')
            end_date = date(request.data['year'] + 1, 6, 1).strftime('%Y-%m-%d')
            month_list = month_list_info(datetime.strptime(start_date, '%Y-%m-%d'), datetime.strptime(end_date, '%Y-%m-%d').date())
            while len(month_list) > 12:
                month_list.pop()
            filters = {}
            usr_fitler = {}
            filters['user_id'] = request.user.id
            usr_fitler['id'] = request.user.id
            filters['month__range'] = [start_date, end_date]
            qry_filter = Q(**filters)
            attandance_data = UserAttandance.objects.select_related('user', 'user__dept').filter(
                qry_filter, user__is_active=True).annotate(
                date_joined=F('user__date_joined'),
                user_fname=F('user__first_name'),
                user_lname=F('user__last_name'),
                dept_name=F('user__dept__name')
                ).values()
            # print(attandance_data, 'attandance_data')
            attandance_data = list(attandance_data)
            for data in attandance_data:
                hrs_foramat = AdmAttendanceReport().hrs_format(data['hrs_diff'])
                extra_hrs = AdmAttendanceReport().hrs_format(abs(data['hrs_diff'])) if data['hrs_diff'] <= 0 else None
                woh_tot_hrs = None
                if data['woh_tot_hrs']:
                    woh_tot_hrs = AdmAttendanceReport().hrs_format(data['woh_tot_hrs'])
                data['hrs_foramat'] = hrs_foramat
                data['extra_hrs'] = extra_hrs
                data['woh_tot_hrs'] = woh_tot_hrs if woh_tot_hrs else data['woh_tot_hrs']
            out_data = AdmAttendanceReport().formated_data(attandance_data, month_list)
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserProdReport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CheckHoliday(generics.GenericAPIView):    #Not used Api
    def get(self, request):
        try:
            # HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            day_holiday_list = []
            mid_holiday_list = []
            ngt_holiday_list = []
            shift_list = [1, 2, 3]
            holiday_qry = HolidayList.objects.filter(
                holiday_date__year=datetime.today().strftime("%Y"), status=True)
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    if holiday.shift_id == 1:
                        day_holiday_list.append(holiday.holiday_date)
                    elif holiday.shift_id == 2:
                        mid_holiday_list.append(holiday.holiday_date)
                    else:
                        ngt_holiday_list.append(holiday.holiday_date)
            prv_task_day = None
            day_prv_task_day = datetime.now()-timedelta(days=1)
            mid_prv_task_day = datetime.now()-timedelta(days=1)
            ngt_prv_task_day = datetime.now()-timedelta(days=1)
            while (day_prv_task_day.date() in day_holiday_list) or (day_prv_task_day.weekday() >= 5):
                day_prv_task_day -= timedelta(days=1)
            while (mid_prv_task_day.date() in mid_holiday_list) or (mid_prv_task_day.weekday() >= 5):
                mid_prv_task_day -= timedelta(days=1)
            while (ngt_prv_task_day.date() in ngt_holiday_list) or (ngt_prv_task_day.weekday() >= 5):
                ngt_prv_task_day -= timedelta(days=1)
            # print(day_prv_task_day, 'day_prv_task_day')
            # print(mid_prv_task_day, 'mid_prv_task_day')
            # print(ngt_prv_task_day, 'ngt_prv_task_day')
            prv_task_day = day_prv_task_day
            if prv_task_day == mid_prv_task_day:
                if prv_task_day == ngt_prv_task_day:
                    prv_task_day = prv_task_day
                elif prv_task_day > ngt_prv_task_day:
                    prv_task_day == prv_task_day
                    shift_list.remove(3)
                elif ngt_prv_task_day > prv_task_day:
                    prv_task_day == ngt_prv_task_day
                    shift_list.remove(1)
                    shift_list.remove(2)
            elif prv_task_day == ngt_prv_task_day:
                if prv_task_day == mid_prv_task_day:
                    prv_task_day = prv_task_day
                elif prv_task_day > mid_prv_task_day:
                    prv_task_day = prv_task_day
                    shift_list.remove(2)
                elif mid_prv_task_day > prv_task_day:
                    prv_task_day = mid_prv_task_day
                    shift_list.remove(1)
                    shift_list.remove(3)
            else:
                if prv_task_day > mid_prv_task_day and prv_task_day > ngt_prv_task_day:
                    prv_task_day = prv_task_day
                    shift_list.remove(2)
                    shift_list.remove(3)
                elif mid_prv_task_day > prv_task_day and mid_prv_task_day > ngt_prv_task_day:
                    prv_task_day = mid_prv_task_day
                    shift_list.remove(1)
                    shift_list.remove(3)
                elif ngt_prv_task_day > mid_prv_task_day and ngt_prv_task_day > prv_task_day:
                    prv_task_day = ngt_prv_task_day
                    shift_list.remove(1)
                    shift_list.remove(2)
                elif mid_prv_task_day > prv_task_day and mid_prv_task_day == ngt_prv_task_day:
                    prv_task_day = mid_prv_task_day
                    shift_list.remove(1)
                elif ngt_prv_task_day > prv_task_day and mid_prv_task_day == ngt_prv_task_day:
                    prv_task_day = ngt_prv_task_day
                    shift_list.remove(1)
            return Response({"date": prv_task_day.date(), "shift_data": shift_list}, status=status.HTTP_200_OK)
        except Exception as e:
            print('CheckHoliday error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdmProductionExcelExport(generics.GenericAPIView):
    def prod_excel_export(self, prod_data):
        try:
            workbook = Workbook()
            workbook.remove(workbook.active)
            worksheet = workbook.create_sheet(title='Production Reports', index=1)
            columns = ['S.No', 'Date', 'Name', 'Department', 'Work Shift', 'Shift Timing',
                'Avg. Production', 'Inprogress', 'Hold', 'Completed', 'Total Task',
                'Production Hours', 'Down Time', 'Total Hours' , 'Bio-Met Hours', 'Bio-Met diff.']
            column_width = []
            row_num = 1
            cell = worksheet.cell(row=row_num, column=2)
            cell.value = 'SE Tracker: Employee Production Reports from - '+ datetime.now().strftime('%m-%d-%Y')
            cell.font = Font(bold=True)
            row_num = row_num + 1
            thin_border = Border(
                left=Side(style='thin'), right=Side(style='thin'),
                top=Side(style='thin'), bottom=Side(style='thin'))

            for col_num, column_title in enumerate(columns, 1):
                worksheet.row_dimensions[row_num].height = 25
                cell = worksheet.cell(row=row_num, column=col_num)
                cell.value = column_title
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                cell.font = Font(bold=True, size="10")
                cell.border = thin_border
                cell.fill = PatternFill(start_color="8ea9db", fill_type="solid")
                column_width.append(len(str(column_title))*1.32)
            sl_no = 1
            for rec in prod_data:
                # print(rec,'eeee')
                row_num += 1
                row = []
                row.append(sl_no)
                row.append(rec['task_date']) if rec['task_date'] else row.append('')
                row.append(rec['user_name']) if rec['user_name'] else row.append('')
                row.append(rec['dept_name']) if rec['dept_name'] else row.append('')
                row.append(rec['shift_name']) if rec['shift_name'] else row.append('')
                row.append(rec['shift_frm'] + ' - ' + rec['shift_to']) if rec['shift_frm'] or rec['shift_frm'] else row.append('')
                row.append(rec['avg_prd_percent']) if rec['avg_prd_percent'] else row.append('')
                row.append(rec['inp_tsk_cnt']) if rec['inp_tsk_cnt'] else row.append('')
                row.append(rec['hold_tsk_cnt']) if rec['hold_tsk_cnt'] else row.append('')
                row.append(rec['cmp_tsk_cnt']) if rec['cmp_tsk_cnt'] else row.append('')
                row.append(rec['tot_tsk_cnt']) if rec['tot_tsk_cnt'] else row.append('')
                row.append(rec['gen_total_time']) if rec['gen_total_time'] else row.append('')
                row.append(rec['down_time']) if rec['down_time'] else row.append('')
                row.append(rec['total_time']) if rec['total_time'] else row.append('')
                row.append(rec['bio_time']) if rec['bio_time'] else row.append('')
                row.append(rec['bio_diff']) if rec['bio_diff'] else row.append('')

                for col_num, cell_value in enumerate(row, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    cell.border = thin_border
                    cell.font = Font(size='10')
                    if column_width[col_num - 1] < len(str(cell_value)):
                        column_width[col_num - 1] = len(str(cell_value))
                    if col_num  == 2 or col_num >= 6:
                        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                    if col_num == 7:
                        cell.number_format = '##0.00"%"'
                sl_no = sl_no + 1
            dim_holder = DimensionHolder(worksheet=worksheet)
            for col in range(worksheet.min_column, worksheet.max_column + 1):
                dim_holder[get_column_letter(col)] = ColumnDimension(worksheet, min=col, max=col, width=column_width[col - 1])
            worksheet.column_dimensions = dim_holder
            date_format = date.today().strftime("%m%d%y")
            file_name = 'SE Tracker Employee Production Reports' + '-' + date_format
            # print(file_name,'file name')
            response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename={0}.xlsx'.format(file_name)
            response['Access-Control-Expose-Headers'] = "Content-Disposition"
            workbook.save(response)
            return response
        except Exception as e:
            print('prod_excel_export error: ', str(e))
            return str(e)

    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AdmProdExcelExportSerializer)
    def post(self, request):
        try:
            date_range = request.data['date_range']
            user_list = request.data['usr_list']
            filters = {}
            usr_filter = {}
            if len(user_list) > 0:
                filters['user_id__in'] = user_list
                usr_filter['id__in']= user_list
            filter_query = Q(**filters)
            user_filter_query = Q(**usr_filter)
            user_data = AdmProdReport().get_user_prod_report(date_range['start_date'],date_range['end_date'],filter_query,user_filter_query, True)
            dict_obj = []
            for usr in user_data :
                dict_obj.append(user_data[usr])
            excel_data = self.prod_excel_export(dict_obj)
            return excel_data
        except Exception as e:
            print('AdmProductionExcelExport error:', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdmTimesheetExport(generics.GenericAPIView):
    def boolean_check(self, data):
        if data == True:
            return 'Yes'
        elif data == False:
            return 'No'
        else:
            return 'N/A'

    def user_report_export(self, prod_timesht_info):
        try:
            workbook = Workbook()
            workbook.remove(workbook.active)
            worksheet = workbook.create_sheet(title='Employee Timesheet Report', index=1)
            std_columns = ['Task Date', 'User', 'Project', 'Task Name', 'Task Summary','Start Date',
                'End Date', 'Due Date', 'Total Time', 'Task Status', 'Task Assigned By', 'Task Meeting',
                'Comments', 'Skills Used', 'Peer Review Status', 'Peer Reviewed By', #'TimeSheet Status',
                'Code Commited', 'Code Comments', 'Coding Standards', 'Updated']
            columns = std_columns
            columns_width = []
            row_num = 1
            cell = worksheet.cell(row=row_num, column=2)
            cell.value = 'SE_Tracker: Employee Timesheet Report - ' + datetime.now().strftime('%m-%d-%Y')
            cell.font = Font(bold=True)
            row_num = row_num + 1
            row_num = row_num + 1

            thin_border = Border(
                left=Side(style='thin'), right=Side(style='thin'),
                top=Side(style='thin'), bottom=Side(style='thin')
            )

            for col_num, column_title in enumerate(columns, 1):
                worksheet.row_dimensions[row_num].height = 25
                cell = worksheet.cell(row=row_num, column=col_num)
                cell.value = column_title
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                cell.font = Font(bold=True, size='10')
                cell.border = thin_border
                cell.fill = PatternFill(start_color="8ea9db", fill_type="solid")
                columns_width.append(len(str(column_title))*1.32)

            for rec in prod_timesht_info:
                row_num+=1
                row = []
                row.append(rec['task_date'].strftime('%m-%d-%Y')) if rec['task_date'] else row.append('')
                row.append(rec['user_fname']+' '+rec['user_lname']) if rec['user_id'] else row.append('')
                row.append(rec['project_name']) if rec['project_id'] else row.append('')
                row.append(rec['task_name']) if rec['task_name'] else row.append('')
                row.append(rec['task_summary']) if rec['task_summary'] else row.append('')
                row.append(rec['start_date'].strftime('%m-%d-%Y')) if rec['start_date'] else row.append('')
                row.append(rec['end_date'].strftime('%m-%d-%Y')) if rec['end_date'] else row.append('')
                row.append(rec['due_date'].strftime('%m-%d-%Y')) if rec['due_date'] else row.append('')
                row.append(hour_to_min(rec['total_time'])) if rec['total_time'] else row.append('')
                row.append(rec['task_sts_name']) if rec['task_status_id'] else row.append('')
                row.append(rec['task_assigned_fname']+' '+rec['task_assigned_lname']) if rec['task_assigned_by_id'] else row.append('')
                row.append(self.boolean_check(rec['task_meeting'])) if rec['task_meeting'] else row.append('')
                row.append(rec['comments']) if rec['comments'] else row.append('')
                # row.append(rec['timesheet_status']) if rec['timesheet_status'] else row.append('')
                row.append(rec['skills_used']) if rec['skills_used'] else row.append('')
                row.append(self.boolean_check(rec['peer_review_sts'])) if rec['peer_review_sts'] else row.append('')
                row.append(rec['peer_review_fname']+' '+rec['peer_review_lname']) if rec['peer_review_by_id'] else row.append('')
                row.append(self.boolean_check(rec['code_commited'])) if rec['code_commited'] else row.append('')
                row.append(self.boolean_check(rec['code_comments'])) if rec['code_comments'] else row.append('')
                row.append(self.boolean_check(rec['coding_standards'])) if rec['coding_standards'] else row.append('')
                row.append(rec['updated'].strftime('%m-%d-%Y')) if rec['updated'] else row.append('')
                for col_num, cell_value in enumerate(row, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    cell.border = thin_border
                    cell.font = Font(size='10')
                    if columns_width[col_num - 1] < len(str(cell_value)):
                        columns_width[col_num - 1] = len(str(cell_value))
                    if col_num in [1, 6, 7, 8, 9, 10, 12, 15, 17, 18, 19, 20]:
                        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

            dim_holder = DimensionHolder(worksheet=worksheet)            
            for col in range(worksheet.min_column, worksheet.max_column + 1):
                dim_holder[get_column_letter(col)] = ColumnDimension(worksheet, min=col, max=col, width=columns_width[col - 1])
            worksheet.column_dimensions = dim_holder
            date_format = date.today().strftime("%m%d%y")
            file_name = 'SE Tracker Employee TimeSheet Reports' + '-' + str(date_format)
            # print(file_name,'file name')
            response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename={0}.xlsx'.format(file_name)
            response['Access-Control-Expose-Headers'] = "Content-Disposition"
            workbook.save(response)
            return response
        except Exception as e :
            print('user_report_export', str(e))
            return str(e)

    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AdmTimesheetListSerializer)
    def post(self, request):
        try:
            start_time = request.data['date_range']['start_date']
            end_time = request.data['date_range']['end_date']
            user_lst = request.data['user_lst']
            filters = {}
            if request.data['user_lst']:
                filters['user_id__in'] = user_lst
            if request.data['status'] != None and request.data['status'] != 0:
                filters['task_status__in'] = request.data['status']
            filter_query = Q(**filters)
            # print(filter_query, 'query')
            prod_timesht_info = ProdTimeSheet.objects.filter(filter_query, task_date__range=[start_time, end_time]
            ).values().annotate(project_name=F('project__name'), task_assigned_fname=F('task_assigned_by__first_name'),
            task_assigned_lname=F('task_assigned_by__last_name'), task_sts_name=F('task_status__name'),
            user_fname=F('user__first_name'), user_lname=F('user__last_name'), peer_review_fname=F('peer_review_by__first_name'),
            peer_review_lname=F('peer_review_by__last_name')).order_by('task_date')
            export_info = self.user_report_export(prod_timesht_info)
            return export_info
        except Exception as e:
            print('ReportExport Error: ', str(e))
            return Response({"Invalid Response": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdmTimesheetProdDetail(generics.GenericAPIView):
    def get_prod_timesheet(self, request, task_date, user_id):
        task_date = datetime.strptime(task_date, '%Y-%m-%d')
        try:
            prod_report = ProdTimeSheet.objects.filter(user_id=user_id, task_date=task_date).annotate(
                usr_fname=F('user_id__first_name'), usr_lname=F('user_id__last_name'), prod_per=F('prod_percent'),
                project_name=F('project__name'), task_sts_name=F('task_status__name'),
                task_assigned_by_fname=F('task_assigned_by__first_name'),
                task_assigned_by_lname=F('task_assigned_by__last_name')).values(
                'user_id', 'task_name', 'task_summary', 'total_time', 'usr_fname',
                'usr_lname', 'prod_per', 'project_name', 'task_sts_name','task_assigned_by_fname',
                'task_assigned_by_lname').order_by('task_date')
            if prod_report:
                for prod_data in prod_report:
                    prod_data['total_time'] = hour_to_min(prod_data['total_time'])
            return prod_report
        except Exception as e:
            print('Production Timesheet error - ', str(e))
            logger.warning(f": Bad Request: {request.path}: {request.data}")
            return str(e)

    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=TimesheetProdDetailSerializer)
    def post(self, request):
        try:
            task_date = request.data['req_date']
            user_id = request.data['user_id']
            usr_data = self.get_prod_timesheet(request, task_date, user_id)
            return Response(usr_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('TimesheetProdDetail error: ' ,str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UsrTimesheetProdDetail(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UsrTimesheetProdDetailSerializer)
    def post(self, request):
        try:
            task_date = request.data['req_date']
            user_id = request.user.id
            usr_data = AdmTimesheetProdDetail().get_prod_timesheet(request, task_date, user_id)
            return Response(usr_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('TimesheetProdDetail error: ' ,str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UsrTaskSearch(generics.GenericAPIView):
    @swagger_auto_schema(request_body=UsrTaskSearchSerializer)
    def post(self, request):
        try:
            req_data = request.data['req_data'].lower().strip()
            user_id = request.user.id
            prod_info = ProdTimeSheet.objects.select_related('task_status__name').filter(
                user=user_id, task_name__icontains=req_data, task_status__name='Inprogress',
                old_task_id__isnull=True, project_id=request.data['project_id'],
                is_completed=False).values('id', 'task_name', 'task_summary',
                'task_assigned_by', 'task_date').annotate(
                task_assigned_by_fname=F('task_assigned_by__first_name'),
                task_assigned_by_lname=F('task_assigned_by__last_name')
                )
            return Response(prod_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('UsrTaskSearch error: ' ,str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdmTaskSearch(generics.GenericAPIView):
    @swagger_auto_schema(request_body=AdmTaskSearchSerializer)
    def post(self, request):
        try:
            req_data = request.data['req_data']
            filters = {}
            filters['user_id'] = request.data['user_id']
            filters['project_id'] = request.data['project_id']
            filters['task_name__icontains'] = req_data.lower().strip()
            filter_query = Q(**filters)
            # print(filter_query, 'filter_query')
            prod_info = ProdTimeSheet.objects.select_related('task_status__name').filter(
                filter_query, task_status__name='Inprogress', old_task_id__isnull=True, is_completed=False
                ).values('id', 'task_name', 'task_summary', 'task_assigned_by', 'task_date').annotate(
                task_assigned_by_fname=F('task_assigned_by__first_name'),
                task_assigned_by_lname=F('task_assigned_by__last_name')
                )
            return Response(prod_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('AdmTaskSearch error: ' ,str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class PrvDayTaskList(generics.GenericAPIView):
    def get_last_work_date(self, user_id):
        try:
            wrk_date = ProdTimeSheet.objects.filter(user=user_id, task_date__lt=datetime.now().date()).order_by('-task_date').values('task_date').first()
            if wrk_date:
                last_wrk_date = wrk_date['task_date']
                return last_wrk_date
            else:
                raise Exception('No data found in requested user!')
        except Exception as e:
            raise Exception('Invalid Request: ', str(e))

    def get(self, request):
        try:
            get_prv_date = self.get_last_work_date(request.user.id)
            # print(get_prv_date,'get_prv_date')
            try:
                user_id = request.user.id
                usr_info = User.objects.get(id=user_id)
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Not Found": "Id not found"}, status=status.HTTP_400_BAD_REQUEST)
            # dt_time = datetime.now(time_zone)
            dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
            today = dt_time.strftime("%Y-%m-%d")
            today = datetime.strptime(today,"%Y-%m-%d")
            am_pm = dt_time.strftime('%p')
            filters = {}
            filters['task_date'] = get_prv_date
            filters['user_id'] = user_id
            qry_filter = Q(**filters)
            # print(qry_filter,'qry_filter')
            if usr_info.timechk_sts:
                if am_pm == "PM":
                    prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter).annotate(
                        user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                        peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                        flag=Value(True, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
                        project_name=F('project__name')).values().order_by("-task_date", '-id')
                else:
                    # selected_date = selected_date-timedelta(days=1) """can not backtrac the object selected date"""
                    prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter).annotate(
                        user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                        peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                        flag=Value(True, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), task_assigned_lname=F('task_assigned_by__last_name'),
                        project_name=F('project__name')).values().order_by("-task_date", '-id')
            else:
                prodtimesht_list = ProdTimeSheet.objects.filter(qry_filter).annotate(
                    user_fulname=Concat(F('user_id__first_name'), Value(' '), F('user_id__last_name'), output_field=CharField()),
                    peer_review_fname=F('peer_review_by__first_name'), peer_review_lname=F('peer_review_by__last_name'), tasksts_name=F('task_status_id__name'),
                    flag=Value(True, output_field=BooleanField()), task_assigned_fname=F('task_assigned_by__first_name'), 
                    task_assigned_lname=F('task_assigned_by__last_name'), project_name=F('project__name')).values().order_by("-task_date", '-id')
            # prv_date_list = get_last_three_date(user_id=user_id)
            # # print(prv_date_list,'prv_date_list')
            # for i in prodtimesht_list:
            #     timesht_access, val_message = prv_edit_permission(i['task_date'], prv_date_list)
            #     if timesht_access:
            #         i['flag'] = True
            #     else:
            #         i['flag'] = False
            return Response(prodtimesht_list, status=status.HTTP_200_OK)
        except Exception as e:
            print('PrvTaskList error: ', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CreatePrvDayTask(generics.GenericAPIView):
    @swagger_auto_schema(request_body=CreateTaskSerializer)
    def post(self, request):
        try:
            task_date = PrvDayTaskList().get_last_work_date(request.user.id)
            if datetime.strptime(request.data['start_date'], "%Y-%m-%d") > datetime.strptime(request.data['end_date'], "%Y-%m-%d"):
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Date Info": "Startdate is always less than enddate. Please check your startdate"}, status=status.HTTP_400_BAD_REQUEST)
            request.data['task_date'] = task_date.strftime('%Y-%m-%d')
            try:
                usr_info = User.objects.get(id=request.user.id)
                request.data['user'] = request.user.id
            except Exception as e:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response({"Not Found":"User Id not found"},status=status.HTTP_400_BAD_REQUEST)
            # dt_time = datetime.now(time_zone)
            dt_time = datetime.now().replace(tzinfo=ZoneInfo('Asia/Kolkata'))
            today_date = dt_time.strftime("%Y-%m-%d")
            today_date = datetime.strptime(today_date,"%Y-%m-%d")
            am_pm =dt_time.strftime('%p')
            if usr_info.timechk_sts:
                if am_pm == "PM":
                    prodtimesheet_info = ProdTimeSheet.objects.filter(
                        user=request.data['user'], task_date__lt=today_date
                        ).values('task_date','id').order_by('-task_date')[:1]
                else:
                    today_date = today_date-timedelta(days=1)
                    prodtimesheet_info = ProdTimeSheet.objects.filter(
                        user=request.data['user'], task_date__lt=today_date
                        ).values('task_date','id').order_by('-task_date')[:1]
            else:
                prodtimesheet_info = ProdTimeSheet.objects.filter(
                    user=request.data['user'], task_date__lt=today_date
                    ).values('task_date','id').order_by('-task_date')[:1]
            request1=request.data
            timesht_access, val_message = timesheet_permission(request1, prodtimesheet_info, today_date, upd_flag=False)
            if timesht_access:
                serializer = CreateTaskSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                try:
                    task_obj = serializer.save()
                    out_data = TaskSerializer(task_obj).data
                    return Response(out_data, status=status.HTTP_200_OK)
                except Exception as e:
                    logger.warning(f": Bad Request: {request.path}: {request.data}")        
                    return Response({"Invaild Data": str(e)}, status=status.HTTP_400_BAD_REQUEST)
            else:
                logger.warning(f": Bad Request: {request.path}: {request.data}")
                return Response('Add Previous timesheet error!', status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('create prve day task error: ', str(e))
            return Response({"Invalid Request": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
def queryset_for_task_list(self):
    task_info=(
            ProdTimeSheet.objects.select_related('task_status__name').values('id', 'task_name', 'task_summary',
                'task_assigned_by', 'task_date').annotate(
                status=F('task_status__name'),
                task_assigned_by_fname=F('task_assigned_by__first_name'),
                task_assigned_by_lname=F('task_assigned_by__last_name')
                )
    )
    return task_info


class UserIncompleteTaskList(DxAPIView):
    permission_classes =[]
    @swagger_auto_schema(request_body=UserIncompleteTaskListSerializer)
    def get_queryset(self):
        try:
            request = self.request
            project_id = request.data.get("project_id")
            user_id = request.data.get("user_id")

            doc_Info = queryset_for_task_list(self)
            doc_Info = doc_Info.filter(project_id=project_id,user=user_id,task_status__name__in=['Inprogress','Hold'],
                                       old_task_id__isnull=True,is_completed=False).order_by('-id')

            return doc_Info
        except Exception as e:
            print('PayorDocFileList Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CommentSuggestion(generics.GenericAPIView):
    def get(self, request):
        User_object = User.objects.filter(id=request.user.id).first()
        result ={}
        if User_object.dept_id == 9:
            result = {
                "Leave Request": {
                    "Unplanned Emergency": [
                        "Kindly approve the unplanned emergency leave.",
                    ],
                    "Sick Leave": [
                        "Kindly approve the sick leave.",
                    ],
                    "Planned Leave": [
                        "Kindly approve the planned leave.",
                    ],
                }
            }
        return Response(result)
