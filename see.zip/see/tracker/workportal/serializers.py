from rest_framework import serializers
from django.db import transaction
from datetime import date, datetime, timezone

from .models import *


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Projects
        fields = '__all__'

class CreateProjectSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    class Meta:
        model = Projects
        fields = '__all__'

    def create(self, validated_data):
        proj_instance = Projects.objects.create(
            name = validated_data['name'],
            desc = validated_data['desc'],
            status = validated_data['status'],
            department = validated_data['department'],
            created = datetime.now(timezone.utc)
        )
        return proj_instance

    def update(self, instance, validated_data):
        with transaction.atomic():
            instance.name = validated_data['name']
            instance.desc = validated_data['desc']
            instance.status = validated_data['status']
            instance.department = validated_data['department']
            instance.updated = datetime.now(timezone.utc)
            instance.save()
        return instance

class CreateTaskSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False)
    old_task_id = serializers.IntegerField(required=False, allow_null=True)
    class Meta:
        model = ProdTimeSheet
        fields = ('id', 'project', 'task_name', 'task_summary', 'task_assigned_by',
            'task_meeting', 'start_date', 'end_date', 'due_date', 'total_time',
            'task_status',  'comments', 'timesheet_status', 'user', 'prod_percent',
            'skills_used', 'peer_review_sts', 'peer_review_by', 'code_commited',
            'code_comments', 'coding_standards', 'task_date', 'old_task_id',
            'created_by', 'updated_by')
        extra_kwargs = {
            'task_date': {'required': False},
            'updated_by': {'required': False, 'allow_null': True}
        }
    def create(self, validated_data):
        timesheet_obj = ProdTimeSheet.objects.create(
            entry_date = datetime.now(timezone.utc),
            project = validated_data['project'],
            task_name = validated_data['task_name'],
            task_summary = validated_data['task_summary'],
            task_assigned_by = validated_data['task_assigned_by'],
            task_meeting = validated_data['task_meeting'],
            start_date = validated_data['start_date'],
            end_date = validated_data['end_date'],
            due_date = validated_data['due_date'],
            total_time = validated_data['total_time'],
            task_status = validated_data['task_status'],
            comments = validated_data['comments'],
            timesheet_status = validated_data['timesheet_status'],
            user = validated_data['user'],
            prod_percent = validated_data['prod_percent'],
            skills_used = validated_data['skills_used'],
            peer_review_sts = validated_data['peer_review_sts'],
            peer_review_by = validated_data['peer_review_by'],
            code_commited = validated_data['code_commited'],
            code_comments = validated_data['code_comments'],
            coding_standards = validated_data['coding_standards'],
            task_date = validated_data['task_date'],
            old_task_id = validated_data.get('old_task_id', None),
            created_by = validated_data['created_by']
        )
        if validated_data['task_status'].name == 'Completed':
            if validated_data['old_task_id']:
                ProdTimeSheet.objects.filter(pk=validated_data['old_task_id']).update(
                    is_completed = True
                )
                timesheet_obj.is_completed = True
                timesheet_obj.save()
        return timesheet_obj
    
    def update(self, instance, validated_data):
        with transaction.atomic():
            instance.project = validated_data['project']
            instance.task_name = validated_data['task_name']
            instance.task_summary = validated_data['task_summary']
            instance.task_assigned_by = validated_data['task_assigned_by']
            instance.task_meeting = validated_data['task_meeting']
            instance.start_date = validated_data['start_date']
            instance.end_date = validated_data['end_date']
            instance.due_date = validated_data['due_date']
            instance.total_time = validated_data['total_time']
            instance.task_status = validated_data['task_status']
            instance.comments = validated_data['comments']
            instance.timesheet_status = validated_data['timesheet_status']
            instance.user = validated_data['user']
            instance.prod_percent = validated_data['prod_percent']
            instance.skills_used = validated_data['skills_used']
            instance.peer_review_sts = validated_data['peer_review_sts']
            instance.peer_review_by = validated_data['peer_review_by']
            instance.code_commited = validated_data['code_commited']
            instance.code_comments = validated_data['code_comments']
            instance.coding_standards = validated_data['coding_standards']
            instance.updated = datetime.now(timezone.utc)
            instance.task_date = validated_data['task_date']
            instance.old_task_id = validated_data.get('old_task_id', None)
            instance.updated_by = validated_data['updated_by']
            instance.save()

            if validated_data['task_status'].name == 'Completed':
                try:
                    if validated_data['old_task_id']:
                        ProdTimeSheet.objects.filter(pk=validated_data['old_task_id']).update(
                            is_completed = True)
                        instance.is_completed = True
                        instance.save()
                except Exception as e:
                    print('Input not found: ', str(e))
            elif validated_data['task_status'].name == 'Inprogress':
                try:
                    if validated_data['old_task_id']:
                        ProdTimeSheet.objects.filter(pk=validated_data['old_task_id']).update(
                            is_completed = False)
                        instance.is_completed = False
                        instance.save()
                except Exception as e:
                    print('Input not found: ', str(e))
        return instance

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProdTimeSheet
        fields = '__all__'

class DateRangeSerializer(serializers.Serializer):
    start_date = serializers.DateField()
    end_date = serializers.DateField()

class TodaytimesheetListSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()

class SelectedTsListSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()
    status = serializers.ListField(
        child = serializers.IntegerField()
    )

class ReportPreviewSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()
    sts_list = serializers.ListField(
        child = serializers.IntegerField()
    )

class AdmTimesheetListSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()
    user_lst = serializers.ListField(
        child = serializers.IntegerField()
    )
    status = serializers.ListField(
        child = serializers.IntegerField()
    )

class UserDeleteTaskSerializer(serializers.Serializer):
    prod_id = serializers.IntegerField()

class BiometricUpdateByUserListSerializer(serializers.Serializer):
    user_list = serializers.ListField(
        child = serializers.IntegerField()
    )
    date_range = DateRangeSerializer()

class UserAttendSerializer(serializers.Serializer):
    req_month = serializers.DateField()

class UserProdReportSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()
    usr_list = serializers.ListField(
        child=serializers.IntegerField()
    )
    usr_active_flag = serializers.BooleanField()

class UserProdReportUsrSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()

class AdmAttendanceReportSerializer(serializers.Serializer):
    year = serializers.IntegerField()
    user_list = serializers.ListField(
        child = serializers.IntegerField()
    )

class AdmProdExcelExportSerializer(serializers.Serializer):
    date_range = DateRangeSerializer()
    usr_list = serializers.ListField(
        child=serializers.IntegerField()
    )

class UsrAttendanceReportSerializer(serializers.Serializer):
    year = serializers.IntegerField()

class TimesheetProdDetailSerializer(serializers.Serializer):
    req_date = serializers.DateField()
    user_id = serializers.IntegerField()

class UsrTimesheetProdDetailSerializer(serializers.Serializer):
    req_date = serializers.DateField()

class UsrTaskSearchSerializer(serializers.Serializer):
    req_data = serializers.CharField()
    project_id = serializers.IntegerField()

class AdmTaskSearchSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    req_data = serializers.CharField()
    project_id = serializers.IntegerField()

class UserIncompleteTaskListSerializer(serializers.Serializer):
    project_id = serializers.IntegerField()
    user_id = serializers.IntegerField()

class ActiveProjectAndUserListSerializer(serializers.Serializer):
    is_show_all = serializers.BooleanField()

class projectListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Projects
        fields = '__all__'
    def to_representation(self, instance):
        """ Ensures extra fields are included in the response """
        data = super().to_representation(instance)
        data['department_name'] = instance.department.name
        return data

class  CommentSuggestionSerializer(serializers.Serializer):
     pass