from django.db import models
from django.db.models import UniqueConstraint

from authapi.models import User,Department
# Create your models here.

class BiometricDetails(models.Model):
    bio_id = models.CharField(max_length=250, null=True, blank=True)
    bio_name = models.CharField(max_length=250, null=True, blank=True)
    process_date = models.DateField(null=True, blank=True)
    first_punch = models.DateTimeField(null=True, blank=True)
    out_punch = models.DateTimeField(null=True, blank=True)
    work_time = models.BigIntegerField(null=True, blank=True)   # time in minutes
    work_time_hhmm =models.DurationField(null=True, blank=True)
    department_name = models.CharField(max_length=250, null=True, blank=True)
    user = models.ForeignKey(User, related_name='rn_bio_user', on_delete=models.CASCADE, null=True, blank=True )
    entry_time = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_on = models.DateTimeField(null=True, blank=True)

class Projects(models.Model):
    name = models.CharField(max_length=100, blank=False)
    desc = models.CharField(max_length=250, blank=True)
    status = models.BooleanField(default=True, null=True, blank=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='project_dept', null=True, blank=True)
    created = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated = models.DateTimeField(null=True, blank=True)
    is_down_time = models.BooleanField(default=False, null=True, blank=True)
    order_id = models.IntegerField(null=True, blank=True)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['name', 'department'], name='unique_project_per_department')
        ]

class TasKStatus(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)
    desc = models.CharField(max_length=100, null=True, blank=True)
    status = models.BooleanField(default=True, null=True)
    order_id = models.IntegerField(default=0, null=True)
    created = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated = models.DateTimeField(null=True, blank=True)

class ProdTimeSheet(models.Model):
    entry_date = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    project = models.ForeignKey(Projects, related_name='rn_proid', on_delete=models.CASCADE, null=True, blank=True)
    task_name = models.TextField(null=True, blank=True)
    task_summary = models.TextField(null=True, blank=True)
    task_assigned_by = models.ForeignKey(User, related_name='rn_assigned_by', on_delete=models.CASCADE, null=True, blank=True)
    task_meeting = models.BooleanField(null=True, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    total_time = models.IntegerField(default=0, null=True, blank=True)  # time in minutes
    task_status = models.ForeignKey(TasKStatus, related_name='rn_task_sts_id', on_delete=models.CASCADE, null=True, blank=True)
    comments = models.TextField(null=True, blank=True)
    timesheet_status = models.BooleanField(default=True, null=True, blank=True)
    user = models.ForeignKey(User, related_name='rn_created_by', on_delete=models.CASCADE, null=True, blank=True)
    prod_percent = models.DecimalField(null=True, blank=True, default=0, max_digits=6, decimal_places=2)
    updated = models.DateTimeField(null=True, blank=True)
    skills_used = models.TextField(null=True, blank=True)
    peer_review_sts = models.BooleanField(null=True, blank=True)
    peer_review_by = models.ForeignKey(User, related_name='pear_rvw_by_id', on_delete=models.CASCADE, null=True, blank=True)
    code_commited = models.BooleanField(null=True, blank=True)
    code_comments = models.BooleanField(null=True, blank=True)
    coding_standards = models.BooleanField(null=True, blank=True)
    task_date = models.DateField(null=True, blank=True)
    old_task_id = models.IntegerField(null=True, blank=True)
    created_by = models.ForeignKey(User, related_name='tsk_create_by_id', on_delete=models.CASCADE, null=True, blank=True)
    updated_by = models.ForeignKey(User, related_name='tsk_upd_by_id', on_delete=models.CASCADE, null=True, blank=True)
    is_completed = models.BooleanField(null=True, blank=True, default=False)

class UserAttandance(models.Model):
    month = models.DateField(null=True, blank=True)
    user = models.ForeignKey(User, related_name='usr_attendance', on_delete=models.CASCADE, null=True, blank=True)
    tot_hrs = models.IntegerField(null=True, blank=True, default=0)
    tot_leaves = models.IntegerField(null=True, blank=True, default=0)
    hrs_diff = models.IntegerField(null=True, blank=True, default=0)
    is_joined_month = models.BooleanField(default=False, null=True, blank=True)
    leave_dates = models.TextField(blank=True, null=True)
    tot_work_days = models.IntegerField(null=True, blank=True, default=0)
    woh_dates = models.TextField(blank=True, null=True) #Work on holiday dates
    woh_tot_hrs = models.IntegerField(null=True, blank=True, default=0) #Work on holiday hrs

    class Meta:
        constraints = [
            UniqueConstraint(
            fields =["month", "user"],
            name = "unique_month_user"
            )
        ]
