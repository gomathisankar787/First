from django.urls import path


from . import views





urlpatterns = [
    path('project_list/', views.ProjectList.as_view()),
    path('act_project_list/', views.ActProjectList.as_view()),
    path('active_project_list/',views.ActiveProjectList.as_view()),
    path('active_user_list/',views.ActiveUserList.as_view()),
    path('create_project/', views.CreateProject.as_view()),
    path('update_project/', views.UpdateProject.as_view()),
    path('create_task/', views.CreateTask.as_view()),
    path('update_task/', views.EditTimeSheet.as_view()),
    path('today_timesht_list/', views.TodaytimesheetList.as_view()),
    path('selected_timesht_list/', views.SelectedTimesheetListView.as_view()),
    path('task_status_info/', views.TaskStatusInfo.as_view()),
    path('get_today_date/', views.GetTodayDate.as_view()),
    path('get_last_task_date/', views.GetPrvTaskDate.as_view()),
    path('usr_report_preview/', views.UsrReportPreview.as_view()),
    path('admtimesht_add/', views.AdmTimesheetAdd.as_view()),
    path('admtimesht_edit/', views.AdmTimesheetEdit.as_view()),
    path('admtimesht_list/', views.AdmTimesheetList.as_view()),
    path('get_biomet_data/', views.GetBiometData.as_view()),    # Get biomet data test api for one give date
    path('delete_task/', views.UserDeleteTask.as_view()),
    path('delete_task_by_adm/', views.DeleteTaskByAdm.as_view()),
    path('get_user_prod_details/', views.GetUserProdDetails.as_view()), # last workday biomet data get api
    path('backup_database/', views.bak_db),  # api to run celery functions
    path('user_attend_manual_scheduler/', views.UserAttendManualScheduler.as_view()),  # Attendance report update by manual process
    path('biometric_update_user_list/', views.BiometricUpdateByUserList.as_view()), # Biometric update by request users only
    path('adm_prod_report/', views.AdmProdReport.as_view()),
    path('user_prod_report/', views.UserProdReport.as_view()),
    path('adm_attendance_report/', views.AdmAttendanceReport.as_view()),
    path('usr_attendance_report/', views.UsrAttendanceReport.as_view()),
    path('chck_holiday/', views.CheckHoliday.as_view()),  #Not used
    path('adm_prod_excel_export/', views.AdmProductionExcelExport.as_view()),
    path('adm_timesheet_export/', views.AdmTimesheetExport.as_view()),
    path('adm_prod_detail_view/', views.AdmTimesheetProdDetail.as_view()),
    path('usr_prod_detail_view/', views.UsrTimesheetProdDetail.as_view()),
    path('usr_task_search/', views.UsrTaskSearch.as_view()),
    path('adm_task_search/', views.AdmTaskSearch.as_view()),
    path('create_prv_day_task/', views.CreatePrvDayTask.as_view()),
    path('prv_day_task_list/', views.PrvDayTaskList.as_view()),
    path('usr_incomplet_task_list',views.UserIncompleteTaskList.as_view()),
    path('commentSuggestion',views.CommentSuggestion.as_view())

]
