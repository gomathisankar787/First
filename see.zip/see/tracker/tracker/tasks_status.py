from operator import getitem
from django.template.loader import get_template
from django.core.mail import EmailMessage
from django.db import connections, transaction
from django.apps import apps
from django.core import mail
from django.db.models import Prefetch, ExpressionWrapper, DurationField, DateTimeField
from django.db.models import Q, Max, Case, When, Sum, Count, F, Avg
from django.db.models.functions import ExtractDay
from datetime import datetime, date, timedelta, timezone
from pathlib import Path, PureWindowsPath
from collections import OrderedDict,defaultdict
from zoneinfo import ZoneInfo
import ast, subprocess, os


from celery import shared_task


from tracker.settings import EMAIL_HOST_USER, EMAIL_TRIGGER, DATABASES, SE_APP_STORAGE, WEB_URL


def get_cclist(cc_json):
    usr_id = []  
    cc_lst = []
    cc_list_ord = OrderedDict()
    for cc_ind in cc_json:
        usr_id.append(cc_ind["usr_id"])
        cc_list_ord[cc_ind["usr_id"]] = ''
    if len(usr_id) > 0:
        user_obj = apps.get_model(app_label='authapi', model_name='User')
        usr_list = user_obj.objects.filter(id__in=usr_id,is_active=True)                
        for usr_in in usr_list:
            cc_list_ord[usr_in.id] = usr_in.email                
        for key, value in cc_list_ord.items():
            cc_lst.append(value)
    return cc_lst

def ticket_get_cclist(cc_json,dept):
    usr_id = []
    cc_lst = []
    cc_list_ord = OrderedDict()
    for cc_ind in cc_json:
        usr_id.append(cc_ind["usr_id"])
        cc_list_ord[cc_ind["usr_id"]] = ''
    if usr_id:
        user_obj = apps.get_model(app_label='authapi', model_name='User')
        usr_list = user_obj.objects.filter(id__in=usr_id,is_active=True)
        for usr_in in usr_list:
            if usr_in.dept_id == dept:
                cc_list_ord[usr_in.id] = usr_in.email
        for key, value in cc_list_ord.items():
            if value:
                cc_lst.append(value)
    return cc_lst

class BiometModel():
    def __init__(self, bio_id=None, bio_name=None, process_date=None, first_punch=None,
            work_time=None, work_time_hhmm=None, out_punch=None, department_name=None,
            id=None, user_id=None, entry_time=None, updated_on=None):
        self.id = id
        self.bio_id = bio_id
        self.bio_name = bio_name
        self.process_date = process_date
        self.first_punch = first_punch
        self.work_time = work_time
        self.work_time_hhmm = work_time_hhmm
        self.out_punch = out_punch
        self.department_name = department_name
        self.user_id = user_id
        self.entry_time = entry_time
        self.updated_on = updated_on

@shared_task
def get_user_biomet_details(request):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Eamil notification disabled'
    User = apps.get_model(app_label='authapi', model_name='User')
    HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
    
    try:
        BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
        max_date = BiometricDetails.objects.aggregate(Max('process_date'))
        print(max_date, 'max_date')
        if max_date['process_date__max'] == None:
            try:
                usr_biomet = []
                with connections['biomet_db'].cursor() as cursor:# Need to change query
                    # cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                    # "WHERE department_name!='RCM'and convert(date, ProcessDate, 103) BETWEEN '2024-06-01' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                    cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                    "WHERE convert(date, ProcessDate, 103) BETWEEN '2024-06-01' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                    usr_biomet = cursor.fetchall() # department_name in ('DEV', 'R&D') and 
            except Exception as ex:
                print('biomet_db error: ', str(ex))
        elif max_date['process_date__max'] != None:
            try:
                usr_biomet = []
                with connections['biomet_db'].cursor() as cursor: # Need to change query
                    # cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                    # "WHERE department_name!='RCM'and convert(date, ProcessDate, 103) BETWEEN '"+ (max_date['process_date__max']+timedelta(days=1)).strftime("%Y-%m-%d")+"' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                    cursor.execute("SELECT UserID, UserName, convert(date, ProcessDate, 103), convert(datetime, Punch1, 103), WorkTime, WorkTime_HHMM, convert(datetime, OutPunch, 103), department_name FROM Mx_VEW_APIDailyAttendance " +
                    "WHERE convert(date, ProcessDate, 103) BETWEEN '"+ (max_date['process_date__max']+timedelta(days=1)).strftime("%Y-%m-%d")+"' AND '" + (datetime.today()-timedelta(days=1)).date().strftime("%Y-%m-%d") + "'")
                    usr_biomet = cursor.fetchall() #department_name in ('DEV', 'R&D') and 
            except Exception as ex:
                print('biomet_db error: ',str(ex))
        print('usr_biomet_len:', len(usr_biomet))
        user_bio_id_list = User.objects.all().values('id', 'bm_usr_id')
        user_data = {}
        for usr_data in user_bio_id_list:
            user_data[usr_data['bm_usr_id']] = usr_data
        model_list = []
        for prs in usr_biomet:
            bio_model_data = BiometModel(*prs)
            bio_model_data.entry_time = datetime.now(timezone.utc)
            if bio_model_data.bio_id in user_data:
                bio_model_data.user_id = user_data[bio_model_data.bio_id]['id']
            model_list.append(bio_model_data)
        # print(model_list, 'model_list', len(model_list))

        """Use bulk create method"""
        bio_data = []
        for usr_bio in model_list:
            bio_data_obj = BiometricDetails(
                None,
                bio_id = usr_bio.bio_id,
                bio_name = usr_bio.bio_name,
                process_date = usr_bio.process_date,
                first_punch = usr_bio.first_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if usr_bio.first_punch != None else None,
                out_punch = usr_bio.out_punch.replace(tzinfo=ZoneInfo("Asia/Kolkata")) if usr_bio.out_punch != None else None,
                work_time = usr_bio.work_time,
                work_time_hhmm = usr_bio.work_time_hhmm,
                department_name = usr_bio.department_name,
                user_id = usr_bio.user_id
                )
            bio_data.append(bio_data_obj)
        # print(bio_data, 'bio_data', len(bio_data))
        biomet_detais = BiometricDetails.objects.bulk_create(bio_data)
        attendance_data = get_attendance_report_data('request')
        return "Success"
    except Exception as e:
        print('get_user_biomet_details error:', str(e))
        cc_json = {}
        try:
            email_list = []
            usr_data = []
            user_data = User.objects.filter(username='devadmin')
            holiday_qry = HolidayList.objects.filter(holiday_date__year=datetime.today().strftime("%Y"), status=True)
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if datetime.today().strftime("%Y-%m-%d") in holiday_list:
                print('get_user_biomet_details error email skipped for holiday')
                return 'get_user_biomet_details error email skipped for holiday'
            prv_task_day = datetime.today() - timedelta(days=1)
            from_email = EMAIL_HOST_USER
            cc_list = get_cclist(cc_json)
            if user_data.exists():
                for usr_list in user_data:
                    try:
                        recipient_list =['krishnakumar.k@solvedge.in', 'duraibabu.g@solvedge.in'] # usr_list.email
                        message = f"""<p style="font-size:0.8rem;">Hi {usr_list.first_name} {usr_list.last_name},</p>
                                    <p style="font-size:0.8rem;">This is a gentle reminder that user's biometric details was not updated on {prv_task_day.strftime("%m/%d/%Y")}.
                                    Please take necessary action to update user's biometric details.</p>
                                    <br>
                                    <p style="font-size:0.8rem;">- SE Notification System</p>"""
                        msg = EmailMessage(
                            'Biometric Details Error Reminder',
                            message,
                            'SE Tracker Failure Alert <do_not_reply@solvedge.in>',
                            recipient_list
                        )
                        msg.content_subtype = "html" # Main content is now text/html
                        email_list.append(msg)
                    except Exception as e:
                        print('Biometric reminder email error - ',e)
            if len(email_list) > 0:
                connection = mail.get_connection()
                connection.send_messages(email_list)
            print('email triggered')
            return 'email triggered'
        except Exception as ex:
            print('error',ex)
        return "User Biomet Details Not Updated"

def holiday_info(req_date, end_date):
    """Returns requested month's shift vise Solvedge holiday list
    day_holiday_list, mid_holiday_list, ngt_holiday_list
    """
    day_holiday_list = []
    mid_holiday_list = []
    ngt_holiday_list = []
    HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
    holiday_qry = HolidayList.objects.filter(
        holiday_date__year__range=[req_date.year, end_date.year], status=True)
    if holiday_qry.exists():
        for holiday in holiday_qry:
            if holiday.shift_id == 1:
                day_holiday_list.append(holiday.holiday_date)
            elif holiday.shift_id == 2:
                mid_holiday_list.append(holiday.holiday_date)
            else:
                ngt_holiday_list.append(holiday.holiday_date)
    return day_holiday_list, mid_holiday_list, ngt_holiday_list

def get_absent_info(req_date, end_date, holiday_data):
    week_day_sun = 1
    week_day_sat = 7
    BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
    biomet_absent = BiometricDetails.objects.select_related('user').filter(
        Q(work_time_hhmm=None)|Q(work_time=0), user_id__isnull = False,
        process_date__week_day__gt=week_day_sun, process_date__week_day__lt=week_day_sat,
        process_date__range=[req_date, end_date]).values('user',
        'process_date', 'user__shift_id').order_by('user_id')
    biomet_absent = list(biomet_absent)
    for abs_data in list(biomet_absent):
        if abs_data['user__shift_id'] == 1:
            if abs_data['process_date'] in holiday_data[0]:
                biomet_absent.remove(abs_data)
        elif abs_data['user__shift_id'] == 2:
            if abs_data['process_date'] in holiday_data[1]:
                biomet_absent.remove(abs_data)
        elif abs_data['user__shift_id'] == 3:
            if abs_data['process_date'] in holiday_data[2]:
                biomet_absent.remove(abs_data)
    return biomet_absent

def work_holiday_data(req_date, end_date, holiday_data):
    holiday_list = list(set(holiday_data[0] + holiday_data[1] + holiday_data[2]))
    week_day_sun = 1
    week_day_sat = 7
    BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
    woh_info = BiometricDetails.objects.select_related('user').filter(
        Q(process_date__week_day__in=[week_day_sat, week_day_sun])|Q(process_date__in=holiday_list),
        work_time__gt=0, user_id__isnull = False, process_date__range=[req_date, end_date]
        ).values('user', 'process_date', 'user__shift_id', 'work_time').order_by('user_id')
    return woh_info

def score_wrk_day(request):
    """To calculate workday count & workday date list from given date string

    :Parameters

    request - date string

    :Result

    returns workday count & workday date list
    """
    req_date = request#'2022-12-05'
    req_date = datetime.strptime(req_date, "%Y-%m-%d")
    join_date = int(req_date.strftime('%d'))
    holiday_list = []
    businessdays = 0
    businessdays_list = []
    for i in range(join_date, 32):
        try:
            thisdate = date(req_date.year, req_date.month, i)
        except(ValueError):
            break
        if thisdate.weekday() < 5 and thisdate not in holiday_list: # Monday == 0, Sunday == 6 
            businessdays_list.append(thisdate)
            businessdays += 1
    return (businessdays, businessdays_list)

def get_cur_mon_work_day(work_days_list):
    work_day_count = 0
    new_list = []
    for work_days in work_days_list[1]:
        if work_days < datetime.now().date():
            work_day_count+=1
            new_list.append(work_days)
    return work_day_count, new_list

def get_tot_work_days(tot_work_days, holiday_data, shift_id, process_date):
    if shift_id == 1:
        for holi_date in holiday_data[0]:
            if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                tot_work_days -= 1
    elif shift_id == 2:
        for holi_date in holiday_data[1]:
            if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                tot_work_days -= 1
    elif shift_id == 3:
        for holi_date in holiday_data[2]:
            if holi_date.weekday() < 5 and process_date.year == holi_date.year and process_date.month == holi_date.month and holi_date<datetime.now().date():
                tot_work_days -= 1
    return tot_work_days

def get_abs_count(data, abs_data):
    for bio_data in data:
        if bio_data['process_date__month'] == abs_data['process_date'].month and bio_data['process_date__year'] == abs_data['process_date'].year:
            bio_data['abs_count'] += 1
            bio_data['abs_date'].append(abs_data['process_date'].day)
    return data

def get_woh_method(old_data, woh_data):
    for bio_data in old_data:
        if bio_data['process_date__month'] == woh_data['process_date'].month and bio_data['process_date__year'] == woh_data['process_date'].year:
            bio_data['tot_hrs'] -= int(woh_data['work_time'])
            bio_data['woh_hrs'] += int(woh_data['work_time'])
            bio_data['woh_date'].append(woh_data['process_date'].day)
    return old_data

def get_biomet_details(req_date, end_date, holiday_data):
    out_data = []
    BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
    biomet_data = BiometricDetails.objects.values('user',
        'process_date__month', 'process_date__year', 'user__shift_id').filter(
        user_id__isnull=False, process_date__range=[req_date, end_date]).annotate(
        tot_hrs=Sum('work_time'), joined_date=F('user__date_joined'),
        is_joinded=Case(When(
            Q(user__date_joined__year=F('process_date__year')) & Q(user__date_joined__month=F('process_date__month')), 
            then=True), default=False)
            ).order_by('user_id', 'process_date__year', 'process_date__month')
    biomet_absent = get_absent_info(req_date, end_date, holiday_data)
    woh_data = work_holiday_data(req_date, end_date, holiday_data)
    user_bio_info = {}
    for bio_info in biomet_data:
        process_date = date(bio_info['process_date__year'], bio_info['process_date__month'], 1)
        if bio_info['is_joinded']:
            new_join = score_wrk_day(bio_info['joined_date'].strftime("%Y-%m-%d"))
            if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                new_join = get_cur_mon_work_day(new_join)
        else:
            new_join = score_wrk_day(process_date.strftime("%Y-%m-%d"))
            if process_date.month == datetime.now().month and process_date.year == datetime.now().year:
                new_join = get_cur_mon_work_day(new_join)
        tot_work_days = get_tot_work_days(new_join[0], holiday_data, bio_info['user__shift_id'], process_date)
        bio_info['process_date'] = process_date
        bio_info['abs_count'] = 0
        bio_info['abs_date'] = []
        bio_info['woh_date'] = []
        bio_info['woh_hrs'] = 0
        bio_info['total_work_days'] = tot_work_days
        temp_dict = {}
        if bio_info['user'] in user_bio_info:
            user_bio_info[bio_info['user']]['data'].append(bio_info)
        else:
            user_bio_info[bio_info['user']] = temp_dict
            temp_dict['user_id'] = bio_info['user']
            temp_dict['data'] = [bio_info]
    if biomet_absent:
        for abs_data in biomet_absent:
            if abs_data['user'] in user_bio_info:
                usr_info = user_bio_info[abs_data['user']]
                user_data = get_abs_count(usr_info['data'], abs_data)
                usr_info['data'] = user_data
    if woh_data:
        for woh_details in woh_data:
            if woh_details['user'] in user_bio_info:
                usr_old_info = user_bio_info[woh_details['user']]
                user_upd_data = get_woh_method(usr_old_info['data'], woh_details)
                usr_old_info['data'] = user_upd_data
    for bio_info in user_bio_info:
        out_data.append(user_bio_info[bio_info])
    return out_data

def cal_hrs_diff(req_info):
    work_days = 0
    work_days = req_info['total_work_days'] - req_info['abs_count']
    bio_diff = 0
    if work_days:
        if req_info['user__shift_id'] in [1, 2]:
            bio_diff = (work_days * 510) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
        elif req_info['user__shift_id'] == 3:
            bio_diff = (work_days * 480) - req_info['tot_hrs'] if req_info['tot_hrs'] != None else 0
    return bio_diff

def create_usr_attend_entry(user_bio_info):
    updated_list = []
    UserAttandance = apps.get_model(app_label='workportal', model_name='UserAttandance')
    for user_data in user_bio_info:
        if 'data' in user_data:
            for attendance in user_data['data']:
                bio_diff = cal_hrs_diff(attendance)
                attend_obj = UserAttandance(
                    None,
                    month = attendance['process_date'],
                    user_id = attendance['user'],
                    tot_hrs = attendance['tot_hrs'],
                    tot_leaves = attendance['abs_count'],
                    hrs_diff = bio_diff,
                    is_joined_month = attendance['is_joinded'],
                    leave_dates = attendance['abs_date'],
                    tot_work_days = attendance['total_work_days'],
                    woh_dates = attendance['woh_date'],
                    woh_tot_hrs = attendance['woh_hrs'] if attendance['woh_hrs'] > 0 else None
                )
                updated_list.append(attend_obj)
    with transaction.atomic():
        if updated_list:
            usr_attend_create = UserAttandance.objects.bulk_create(
                objs=updated_list, 
                update_conflicts= True, 
                update_fields=['tot_hrs', 'tot_leaves', 'hrs_diff', 'leave_dates', 'tot_work_days', 'woh_dates', 'woh_tot_hrs'],
                unique_fields=['user_id', 'month'])

@shared_task
def get_attendance_report_data(request):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Eamil notification disabled'
    try:
        UserAttandance = apps.get_model(app_label='workportal', model_name='UserAttandance')
        max_date = UserAttandance.objects.aggregate(Max('month'))
        print(max_date, 'max_date')
        if not max_date['month__max']:
            req_date = date(2024, 6, 1)
        else:
            req_date = max_date['month__max']
        req_date = date(req_date.year, req_date.month, 1)
        end_date = datetime.now() - timedelta(days=1)
        holiday_data = holiday_info(req_date=req_date, end_date=end_date)
        biomet_info = get_biomet_details(req_date=req_date, end_date=end_date, holiday_data=holiday_data)
        attandance_data = create_usr_attend_entry(biomet_info)
        return 'Attendance Report updated successfuly'
    except Exception as e:
        print('UserAttendReport error:', str(e))
        try:
            print('inside no data email set up')
            email_list = []
            HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            holiday_qry = HolidayList.objects.filter(
                holiday_date__year=datetime.today().strftime("%Y"),
                status=True
                )
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if datetime.today().strftime("%Y-%m-%d") in holiday_list:
                print('Attendance Report error email skipped for holiday')    
                return 'email skipped for holiday'
            prv_task_day = datetime.today()
            from_email = EMAIL_HOST_USER
            try:
                message = f"""<p style="font-size:0.8rem;">Hi Team,</p> 
                                <p style="font-size:0.8rem;">
                                    There is gentile remainder for User Attendance report schedular faild on
                                    {prv_task_day.strftime("%m/%d/%Y")}. 
                                </p>
                            <br>
                            <p style="font-size:0.8rem;">- SE Notification System</p>"""
                msg = EmailMessage(
                    'User Attendance Report Error - Reg.',
                    message,
                    'Failure Alert <do_not_reply@solvedge.in>',
                    ['krishnakumar.k@solvedge.in'],
                    cc=['duraibabu.g@solvedge.in']
                )
                msg.content_subtype ="html" # Main content is now text/html
                email_list.append(msg) 
            except Exception as e:
                print('Attendance Report email error - ',e)
            if len(email_list) > 0:
                # print(email_list, 'email_list')
                connection = mail.get_connection()
                connection.send_messages(email_list)
            print('Attendance Report error email triggered')
            return 'Attendance Report error email triggered'
        except Exception as ex:
            print('error',ex)
            return "Attendance Report email notification error"

def bio_time_diff(total_hours, bio_hours):
    hur_mins = '0:00'
    try:
        tot_date = datetime.strptime(total_hours,"%H:%M")
        bio_date = datetime.strptime(bio_hours,"%H:%M")
        min_sign = "+ "
        if tot_date > bio_date:
            delta = tot_date - bio_date
            min_sign = "- "
        else:
            delta = bio_date - tot_date 
        minutes = int(delta.total_seconds() / 60)
        if minutes > 0:
            hour = minutes // 60
            mins = minutes % 60
            if mins < 10:
                hur_mins = "{}:0{}".format(hour,mins)
            else:
                hur_mins = "{}:{}".format(hour,mins)
        if minutes > 10 and min_sign == '- ':
            return min_sign + hur_mins, 'lt10'
        else:
            return min_sign + hur_mins, 'gt10'
    except Exception as ex:
        print('bio_diff: ',str(ex))
    return hur_mins, 'er'

def hour_to_min(mins_data):
    hur_mins = '0:00'
    if mins_data:
        if mins_data <= 0:
            return hur_mins
        hour = mins_data // 60
        mins = mins_data % 60
        if mins < 10:
            hur_mins = "{}:0{}".format(hour,mins)
        else:
            hur_mins = "{}:{}".format(hour,mins)
    return hur_mins

def hrs_format(b_time):
    seconds = int(b_time.total_seconds())
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    bi_time = "{}:{}:{}".format(hour, minutes, seconds)
    return bi_time

def con_user_production_report(user_info, prod_report, usr_biomet):
    prod_info = {}
    usr_info = {}
    for usr in user_info:
        try:
            for wrktime in usr_biomet:
                usr_res = {}
                usr_res['shift_name'] = usr['shift_name']
                usr_res['shift_frm'] = usr['shift_frm']  #+ ' to ' + usr['shift_to']
                usr_res['shift_to'] = usr['shift_to']
                usr_res['user_id'] = usr['id']
                usr_res['dept_name'] = usr['dept_name']
                usr_res['user_name'] = usr['first_name'] + " " + usr['last_name']
                if wrktime["bio_id"] == usr['bm_usr_id']:
                    if len(wrktime):
                        if wrktime['work_time_hhmm'] is None or str(wrktime['work_time_hhmm']).startswith('0'):
                            usr_res['bio_time'] = '0:00'
                            usr_res['process_date'] = wrktime['process_date']  
                        else:
                            b_time = wrktime['work_time_hhmm']
                            if type(b_time)!=str:
                                bi_time = hrs_format(b_time)
                                usr_res['bio_time'] = datetime.strptime(bi_time, "%H:%M:%S").strftime("%H:%M")
                                usr_res['process_date'] = wrktime['process_date']
                            else:
                                usr_res['bio_time'] = '0:00'
                                usr_res['process_date'] = wrktime['process_date']
                    else:
                        usr_res['bio_time'] = '0:00'
                        usr_res['process_date'] = wrktime['process_date']
                    usr_info[usr['id'], wrktime['process_date'].strftime('%m-%d-%Y')] = usr_res
        except Exception as ex:
            print('usr_biomet err: ',str(ex))
    # print(usr_info, 'usr_info')
    user_prod_info = {}
    if prod_report:
        for prod in prod_report:
            try:
                prod_info[prod['user_id'], prod['task_date'].strftime('%m-%d-%Y')] = prod
                prod['user_name'] = prod['usr_fname'] + ' ' + prod['usr_lname']
                prod['task_date'] = prod['task_date'].strftime('%m-%d-%Y')
                prod['avg_prd_percent'] = round(prod['avg_prd_percent'], 2)
                prod['total_time'] = hour_to_min(prod['tsk_tot_time'])
                prod['gen_total_time'] = hour_to_min(prod['tsk_gen_time'])
                prod['down_time'] = hour_to_min(prod['tsk_down_time']) if prod['tsk_down_time'] != None else '0:00'
                try:
                    usr_addon = usr_info[prod['user_id'], prod['task_date']]
                    if usr_addon is None:
                        prod['shift_name'] = ''
                        prod['shift_frm'] = ''
                        prod['shift_to'] = ''
                        prod['bio_time'] = ''
                        prod['bio_diff'] = ''
                        prod['bio_diff_org'] = ''
                        prod['bio_diff_flag'] = ''
                    else:
                        prod['shift_name'] = usr_addon['shift_name']
                        prod['shift_frm'] = usr_addon['shift_frm']
                        prod['shift_to'] = usr_addon['shift_to']
                        prod['bio_time'] = usr_addon['bio_time']
                        prod['bio_diff_org'] = usr_addon['bio_time']
                        prod['bio_diff'], prod['bio_diff_flag'] = bio_time_diff(prod['total_time'], prod['bio_diff_org'])
                except Exception as e:
                    print('error:', str(e))
                    for usr in user_info:
                        if usr['id'] == prod['user_id']:
                            prod['shift_name'] = usr['shift_name']
                            prod['shift_frm'] = usr['shift_frm']
                            prod['shift_to'] = usr['shift_to']
                            prod['bio_time'] = '0:00'
                            prod['bio_diff_org'] = '0:00'
                            prod['bio_diff'], prod['bio_diff_flag'] = bio_time_diff(prod['total_time'], prod['bio_diff_org'])
                user_prod_info[prod['user_id'], prod['task_date']] = prod 
            except Exception as ex:
                print('Production time sheet e: ', ex)
    usr_prod_info = {}
    for user in usr_info:
        if user not in prod_info:
            if type(usr_info[user]['bio_time']) == str:
                time1 = datetime.strptime(usr_info[user]['bio_time'], "%H:%M")
                time2 = datetime(1900,1,1)
            if (time1-time2).total_seconds() / 60.0 > 0:
                cur_prod = {}
                usr_prod_info[user] = cur_prod
                cur_prod['user_name'] = usr_info[user]['user_name']
                cur_prod['task_date'] = user[1].strftime("%m-%d-%Y") if type(user[1]) != str else user[1]
                cur_prod['user_id'] = user[0]
                cur_prod['inp_tsk_cnt'] = None
                cur_prod['hold_tsk_cnt'] = None
                cur_prod['cmp_tsk_cnt'] = None
                cur_prod['avg_prd_percent'] = None
                cur_prod['total_time'] = '0:00'
                cur_prod['down_time'] = '0:00'
                cur_prod['gen_total_time'] = '0:00'
                cur_prod['dept_name'] = usr_info[user]['dept_name']
                cur_prod['shift_name']= usr_info[user]['shift_name']
                cur_prod['shift_frm']= usr_info[user]['shift_frm']
                cur_prod['shift_to']= usr_info[user]['shift_to']
                cur_prod['bio_time']= usr_info[user]['bio_time']
                cur_prod['bio_diff_org']= usr_info[user]['bio_time']
                cur_prod['bio_diff'], cur_prod['bio_diff_flag'] = bio_time_diff('0:00', cur_prod['bio_diff_org'])
        prod_info.update(usr_prod_info)
    prod_info = OrderedDict(sorted(prod_info.items(), key = lambda x: getitem(x[1], 'task_date')))
    out_list = []
    if prod_info:
        for out_data in prod_info:
            out_list.append(prod_info[out_data])
    return out_list

def get_user_prod_report(prv_date):
    ProdTimeSheet = apps.get_model(app_label='workportal', model_name='ProdTimeSheet')
    BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
    User = apps.get_model(app_label='authapi', model_name='User')
    try:
        prod_report = ProdTimeSheet.objects.values(
            'user_id', 'task_date').prefetch_related('user_id', 'task_status').filter(
            Q(user_id__is_active=True), task_date=prv_date).annotate(usr_fname=F('user_id__first_name'),
            usr_lname=F('user_id__last_name'), dept_name=F('user__dept__name'), inp_tsk_cnt=Count('id', filter=Q(task_status=1)),
            cmp_tsk_cnt=Count('id', filter=Q(task_status=3)), hold_tsk_cnt=Count('id', filter=Q(task_status=2)),
            tot_tsk_cnt=Count('id'), tsk_tot_time=Sum('total_time'),
            tsk_down_time=Sum('total_time', filter=Q(project__is_down_time=True)),
            tsk_gen_time=Sum('total_time', filter=~Q(project__is_down_time=True)),
            total_per=Sum('prod_percent'), avg_prd_percent=Avg('prod_percent')
            ).order_by('task_date')
        usr_info = User.objects.filter(is_active=True).values(
            'id','first_name', 'last_name','bm_usr_id','shift','shift_frm','shift_to',
            shift_name = F('shift__shift_name'), usr_id = F('id'), dept_name=F('dept__name'))
        usr_biomet = BiometricDetails.objects.prefetch_related('user_id').filter(
            Q(user_id__is_active=True), process_date=prv_date).values( 'bio_id', 'bio_name',
            'process_date', 'work_time', 'work_time_hhmm', 'department_name', 'user_id')
        usr_prd_repport = con_user_production_report(usr_info, prod_report, usr_biomet)
        return usr_prd_repport
    except Exception as e:
        print('Production Timesheet qry error :', str(e))

@shared_task
def daily_ts_production_report(request):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Eamil notification disabled'
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        notify_status = NotificationSystem.objects.filter(schedular_name='Production Report').values()
        notify_enable = False
        cc_json = {}
        to_json = {}
        correspondance_name = ''
        if notify_status:
            if notify_status[0]['status'] == True:
                notify_enable = True
                correspondance_name = notify_status[0]['correspondance_name']
                cc_json = ast.literal_eval(notify_status[0]['cc_list'])
                to_json = ast.literal_eval(notify_status[0]['to_list'])
        if notify_enable:
            HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            holiday_qry = HolidayList.objects.filter(holiday_date__year=datetime.today().strftime("%Y"), status=True)
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if datetime.today().strftime("%Y-%m-%d") in holiday_list:
                print('production report email skipped for holiday')    
                return 'email skipped for holiday'                
            prv_task_day = datetime.today() - timedelta(days=1)
            while (prv_task_day.strftime("%Y-%m-%d") in holiday_list) or (prv_task_day.weekday() >= 5):
                prv_task_day -= timedelta(days=1) 

            """Production Report Email"""
            usr_data = get_user_prod_report(prv_date=prv_task_day)
            email_list = []
            from_email = EMAIL_HOST_USER
            cc_list = get_cclist(cc_json)
            recipient_list = get_cclist(to_json)
            ctx = {
                'prv_task_date': prv_task_day.strftime("%m/%d/%Y"),
                'data': usr_data
            }
            message = get_template('prod_reprt_tmpl.html').render(ctx)
            msg = EmailMessage(
                'Production Timesheet Report',
                message,
                f'{correspondance_name} <do_not_reply@solvedge.in>',
                recipient_list,
                cc=cc_list
            )
            msg.content_subtype = "html"
            email_list.append(msg)
            connection = mail.get_connection()
            connection.send_messages(email_list)
            print('Production sheet email triggered')
            return 'Production sheet email triggered'
    except Exception as e:
        print('daily_production_report email error: ', str(e))

@shared_task
def timesheet_remainder_email(res_alloc_details):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Eamil notification disabled'
    # check database for status email status
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        notify_status = NotificationSystem.objects.filter(schedular_name='Time Sheet Reminder').values()
        notify_enable = False
        cc_json = {}
        ts_correspondance_name = ''
        if notify_status:
            if notify_status[0]['status'] == True:
                notify_enable = True
                ts_correspondance_name = notify_status[0]['correspondance_name']
                cc_json = ast.literal_eval(notify_status[0]['cc_list'])
        notify_status_mg = NotificationSystem.objects.filter(schedular_name='Time Sheet Status').values()
        notify_enable_mg = False
        cc_json_mg = {}
        to_json_mg = {}
        correspondance_name = ''
        if notify_status_mg:
            if notify_status_mg[0]['status'] == True:
                notify_enable_mg = True
                correspondance_name = notify_status_mg[0]['correspondance_name']
                cc_json_mg = ast.literal_eval(notify_status_mg[0]['cc_list'])
                to_json_mg = ast.literal_eval(notify_status_mg[0]['to_list'])

        if notify_enable or notify_enable_mg:
            HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            holiday_qry = HolidayList.objects.filter(holiday_date__year=datetime.today().strftime("%Y"), status=True)
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if datetime.today().strftime("%Y-%m-%d") in holiday_list:
                print('timesheet_remainder_email email skipped for holiday')    
                return 'email skipped for holiday'                
            prv_task_day = datetime.today() - timedelta(days=1)
            while (prv_task_day.strftime("%Y-%m-%d") in holiday_list) or (prv_task_day.weekday() >= 5):
                prv_task_day -= timedelta(days=1)
            ProdTimeSheet = apps.get_model(app_label='workportal', model_name='ProdTimeSheet')
            BiometricDetails = apps.get_model(app_label='workportal', model_name='BiometricDetails')
            query = Q(user_id__in=ProdTimeSheet.objects.filter(
                task_date=prv_task_day.strftime("%Y-%m-%d")).values_list('user_id').distinct())
            user_query = Q(id__in=BiometricDetails.objects.prefetch_related('user_id').filter(~query, 
                Q(user_id__is_active=True), Q(work_time__gt=0)&Q(work_time__isnull=False), process_date=prv_task_day.strftime("%Y-%m-%d")).values_list('user_id'))
            absent_user_query = Q(id__in=BiometricDetails.objects.prefetch_related('user_id').filter(~query, 
                Q(user_id__is_active=True), Q(work_time_hhmm__isnull=True)|Q(work_time=0), process_date=prv_task_day.strftime("%Y-%m-%d")).values_list('user_id'))
            User_obj = apps.get_model(app_label='authapi', model_name='User')
            usr_unfinished = User_obj.objects.filter(user_query, is_active=True).annotate(dept_name=F('dept__name')).order_by('dept_id').distinct()
            usr_absent = User_obj.objects.filter(absent_user_query, is_active=True).annotate(dept_name=F('dept__name')).order_by('dept_id').distinct()
            email_list = []
            usr_data = []
            if usr_unfinished.exists():
                from_email = EMAIL_HOST_USER
                cc_list = get_cclist(cc_json)
                for usr_lst in usr_unfinished:
                    try:
                        if usr_lst.timeshtlist_sts:
                            if usr_lst.dept_name != None and usr_lst.dept_id not in (15,16):
                                tsreminder = {}
                                tsreminder['usr_name'] = usr_lst.first_name + ' ' + usr_lst.last_name
                                tsreminder['usr_email'] = usr_lst.email
                                tsreminder['usr_dept'] = usr_lst.dept_name if usr_lst.dept_name != None else '' #usr_lst.user_id.res_grp_id
                                usr_data.append(tsreminder)
                        if notify_enable and usr_lst.timeshtlist_sts and usr_lst.dept_id not in (15, 16):
                            recipient_list = usr_lst.email
                            ctx = {
                                'first_name':usr_lst.first_name,
                                'last_name':usr_lst.last_name,
                                'prv_task_day':prv_task_day.strftime("%m/%d/%Y"),
                                'portal_url':WEB_URL
                            }
                            message = get_template('usr_timeshet_tmpl.html').render(ctx)
                            # print(recipient_list, 'recipient_list')
                            # message = f"""<p style="font-size:0.8rem;">Hi {usr_lst.first_name} {usr_lst.last_name},</p> 
                            #             <p style="font-size:0.8rem;">This is a gentle reminder that your Timesheet was not submitted on {prv_task_day.strftime("%m/%d/%Y")}.
                            #             Please contact your Team Lead/ Administrator to submit your Timesheet.</p>
                            #             <p style="font-size:0.8rem;">Kindly ignore this email if you have already submitted your timesheet or were absent on {prv_task_day.strftime("%m/%d/%Y")}.</p>
                            #             <br>
                            #             <p style="font-size:0.8rem;">- SE Notification System</p>"""
                            msg = EmailMessage(
                                'Timesheet Reminder',
                                message,
                                f'{ts_correspondance_name} <do_not_reply@solvedge.in>',
                                [recipient_list,],
                                cc=cc_list
                            )
                            msg.content_subtype ="html"# Main content is now text/html
                            email_list.append(msg)
                    except Exception as e:
                        print('Timesheet email error - ',e)
            else:
                print('No unfinished user found.')
            print('remainder email triggered!')

            absent_user_list = []
            # print(usr_absent, 'usr_absent')
            if usr_absent.exists():
                for usr_abs_lst in usr_absent:
                    try:
                        if usr_abs_lst.timeshtlist_sts:
                            if usr_abs_lst.dept_name != None and usr_abs_lst.dept_id not in (15,16):
                                absent_user = {}
                                absent_user['usr_name'] = usr_abs_lst.first_name + ' ' + usr_abs_lst.last_name
                                absent_user['usr_email'] = usr_abs_lst.email
                                absent_user['usr_dept'] = usr_abs_lst.dept_name if usr_abs_lst.dept_name != None else ''
                                absent_user_list.append(absent_user)
                    except Exception as e:
                        print('Timesheet email error - ',e) 
            else:
                print('No absentee user found.')
            # print(absent_user_list, 'absent_user_list')
            if notify_enable_mg :
                from_email = EMAIL_HOST_USER
                ctx = {
                    'prv_task_date': prv_task_day.strftime("%m/%d/%Y"),
                    'data': usr_data,
                    'absent_data': absent_user_list
                }
                # print(usr_data)
                recipient_list = get_cclist(to_json_mg)
                cc_list = get_cclist(cc_json_mg)
                message = get_template('tmsh_rem_tmpl.html').render(ctx)
                msg = EmailMessage(
                    'Absentee List ('+ str(len(absent_user_list)) +') & Timesheet Reminder (' + str(len(usr_data)) + ') - Report',
                    message,
                    f'{correspondance_name} <do_not_reply@solvedge.in>',
                    recipient_list, #Need to change query
                    cc=cc_list
                )
                msg.content_subtype ="html"# Main content is now text/html
                email_list.append(msg)
            else:
                print('Timesheet Report Notification Disabled')
            if len(usr_data) <= 0:
                print('All user completed their task')
            if len(email_list) > 0:
                connection = mail.get_connection()
                connection.send_messages(email_list)
        else:
            print('Timesheet Reminder Notification Disabled')
        return 'email triggered'
    except Exception as ex:
        print('Timesheet Remainder email error: ', str(ex))

@shared_task
def backup_database(res_alloc_details): 
    try:
        if not os.path.exists(PureWindowsPath(SE_APP_STORAGE)):
            os.mkdir(PureWindowsPath(SE_APP_STORAGE))
        path = os.path.join(PureWindowsPath(SE_APP_STORAGE), 'dbstorage_bkp') # /2022_06
        # print('path: ',path)
        if not os.path.exists(path):
            os.mkdir(path)
        dt_now = datetime.now()
        dt_folder = dt_now.strftime("%Y_%m")
        path = os.path.join(path,dt_folder)
        if not os.path.exists(path):
            os.mkdir(path)
        filename = os.path.join(path, "setrackerprod_" + dt_now.strftime("%m%d_%H%M%S") + ".sql")
        
        version = 16 # postgres version 14
        postgresDir = Path("C:/Program Files/PostgreSQL/{}/bin/".format(version))
        directory = PureWindowsPath(postgresDir)
        saveDir = PureWindowsPath(filename) # Path("E:/bkp/{}.zip".format(filename))  # output directory here
        file = PureWindowsPath(saveDir)

        # passw = DATABASES['default']['PASSWORD'] # Password capture in postgresql\pgpass.config
        host = DATABASES['default']['HOST']
        user = DATABASES['default']['USER']
        port = DATABASES['default']['PORT']
        dbname = DATABASES['default']['NAME']  # database name here
        proc = subprocess.Popen(['pg_dump', '-h', host, '-U', user,'-w','-p', port,
                    '-F', 'c', '-f', str(file), '-d', dbname],
                        cwd=directory,shell=True, stdin=subprocess.PIPE)
        proc.wait()
    except Exception as ex:
        print('database backup error: ', str(ex))

@shared_task
def close_and_escalate_tickets(request):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Eamil notification disabled'
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        notify_status = NotificationSystem.objects.filter(schedular_name='Timebound Escalate').values()
        notify_enable = False
        cc_json = {}
        to_json = {}
        correspondance_name = ''
        if notify_status:
            if notify_status[0]['status'] == True:
                notify_enable = True
                correspondance_name = notify_status[0]['correspondance_name']
                cc_json = ast.literal_eval(notify_status[0]['cc_list'])
                to_json = ast.literal_eval(notify_status[0]['to_list'])
        if notify_enable:
            HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            holiday_qry = HolidayList.objects.filter(holiday_date__year=datetime.today().strftime("%Y"), status=True)
            holiday_list = []
            if holiday_qry.exists():
                for holiday in holiday_qry:
                    holiday_list.append(holiday.holiday_date.strftime("%Y-%m-%d"))
            if datetime.today().strftime("%Y-%m-%d") in holiday_list or datetime.today().weekday() >= 5:
                print('Escalation report email skipped for holiday')
                return 'email skipped for holiday'
            prv_task_day = datetime.today() - timedelta(days=1)
            while (prv_task_day.strftime("%Y-%m-%d") in holiday_list) or (prv_task_day.weekday() >= 5):
                prv_task_day -= timedelta(days=1)

            HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
            holidays = set(HolidayList.objects.filter(status=True).values_list('holiday_date', flat=True))

            """Closing Tickets"""
            close_ticket = close_tickets(holidays)
            # print('close',close_ticket)

            """Escalation Tickets Report Email"""
            first_esc_tickets, rec_esc_tickets = escalate_tickets(holidays)
            # print('first',first_esc_tickets)
            # print('rec',rec_esc_tickets)
            # Group by department
            dept_ticket_map = defaultdict(lambda: {'first': [], 'rec': [], 'max_duration': 0})

            for ticket in first_esc_tickets:
                sno=1
                ticket.sno = sno
                dept_ticket_map[ticket.department_id]['first'].append(ticket)
                sno+=1

            for ticket in rec_esc_tickets:
                sno=1
                ticket.sno = sno
                dept_ticket_map[ticket.department_id]['rec'].append(ticket)
                if ticket.duration > dept_ticket_map[ticket.department_id]['max_duration']:
                    dept_ticket_map[ticket.department_id]['max_duration'] = ticket.duration
                sno+=1

            email_list = []

            for dept_id, values in dept_ticket_map.items():
                first_tickets = values['first']
                rec_tickets = values['rec']
                max_duration = values['max_duration']

                to_list = ticket_get_cclist(to_json, dept_id)
                cc_list = ticket_get_cclist(cc_json, dept_id)

                if to_list == []:
                    # print(f"No recipients found for department {dept_id}, skipping email.")
                    continue

                ctx = {
                    'first_esc_tickets': first_tickets,
                    'rec_esc_tickets': rec_tickets,
                    'max_duration': max_duration,
                    'portal_url': WEB_URL
                }

                message = get_template('ticket_esc_tmpl.html').render(ctx)
                msg = EmailMessage(
                    'Escalation notice for tickets with no progress',
                    message,
                    f'{correspondance_name} <do_not_reply@solvedge.in>',
                    to_list,
                    cc=cc_list
                )
                msg.content_subtype = "html"
                email_list.append(msg)

            if email_list:
                connection = mail.get_connection()
                connection.send_messages(email_list)
                print('Escalation Report email(s) triggered')
                return 'Escalation Report email(s) triggered'

    except Exception as e:
        print('daily_production_report email error:', str(e))
    return "Task finished"

def get_working_days(start_date, end_date, holidays):
    
    working_days = 0
    current_date = start_date

    while current_date <= end_date:
        if current_date.weekday() < 5 and current_date not in holidays:  # 0=Monday, ..., 6=Sunday
            working_days += 1
        current_date += timedelta(days=1)
    return working_days

def close_tickets(holidays):
    ticket_object = apps.get_model(app_label='ticketingsystem', model_name='TicketDetails')
    ticket_status = apps.get_model(app_label='ticketingsystem', model_name='TicketStatus')
    TicketStatusHistory = apps.get_model(app_label='ticketingsystem', model_name='TicketStatusHistory')

    resolved_tickets = ticket_object.objects.filter(status=ticket_status.StatusStage.RESOLVED)
    max_time = timedelta(days=7).days
    today = datetime.today().date()
    tickets_to_update = []
    ticket_hist_to_update =[]

    for ticket in resolved_tickets:
        time_since_update = get_working_days(ticket.status_updated_at.date(), today, holidays)
        if time_since_update >= max_time:
            ticket.is_active = False
            ticket.status_id = ticket_status.StatusStage.CLOSED
            ticket.status_updated_at = datetime.now(timezone.utc)
            ticket.closed_by = ticket_object.ClosedByType.AUTOMATE
            tickets_to_update.append(ticket)
            ticket_hist_to_update.append(TicketStatusHistory(
                ticket=ticket,
                status=ticket.status,
            ))
    if tickets_to_update:
        ticket_object.objects.bulk_update(tickets_to_update, ['is_active','status','status_updated_at' ,'closed_by'])
    if ticket_hist_to_update:
        TicketStatusHistory.objects.bulk_create(ticket_hist_to_update)

    return tickets_to_update

def escalate_tickets(holidays):
    Ticket = apps.get_model(app_label='ticketingsystem', model_name='TicketDetails')
    TicketEscalationHistory = apps.get_model(app_label='ticketingsystem', model_name='TicketEscalationHistory')

    today = datetime.now().date()
    all_tickets = Ticket.objects.filter(is_active=True)
    first_esc_tickets = []
    first_hist_esc_tickets = []
    rec_esc_tickets = []
    rec_hist_esc_tickets = []

    for ticket in all_tickets:
        if not ticket.status.is_escalate:
            continue

        time_since_update = get_working_days(ticket.status_updated_at.date(), today, holidays)
        first_esc_days = ticket.sub_category.first_esc
        recurring_esc_days = ticket.sub_category.recurring_esc
        escalation_count = ticket.escalation_count

        if time_since_update > first_esc_days and escalation_count == 0 and recurring_esc_days > 0:
            ticket.is_escalate = True
            ticket.escalation_count = escalation_count + 1
            ticket.esc_updated_at = datetime.now(timezone.utc)
            ticket.duration = time_since_update
            ticket.department_name = ticket.department.name
            ticket.user_name = f"{ticket.created_by.first_name} {ticket.created_by.last_name}"
            ticket.created_date = ticket.created_at.strftime("%B %d, %Y %I:%M %p").replace("AM", "A.M.").replace("PM", "P.M.")
            first_esc_tickets.append(ticket)
            first_hist_esc_tickets.append(TicketEscalationHistory(
                ticket=ticket,
                trigger_type=TicketEscalationHistory.EscTriggerType.AUTOMATE,
            ))
        elif escalation_count > 0:
            # last_esc,manual_interrupt = escalation_history(ticket=ticket)
            if ticket.status_updated_at > ticket.esc_updated_at: #21 > 22
                time_since_update = get_working_days(ticket.status_updated_at.date(), today, holidays)
                time_since_update_for_duration = time_since_update
                # print('dddd',ticket.id)
            else:
                time_since_update = get_working_days(ticket.esc_updated_at.date(), today, holidays)
                time_since_update_for_duration = get_working_days(ticket.status_updated_at.date(), today, holidays)
            threshold_days = recurring_esc_days
            if time_since_update > threshold_days:
                if not ticket.is_escalate:
                    ticket.is_escalate = True
                ticket.escalation_count = escalation_count + 1
                ticket.esc_updated_at = datetime.now(timezone.utc)
                ticket.duration = time_since_update_for_duration
                ticket.department_name = ticket.department.name
                ticket.user_name = f"{ticket.created_by.first_name} {ticket.created_by.last_name}"
                ticket.created_date = ticket.created_at.strftime("%B %d, %Y %I:%M %p").replace("AM", "A.M.").replace("PM", "P.M.")
                ticket.updated_date = ticket.status_updated_at.strftime("%B %d, %Y %I:%M %p").replace("AM", "A.M.").replace("PM", "P.M.")
                rec_esc_tickets.append(ticket)
                rec_hist_esc_tickets.append(TicketEscalationHistory(
                    ticket=ticket,
                    trigger_type=TicketEscalationHistory.EscTriggerType.AUTOMATE,
                ))

    if first_esc_tickets:
        Ticket.objects.bulk_update(first_esc_tickets, ['is_escalate', 'escalation_count', 'esc_updated_at'])
    if first_hist_esc_tickets:
        TicketEscalationHistory.objects.bulk_create(first_hist_esc_tickets)

    if rec_esc_tickets:
        Ticket.objects.bulk_update(rec_esc_tickets, ['is_escalate', 'escalation_count', 'esc_updated_at'])
    if rec_hist_esc_tickets:
        TicketEscalationHistory.objects.bulk_create(rec_hist_esc_tickets)

    first_esc_tickets.sort(key=lambda x: (x.id, x.duration))
    rec_esc_tickets.sort(key=lambda x: (x.id, x.duration))

    return first_esc_tickets, rec_esc_tickets

# def escalation_history(ticket):
#     TicketEscalationHistory = apps.get_model(app_label='ticketingsystem', model_name='TicketEscalationHistory')
#     history_qs = TicketEscalationHistory.objects.filter(ticket=ticket).order_by('-created_at')
#     latest_history = history_qs.first()
#     manual_interrupt = history_qs.filter(trigger_type=TicketEscalationHistory.EscTriggerType.AUTOMATE).exists()
#     return latest_history, manual_interrupt

@shared_task
def send_status_email(request):
    if not EMAIL_TRIGGER:
        print('Email notification disabled')
        return 'Email notification disabled'
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        notify_status = NotificationSystem.objects.filter(schedular_name='Status Email').values().first()
        email_list = []

        if not notify_status or not notify_status.get('status', False):
            print('Notification disabled or not configured')
            return 'Notification disabled or not configured'

        correspondance_name = notify_status.get('correspondance_name', 'Notification')
        cc_json = ast.literal_eval(notify_status.get('cc_list', '{}'))
        to_json = ast.literal_eval(notify_status.get('to_list', '{}'))

        HolidayList = apps.get_model(app_label='authapi', model_name='HolidayList')
        holiday_qry = HolidayList.objects.filter(holiday_date__year=datetime.today().year, status=True)
        holiday_list = [holiday.holiday_date.strftime("%Y-%m-%d") for holiday in holiday_qry]

        if datetime.today().strftime("%Y-%m-%d") in holiday_list:
            print('Status email skipped for holiday')
            return 'Status email skipped for holiday'

        ticket_data,requested_date = get_today_status(holiday_list)
        ctx = {
            'data': ticket_data,
            'date': requested_date,
            'portal_url': WEB_URL
        }
        message = get_template('ticket_status_tmpl.html').render(ctx)
        from_email = EMAIL_HOST_USER
        recipient_list = get_cclist(to_json)
        cc_list = get_cclist(cc_json)
        msg = EmailMessage(
            'TicketingSystem Status Report @ ' + datetime.now().strftime("%I %p"),
            message,
            f'{correspondance_name} <do_not_reply@solvedge.in>',
            recipient_list,
            cc=cc_list
        )
        msg.content_subtype = "html"
        email_list.append(msg)

        if email_list:
            connection = mail.get_connection()
            connection.send_messages(email_list)
            print('Status count report email sent successfully')
            return 'Status count report email sent successfully'

    except Exception as ex:
        print('Exception occurred while sending status email:', ex)
        return f'Exception occurred: {str(ex)}'

def get_today_status(holiday_list):
    try:
        ticket_object = apps.get_model(app_label='ticketingsystem', model_name='TicketDetails')
        TicketStatus = apps.get_model(app_label='ticketingsystem', model_name='TicketStatus')
        department_model = apps.get_model(app_label='authapi', model_name='Department')

        department_list = department_model.objects.filter(status=True, is_ticket=True)
        dept_map = {dept.id: dept.name for dept in department_list}

        previous_day = datetime.today() - timedelta(days=1)
        while (previous_day.strftime("%Y-%m-%d") in holiday_list) or (previous_day.weekday() >= 5):
            previous_day -= timedelta(days=1)

        overall_qs = ticket_object.objects.values('department_id', 'status_id')
        prev_day_qs = ticket_object.objects.filter(status_updated_at__date=previous_day).values('department_id', 'status_id')

        overall_counts = defaultdict(lambda: defaultdict(int))
        prev_day_counts = defaultdict(lambda: defaultdict(int))

        for entry in overall_qs.annotate(count=Count('id')):
            dept_id = entry['department_id']
            status_id = entry['status_id']
            count = entry['count']
            overall_counts[dept_id][status_id] += count

        for entry in prev_day_qs.annotate(count=Count('id')):
            dept_id = entry['department_id']
            status_id = entry['status_id']
            count = entry['count']
            prev_day_counts[dept_id][status_id] += count

        outstanding_statuses = {
            TicketStatus.StatusStage.OPEN,
            TicketStatus.StatusStage.INPROGRESS,
            TicketStatus.StatusStage.ONHOLD,
            TicketStatus.StatusStage.REOPEN,
        }

        overall_status_map = {
            TicketStatus.StatusStage.OPEN: 'open_tickets',
            TicketStatus.StatusStage.INPROGRESS: 'inprogress_tickets',
            TicketStatus.StatusStage.ONHOLD: 'hold_tickets',
            TicketStatus.StatusStage.REOPEN: 'reopen_tickets',
        }

        previous_day_status_map = {
            TicketStatus.StatusStage.OPEN: 'open_tickets',
            TicketStatus.StatusStage.RESOLVED: 'resolved_tickets',
            TicketStatus.StatusStage.CLOSED: 'closed_tickets',
        }

        ticket_dict = {}

        for dept_id, dept_name in dept_map.items():
            ticket_dict[dept_name] = {
                'overall_tickets': {v: 0 for v in overall_status_map.values()},
                'prev_day_tickets': {v: 0 for v in previous_day_status_map.values()},
                'overall_tickets_outstanding': 0
            }

            for status_id, count in overall_counts.get(dept_id, {}).items():
                if status_id in overall_status_map:
                    ticket_dict[dept_name]['overall_tickets'][overall_status_map[status_id]] = count
                if status_id in outstanding_statuses:
                    ticket_dict[dept_name]['overall_tickets_outstanding'] += count

            for status_id, count in prev_day_counts.get(dept_id, {}).items():
                if status_id in previous_day_status_map:
                    ticket_dict[dept_name]['prev_day_tickets'][previous_day_status_map[status_id]] = count

        return ticket_dict,previous_day

    except Exception as e:
        print('TicketStatusCount API Error:', str(e))
        return {}