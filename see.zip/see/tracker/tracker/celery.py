from __future__ import absolute_import, unicode_literals
import os

from celery import Celery
from celery.schedules import crontab
from .tasks_status import *
# Set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tracker.settings')

app = Celery('tracker')

# Using a string here means the worker doesn't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
app.config_from_object('django.conf:settings', namespace='CELERY')
# Load task modules from all registered Django apps.
app.autodiscover_tasks()
app.conf.timezone = 'Asia/Kolkata' #'UTC'
app.conf.enable_utc = False
# remove pending tasks
# app.control.purge()

# app.conf.beat_schedule = {
#     'add-every-30-seconds': {
#         'task': 'tasks.send_status_email',
#         'schedule': 10.0,
#         'args': (16)
#     },
# }

@app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(
        crontab(day_of_week="1-6", minute=30, hour='7, 20'),
        backup_database.s('Backup database trigger!'),
    )
    sender.add_periodic_task(
        crontab(day_of_week="1-5", minute=0, hour='11'),
        timesheet_remainder_email.s('Backup database trigger!'),
    )
    sender.add_periodic_task(
        crontab(day_of_week="1-5", minute=0, hour='11'),
        daily_ts_production_report.s('Timesheet Production Report Trigger!'),
    )
    sender.add_periodic_task(
        crontab(day_of_week="1-5", minute=30, hour='10'),
        get_user_biomet_details.s('User Production Details Trigger!'),
    )
    sender.add_periodic_task(
        crontab(day_of_week="1-5", minute=0, hour='9'),
        close_and_escalate_tickets.s('Ticket Escalation Details Trigger!'),
    )
    sender.add_periodic_task(
        crontab(day_of_week="1-5", minute=0, hour='9'),
        send_status_email.s('Ticket Status Details Trigger!'),
    )


@app.task(bind=True)
def debug_task(self):
    print(f'Request: {self.request!r}')

@app.task
def error_handler(request, exc, traceback):
    print('Task {0} raised exception: {1!r}\n{2!r}'.format(
          request.id, exc, traceback))