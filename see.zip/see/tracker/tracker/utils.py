from rest_framework.views import exception_handler
from rest_framework import exceptions
import datetime
import http
import logging
logger = logging.getLogger(__name__)

def custom_exception_handler(exc, context):
    # Get standard error response from REST framework's default exception handler:
    response = exception_handler(exc, context)

    if response is not None and response.status_code == http.client.BAD_REQUEST:
        # Log response data for bad request to simplify debugging:        
        # print(f"Bad Request: {context['request'].path}: {response.data}")
        # logger.warning(" " + str(datetime.datetime.now()) + f": Bad Request: {context['request'].path}: {response.data}")
        logger.warning(f": Bad Request: {context['request'].path}: {response.data}")
        try:
            # field_names = []
            # for field_name, field_errors in response.data.items():
            #     field_names.append(field_name, '-',field_errors[0])
            # response.data = {'error': f'{field_names}'}
            print('rd',type(response.data))
            if type(response.data) is dict or type(response.data) is exceptions.ReturnDict:
                new_error = {}
                for field_name, field_errors in response.data.items():
                    print('for loop',type(field_errors))
                    if type(field_errors) is list:
                        if len(field_errors) > 0:
                            new_error[field_name] = field_errors[0]
                        else:
                            new_error[field_name] = "Invalid field data"
                    elif type(field_errors) is exceptions.ErrorDetail:
                        print('err det')
                        new_error[field_name] = field_errors
                    else:
                        new_error[field_name] = "Invalid fields value"
                if bool(new_error):
                    response.data = new_error
        except Exception as ex:
            logger.warning(f": Bad Request: Exception Called - {context['request'].path}: {response.data}")
    return response