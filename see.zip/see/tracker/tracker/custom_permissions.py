from rest_framework.permissions import BasePermission
from authapi import models


class IsAdmin(BasePermission):
   def has_permission(self, request, view):
       if hasattr(request.user,'role_id'):
            try:
                usr_rle = models.UserRole.objects.get(pk=request.user.role_id)
            except Exception as e:
                return False
            if usr_rle.id == models.UserRole.RoleStatus.ADMIN:
               return True #request.user.role_id == 1
       return False

class IsBasicUser(BasePermission):
   def has_permission(self, request, view):
       if hasattr(request.user,'role_id'):
           usr_rle = models.UserRole.objects.get(pk=request.user.role_id)
           if usr_rle.id == models.UserRole.RoleStatus.BASIC:
               return True #request.user.role_id == 2
       return False
   
class IsStaff(BasePermission):
    def has_permission(self, request, view):
        if hasattr(request.user,'role_id'):
            usr_rle = models.UserRole.objects.get(pk=request.user.role_id)
            if usr_rle.id == models.UserRole.RoleStatus.STAFF:
                return True #request.user.role_id == 2
        return False

class IsManager(BasePermission):
    def has_permission(self, request, view):
        if hasattr(request.user,'role_id'):
            usr_rle = models.UserRole.objects.get(pk=request.user.role_id)
            if usr_rle.id == models.UserRole.RoleStatus.MANAGER:
                return True #request.user.role_id == 2
        return False