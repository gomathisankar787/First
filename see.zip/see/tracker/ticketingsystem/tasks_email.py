from __future__ import absolute_import, unicode_literals
from celery import shared_task
from django.core.mail import EmailMessage
from django.core import mail
from tracker.settings import EMAIL_HOST_USER,WEB_URL
from django.apps import apps
import ast
from collections import OrderedDict
from django.template.loader import get_template

def get_cc_list(cc_json,dept):
    usr_id = []
    cc_list = []
    cc_list_ord = OrderedDict()
    for cc_ind in cc_json:
        usr_id.append(cc_ind["usr_id"])
        cc_list_ord[cc_ind["usr_id"]] = ''
    if len(usr_id) > 0:
        user_obj = apps.get_model(app_label='authapi', model_name='User')
        usr_list = user_obj.objects.filter(id__in=usr_id,is_active=True)
        for usr_in in usr_list:
            if usr_in.dept_id == dept:
                cc_list_ord[usr_in.id]=usr_in.email
        for key,value in cc_list_ord.items():
            cc_list.append(value)
    return cc_list

@shared_task
def send_newticket_email(res_alloc_details):
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')
        ticket_type = res_alloc_details['type']
        if ticket_type == 'Created':
            schedular_name = 'Create Ticket'
        if ticket_type == 'Status' or ticket_type == 'Reopen':
            schedular_name = 'Ticket Status Update'
        if ticket_type == 'Escalate':
            if res_alloc_details['current_status_id'] == 1:
                schedular_name = 'Timebound Escalate'
            else:
                schedular_name = 'User Escalate'
        if ticket_type == 'Notes':
            schedular_name = 'Ticket Notes'
        notify_status = NotificationSystem.objects.filter(schedular_name=schedular_name).values()
        notify_enable = False
        email_list = []
        cc_json = {}
        if notify_status:
            if notify_status[0]['status'] == True:
                correspondance_name = notify_status[0]['correspondance_name']
                notify_enable = True
                cc_json = ast.literal_eval(notify_status[0]['cc_list'])
                if ticket_type == 'Escalate' and res_alloc_details['current_status_id'] == 1:
                    to_json = ast.literal_eval(notify_status[0]['to_list'])
                    correspondance_name = 'SE Tracker - User Escalation Notice'
        email = res_alloc_details['user_mail']
        dept = res_alloc_details['department']
        if notify_enable:
            try:
                recipient_list = [email] #'krishnakumar.k@solvedge.in' 
                cc_list = get_cc_list(cc_json,dept)
                if ticket_type == 'Escalate' and res_alloc_details['current_status_id'] == 1:
                    recipient_list = get_cc_list(to_json,dept)
                    if recipient_list == []:
                        print('email skipped because of empty to list')
                        return 'email skipped because of empty to list'
                ctx = {
                    'ticket_id': res_alloc_details['ticket_id'],
                    'category_name': res_alloc_details['category_name'],
                    'title': res_alloc_details['title'],
                    'summary': res_alloc_details['summary'],
                    'user_name': res_alloc_details['user_name'],
                    'type': res_alloc_details['type'],
                    'portal_url':WEB_URL
                }
                subject_map = {
                    'Created': f"New Ticket Created - #TCK{res_alloc_details['ticket_id']}",
                    'Status': f"Status Changed for Ticket #TCK{res_alloc_details['ticket_id']}",
                    'Escalate': f"Escalation Notice: Ticket #TCK{res_alloc_details['ticket_id']}",
                    'Notes': f"New Comment Added: Ticket #TCK{res_alloc_details['ticket_id']}",
                    'Reopen': f"Ticket Reopened: Ticket #TCK{res_alloc_details['ticket_id']}"
                }
                subject = subject_map.get(ticket_type, 'HR Helpdesk Ticket Notification')

                if ticket_type == 'Created':
                    ctx['created_at'] = res_alloc_details.get('created_date').strftime("%B %d, %Y %I:%M %p").replace("AM", "A.M.").replace("PM", "P.M.")

                if ticket_type == 'Status':
                    ctx['current_status'] = res_alloc_details.get('current_status')
                
                if ticket_type == 'Reopen':
                    ctx['comments'] = res_alloc_details.get('comments')
                    ctx['requested_by'] = res_alloc_details.get('requested_by')
                    ctx['current_status'] = res_alloc_details.get('current_status')

                if ticket_type == 'Escalate' or ticket_type == 'Notes':
                    if ticket_type == 'Notes':
                        ctx['user_type'] = res_alloc_details.get('user_type')
                        ctx['comments'] = res_alloc_details.get('notes')
                    ctx['comment_for'] = res_alloc_details.get('comment_for')
                    ctx['created_at'] = res_alloc_details.get('created_date').strftime("%B %d, %Y %I:%M %p").replace("AM", "A.M.").replace("PM", "P.M.")
                    ctx['current_status'] = res_alloc_details.get('current_status')

                message = get_template('ticket_create_tmpl.html').render(ctx)
                msg = EmailMessage(
                    subject=subject,
                    body=message,
                    from_email=f'{correspondance_name} <do_not_reply@solvedge.in>',
                    to=recipient_list,
                    cc=cc_list
                )
                msg.content_subtype ="html" # Main content is now text/html
                email_list.append(msg)
                print('Ticket creation email triggered')
            except Exception as e:
                print('New Ticket Notification Disabled',e)
        if len(email_list) > 0:
            connection = mail.get_connection()
            connection.send_messages(email_list)
            print('email triggered')
            return 'email triggered'
    except Exception as ex:
        print(ex)
    return "ticket Details Not Updated"

@shared_task
def send_ticket_assign_mail_v2(ticket_email_data_list):
    email_list = []
    try:
        NotificationSystem = apps.get_model(app_label='authapi', model_name='NotificationSystem')

        grouped_by_assigned_to = {}
        grouped_assign = {}

        for data in ticket_email_data_list:
            ticket_type = data['type']
            if ticket_type not in ['Assign', 'Reassign']:
                continue

            schedular_name = 'Assign Ticket' if ticket_type == 'Assign' else 'Reassign Ticket'

            notify_status = NotificationSystem.objects.filter(schedular_name=schedular_name).values()
            if not notify_status or not notify_status[0]['status']:
                print(f"Notification disabled for {schedular_name}")
                continue

            correspondance_name = notify_status[0]['correspondance_name']
            cc_json = ast.literal_eval(notify_status[0]['cc_list'])
            cc_list = get_cc_list(cc_json,data['department'])

            assigned_to_email = data['assigned_to_email']
            assigned_to_name = data['assigned_to_name']

            if ticket_type == 'Reassign':
                key = (assigned_to_email, assigned_to_name)
                if key not in grouped_by_assigned_to:
                    grouped_by_assigned_to[key] = {
                        'assigned_by_name': data['assigned_by_name'],
                        'ticket_list': [],
                        'portal_url': WEB_URL,
                        'correspondance_name': correspondance_name,
                        'cc_list': cc_list
                    }

                grouped_by_assigned_to[key]['ticket_list'].append({
                    'ticket_id': data['ticket_id'],
                    'category_name': data.get('category_name', ''),
                    'title': data.get('title', ''),
                    'summary': data.get('summary', ''),
                    'created_at': data['created_date'].strftime("%B %d, %Y %I:%M %p"),
                    'current_status': data.get('current_status', '')
                })
            
                # Notify the ticket creator
                ctx_user = {
                    'type': 'Reassign',
                    'ticket_id': data['ticket_id'],
                    'category_name': data.get('category_name', ''),
                    'title': data.get('title', ''),
                    'summary': data.get('summary', ''),
                    'created_at': data['created_date'].strftime("%B %d, %Y %I:%M %p"),
                    'portal_url': WEB_URL,
                    'user_name': data['created_by_name'],
                    'assigned_by_name': data['assigned_by_name'],
                    'assigned_to_name': data['assigned_to_name'],
                    'current_status': data.get('current_status', '')
                }

                subject_user = f"Reassigned: Ticket #TCK{data['ticket_id']} Reassigned to {data['assigned_to_name']}"
                try:
                    message_user = get_template('ticket_create_tmpl.html').render(ctx_user)
                    msg = EmailMessage(
                        subject=subject_user,
                        body=message_user,
                        from_email=f"{correspondance_name} <do_not_reply@solvedge.in>",
                        to=[data['created_by_email']],
                        cc=cc_list,
                    )
                    msg.content_subtype = "html"
                    email_list.append(msg)
                    print(f"Reassign notification sent to creator: {data['created_by_email']}")
                except Exception as e:
                    print(f"Error mailing ticket creator: {e}")

            elif ticket_type == 'Assign' and len(grouped_by_assigned_to) == 0:
                key = (assigned_to_email, assigned_to_name)
                if key not in grouped_assign:
                    grouped_assign[key] = {
                        'assigned_by_name': data['assigned_by_name'],
                        'ticket_list': [],
                        'portal_url': WEB_URL,
                        'correspondance_name': correspondance_name,
                        'cc_list': cc_list
                    }
                grouped_assign[key]['ticket_list'].append({
                    'ticket_id': data['ticket_id'],
                    'category_name': data.get('category_name', ''),
                    'title': data.get('title', ''),
                    'summary': data.get('summary', ''),
                    'created_at': data['created_date'].strftime("%B %d, %Y %I:%M %p"),
                    'current_status': data.get('current_status', '')
                })
                ctx_user = {
                    'type': 'Assign',
                    'ticket_id': data['ticket_id'],
                    'category_name': data.get('category_name', ''),
                    'title': data.get('title', ''),
                    'summary': data.get('summary', ''),
                    'created_at': data['created_date'].strftime("%B %d, %Y %I:%M %p"),
                    'portal_url': WEB_URL,
                    'user_name': data['created_by_name'],
                    'assigned_by_name': data['assigned_by_name'],
                    'assigned_to_name': data['assigned_to_name'],
                    'current_status': data.get('current_status', '')
                }
                subject_user = f"Assigned: Ticket #TCK{data['ticket_id']} Assigned to {data['assigned_by_name']}"
                try:
                    message_user = get_template('ticket_create_tmpl.html').render(ctx_user)
                    msg = EmailMessage(
                        subject=subject_user,
                        body=message_user,
                        from_email=f"{correspondance_name} <do_not_reply@solvedge.in>",
                        to=[data['created_by_email']],
                        cc=cc_list,
                    )
                    msg.content_subtype = "html"
                    email_list.append(msg)
                    print(f"Assign notification sent to creator: {data['created_by_email']}")
                except Exception as e:
                    print(f"Error mailing ticket creator: {e}")

        # send grouped reassignment mail to assigned staff
        for (email, name), val in grouped_by_assigned_to.items():
            for idx, ticket in enumerate(val['ticket_list'], start=1):
                ticket['s_no'] = idx
            ctx_staff = {
                'type': 'Reassign',
                'user_name': name,
                'assigned_by_name': val['assigned_by_name'],
                'ticket_list': val['ticket_list'],
                'portal_url': val['portal_url']
            }
            try:
                message_staff = get_template('ticket_assign_tmpl.html').render(ctx_staff)
                msg = EmailMessage(
                    subject=f"Tickets Removed: {len(val['ticket_list'])} ticket(s) Removed from your queue",
                    body=message_staff,
                    from_email=f"{val['correspondance_name']} <do_not_reply@solvedge.in>",
                    to=[email],
                    cc=val['cc_list']
                )
                msg.content_subtype = "html"
                email_list.append(msg)
                print(f"Reassign bulk mail sent to: {email}")
            except Exception as e:
                print(f"Error mailing assigned staff: {e}")

        # send grouped assignment mail to assigned staff
        if len(grouped_assign) > 1:
            for (email, name), val in grouped_assign.items():
                for idx, ticket in enumerate(val['ticket_list'], start=1):
                    ticket['s_no'] = idx
                ctx_staff = {
                    'type': 'Assign',
                    'user_name': name,
                    'assigned_by_name': val['assigned_by_name'],
                    'ticket_list': val['ticket_list'],
                    'portal_url': val['portal_url']
                }
                try:
                    message_staff = get_template('ticket_assign_tmpl.html').render(ctx_staff)
                    msg = EmailMessage(
                        subject=f"Tickets Added: {len(val['ticket_list'])} ticket(s) Added to your queue",
                        body=message_staff,
                        from_email=f"{val['correspondance_name']} <do_not_reply@solvedge.in>",
                        to=[email],
                        cc=val['cc_list']
                    )
                    msg.content_subtype = "html"
                    email_list.append(msg)
                    print(f"Assign bulk mail sent to: {email}")
                except Exception as e:
                    print(f"Error mailing assigned staff: {e}")

        if email_list:
            connection = mail.get_connection()
            connection.send_messages(email_list)
            print("email triggered")
            return 'email triggered'

    except Exception as e:
        print("Mail processing error:", e)