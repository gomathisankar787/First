from rest_framework import serializers
from .models import TicketDetails,CategoryDetails,SubCategoryDetails,TicketHistoryDetails,TicketNotesDetails, TicketStatus
from django.db import transaction
from datetime import datetime, timezone
import os,re
from pathlib import Path
from tracker.celery import app
from .tasks_email import send_newticket_email
from tracker.settings import FILE_PATH, EMAIL_TRIGGER
from authapi.models import Department,User
from django.core.files.storage import FileSystemStorage
from django.core.files.base import ContentFile

def clean_name(name):
        """Remove special characters except spaces and underscores, and replace spaces with underscores."""
        name = re.sub(r'[^a-zA-Z0-9 _]', '', name)
        return name.replace(" ", "_").lower()

def handle_uploaded_file(file_content, department_id, user_id, ticket_id, type):
        """
        To handle uploading of a file, storing it with versioning and generating a structured file path.
        :Parameters
        file_content - uploaded file object (InMemoryUploadedFile or TemporaryUploadedFile)
        department_id - ID of the department the file is associated with (integer)
        user_id - ID of the user uploading the file (integer)
        ticket_id - ID of the ticket the file is linked to (integer)
        type - string indicating the file context ('note' for TicketNotesDetails or any other value for TicketDetails)
        :Result
        returns a tuple containing the relative file path (string), the saved file name with version and original name metadata (string), and the latest version string (e.g., '1.0', '1.1')
        """
        department_name = Department.objects.get(id=department_id).name

        date_object = datetime.now().date()
        year, month, day = str(date_object.year), str(date_object.month), str(date_object.day)
        relative_path = os.path.join(department_name, year, month, day)
        absolute_path = os.path.join(FILE_PATH, relative_path)
        Path(absolute_path).mkdir(parents=True, exist_ok=True)

        file_name_raw, file_ext = os.path.splitext(file_content.name)
        cleaned_file_name = clean_name(file_name_raw)
        original_file_name = f"{cleaned_file_name}{file_ext}"
        user_name = User.objects.get(id=user_id).first_name
        if type=="note":
            previous_version = TicketNotesDetails.objects.filter(ticket_id=ticket_id).order_by('-created_at').first()
        else:
            previous_version = TicketDetails.objects.filter(id=ticket_id).first()

        if previous_version and previous_version.file_path:
            # previous_file_name = os.path.basename(previous_version.file_path)
            # version_match =  re.search(rf"{re.escape(cleaned_file_name)}_(\d+){re.escape(file_ext)}", previous_file_name)
            # if version_match:
            #     last_version = int(version_match.group(1))
            #     print('last_version',last_version)
            # else:
            #     last_version = 1
            major, minor = map(int, previous_version.version.split('.'))
            if minor == 9:
                major += 1
                minor = 0
            else:
                minor += 1
            latest_version = f"{major}.{minor}"
        else:
            latest_version = '1.0'
        versioned_file_name = f"{cleaned_file_name}_{user_name}_{latest_version}__ORIG__{cleaned_file_name}{file_ext}"
        fs = FileSystemStorage(location=absolute_path)
        fs.save(versioned_file_name, ContentFile(file_content.read()))

        return relative_path, versioned_file_name,latest_version,original_file_name

def userRole(user_id):
    """
    To determine the user's role based on their ID and check if the user is a regular user.
    :Parameters
    user_id - ID of the user (integer)
    :Result
    returns True if the user is a regular user (not a superuser or staff), otherwise returns False
    """
    user_object = User.objects.filter(id=user_id).first()
    if user_object.is_superuser or user_object.is_staff:
        return False
    return True

class TicketUploadSerializer(serializers.Serializer):
    id = serializers.IntegerField(required=False)
    title = serializers.CharField(required=False, allow_blank=True)
    summary = serializers.CharField(required=False, allow_blank=True)
    doc_file = serializers.FileField(required=False)
    # status = serializers.IntegerField(required=True, allow_null=True)
    category = serializers.IntegerField(required=True, allow_null=True)
    sub_category = serializers.IntegerField(required=True, allow_null=True)
    department = serializers.IntegerField(required=True, allow_null=True)
    tag_staff = serializers.IntegerField(required=False, allow_null=True)
    comments = serializers.CharField(required=False, allow_blank=True)
    created_by = serializers.IntegerField(required=False)
    updated_by = serializers.IntegerField(required=False)

    def create(self, validated_data):
        file_path = ''
        file_name = ''
        file_content = validated_data.get('doc_file', None)
        department_id = validated_data['department']
        department_obj = Department.objects.filter(id=department_id).values().first()
        department_ticket_flag = department_obj['is_ticket']
        
        if department_ticket_flag is False:
            raise ValueError("Ticket functionality is not enabled for this department.")

        with transaction.atomic():
            if file_content and validated_data.get('department'):
                department_name = department_obj['name']
                date_object = datetime.now().date()
                year = str(date_object.year)
                month = str(date_object.month)
                day = str(date_object.day)

                relative_path = os.path.join(department_name, year, month, day)
                file_path = os.path.join(FILE_PATH, relative_path)
                Path(file_path).mkdir(parents=True, exist_ok=True)

                raw_file_name, file_ext = os.path.splitext(file_content.name)
                user_id = self.context['user_id'] #validated_data['created_by']
                user_name = User.objects.get(id=user_id).first_name

                cleaned_file_name = clean_name(raw_file_name)
                version = '1.0'
                file_name = f"{cleaned_file_name}_{user_name}_{version}__ORIG__{cleaned_file_name}{file_ext}"

            tag_staff = validated_data.get('tag_staff')
            ticket = TicketDetails(
                title=validated_data.get('title', ''),
                summary=validated_data.get('summary', ''),
                file_path=relative_path if file_content else '',
                file_name=file_name if file_content else '',
                org_file_name = f"{cleaned_file_name}{file_ext}" if file_content else '',
                version=version if file_content else '',
                category_id=validated_data['category'],
                status_updated_at=datetime.now(timezone.utc),
                status_id=TicketStatus.StatusStage.OPEN if department_id != 9 else TicketStatus.StatusStage.INPROGRESS,
                sub_category_id=validated_data['sub_category'],
                department_id=validated_data['department'],
                tag_staff_id = tag_staff if tag_staff != 0 else None,
                created_by_id= self.context['user_id'], #validated_data['created_by']
                assigned_by_id=9 if department_id ==3 else None,
                worked_by_id=9 if department_id ==3 else None
            )
            ticket.save()
                
            
            # category = validated_data['category']
            # department = validated_data['department']

            # bat_no = f"TK{category:03d}{department:03d}{ticket.id}"
            # ticket.batch_number = bat_no
            # ticket.save(update_fields=["batch_number"])

            tick_hist = TicketHistoryDetails(
                title=validated_data.get('title', ''),
                summary=validated_data.get('summary', ''),
                file_path=relative_path if file_content else '',
                file_name=file_name if file_content else '',
                org_file_name = f"{cleaned_file_name}{file_ext}" if file_content else '',
                version=version if file_content else '',
                ticket=ticket,
                category_id=validated_data['category'],
                status_id=TicketStatus.StatusStage.OPEN,
                sub_category_id=validated_data['sub_category'],
                department_id=validated_data['department'],
                tag_staff_id=validated_data.get('tag_staff') if validated_data.get('tag_staff') != 0 else None,
                updated_by_id=self.context['user_id'] #validated_data['updated_by']
            )
            tick_hist.save()

            if file_content:
                fs = FileSystemStorage(location=file_path)
                fs.save(file_name, ContentFile(file_content.read()))
            # print('ticket data:', {field.name: getattr(ticket, field.name) for field in ticket._meta.fields})

            if EMAIL_TRIGGER:
                try:
                    result = app.control.broadcast('ping', reply=True, limit=1)
                    if result:
                        trans_data = {}
                        trans_data['type'] = "Created"
                        trans_data['ticket_id'] = ticket.id
                        trans_data['category_name'] = ticket.category.name
                        trans_data['title'] = ticket.title
                        trans_data['department'] = ticket.department_id
                        trans_data['summary'] = ticket.summary
                        trans_data['created_date'] = ticket.created_at
                        trans_data['user_mail'] = ticket.created_by.email
                        trans_data['user_name'] = f"{ticket.created_by.first_name} {ticket.created_by.last_name}"
                        send_newticket_email.delay(trans_data)
                    else:
                        print('Celery process not responding')
                except Exception as e:
                    print('Allocation email error',e)
            return ticket

    def update(self, instance, validated_data):
        new_file_content = validated_data.pop('doc_file', None)

        if new_file_content and validated_data.get('department'):
            department_id = validated_data.get('department', instance.department_id)
            user_id = self.context['user_id'] #validated_data['created_by']
            doc_folder, versioned_file_name,version,original_file_name = handle_uploaded_file(
                file_content=new_file_content,
                department_id=department_id,
                user_id=user_id,
                ticket_id = instance.id,
                type='ticket'
            )

        else:
            doc_folder = instance.file_path
            versioned_file_name = instance.file_name
            version = instance.version
            original_file_name = instance.org_file_name

        with transaction.atomic():
            instance.title = validated_data.get('title', instance.title)
            instance.summary = validated_data.get('summary', instance.summary)
            instance.status_id = TicketStatus.StatusStage.OPEN
            instance.status_updated_at = datetime.now(timezone.utc)
            instance.category_id = validated_data.get('category', instance.category_id)
            instance.sub_category_id = validated_data.get('sub_category', instance.sub_category_id)
            instance.department_id = validated_data.get('department', instance.department_id)
            instance.tag_staff_id = validated_data.get('tag_staff', instance.tag_staff_id) if validated_data.get('tag_staff') != 0 else None
            instance.file_path = doc_folder
            instance.file_name = versioned_file_name
            instance.org_file_name = original_file_name
            instance.version = version
            instance.save()

            tick_hist = TicketHistoryDetails(
                title=validated_data.get('title', instance.title),
                summary=validated_data.get('summary', instance.summary),
                comments=validated_data.get('comments'),
                ticket=instance,
                file_path=doc_folder,
                file_name=versioned_file_name,
                org_file_name = original_file_name,
                version=version,
                status_id=TicketStatus.StatusStage.OPEN,
                category_id=validated_data.get('category', instance.category_id),
                sub_category_id=validated_data.get('sub_category', instance.sub_category_id),
                department_id=validated_data.get('department', instance.department_id),
                tag_staff_id=validated_data.get('tag_staff', instance.tag_staff_id) if validated_data.get('tag_staff') != 0 else None,
                updated_by_id=self.context['user_id'] #validated_data.get('updated_by')
            )
            tick_hist.save()

        return instance

class TicketUploadDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketDetails
        exclude = ['status', 'category', 'sub_category', 'department', 'tag_staff', 'created_by']
    def to_representation(self, instance):
        """ Ensures extra fields are included in the response """
        data = super().to_representation(instance)
        data['status_id'] = instance.status_id
        data['category_id'] = instance.category_id
        data['sub_category_id'] = instance.sub_category_id
        data['department_id'] = instance.department_id
        data['tag_staff_id'] = instance.tag_staff_id if instance.tag_staff else None
        data['created_by_id'] = instance.created_by_id
        data['status_name'] = instance.status.name if instance.status else None
        data['category_name'] = instance.category.name if instance.category else None
        data['sub_category_name'] = instance.sub_category.name if instance.sub_category else None
        data['department_name'] = instance.department.name if instance.department else None
        data['tag_staff_name'] = (
            f"{instance.tag_staff.first_name} {instance.tag_staff.last_name}".strip()
            if instance.tag_staff else None
        )
        data['created_by_name'] = (
            f"{instance.created_by.first_name} {instance.created_by.last_name}".strip()
            if instance.created_by else None
        )
        latest_update = TicketHistoryDetails.objects.filter(ticket=instance).select_related('updated_by').order_by('-updated_at').first()

        data['updated_by_id'] = latest_update.updated_by.id if latest_update and latest_update.updated_by else None
        data['updated_by_name'] = (
            f"{latest_update.updated_by.first_name} {latest_update.updated_by.last_name}".strip()
            if latest_update and latest_update.updated_by else None
        )
        return data

class AddTicketNoteSerializer(serializers.Serializer):
    ticket_id = serializers.IntegerField()
    msg_notes = serializers.CharField()
    is_private = serializers.BooleanField(required=False)
    # status_id = serializers.IntegerField(required=False)
    file = serializers.FileField(required=False)
    user_id = serializers.IntegerField()

    def create(self, validated_data):
        ticket_id = validated_data.get("ticket_id")
        user_id = self.context['user_id'] # validated_data.get("user_id")
        ticket = TicketDetails.objects.select_related('category','worked_by','status','created_by').filter(id=ticket_id).first()
        if not ticket:
            raise serializers.ValidationError("Ticket not found")

        file_obj = validated_data.get("file")
        file_name, file_path = None, None

        if file_obj:
            department_id = ticket.department_id
            file_path, file_name,version,org_file_name = handle_uploaded_file(
                file_content=file_obj,
                department_id=department_id,
                user_id=user_id,
                ticket_id = ticket_id,
                type = "note"
            )
        base_user = True if ticket.created_by_id == user_id else False
        is_staff = True if user_id == ticket.worked_by_id else False
        notes_data = {
            "ticket": ticket,
            "msg_notes": validated_data.get("msg_notes"),
            "is_staff":is_staff,
            "file_name": file_name if file_obj else '',
            "org_file_name": org_file_name if file_obj else '',
            "file_path": file_path if file_obj else '',
            "version":version  if file_obj else '',
            "created_by_id": user_id,
        }

        if not base_user:
            notes_data["is_private"] = validated_data.get("is_private", False)
        #     TicketDetails.objects.filter(id=ticket_id).update(notes_status='01')
        #     notes_data["status_id"] = validated_data.get("status_id", ticket.status_id)
        # else:
        #     TicketDetails.objects.filter(id=ticket_id).update(notes_status='11')

        notes = TicketNotesDetails.objects.create(**notes_data)

        if user_id == ticket.created_by_id and ticket.receiver_notes is False:
            ticket.receiver_notes = True
            ticket.save()
        if user_id == ticket.worked_by_id and ticket.sender_notes is False and validated_data.get("is_private") is False:
            ticket.sender_notes = True
            ticket.save()

        if EMAIL_TRIGGER:
                try:
                    result = app.control.broadcast('ping', reply=True, limit=1)
                    if result and validated_data.get("is_private") is False:
                        trans_data = {}
                        trans_data['type'] = "Notes"
                        trans_data['ticket_id'] = ticket.id
                        trans_data['title'] = ticket.title
                        trans_data['department'] = ticket.department_id
                        trans_data['category_name'] = ticket.category.name
                        trans_data['summary'] = ticket.summary
                        trans_data['notes'] = notes.msg_notes
                        trans_data['created_date'] = ticket.created_at
                        if not base_user:
                            trans_data['user_type'] = "staffuser"
                            trans_data['user_mail'] = ticket.created_by.email
                            trans_data['comment_for'] = f"{ticket.created_by.first_name} {ticket.created_by.last_name}"
                            trans_data['user_name'] = f"{ticket.worked_by.first_name} {ticket.worked_by.last_name}"
                        else:
                            trans_data['user_type'] = "baseuser"
                            trans_data['user_mail'] = ticket.worked_by.email
                            trans_data['comment_for'] = f"{ticket.created_by.first_name} {ticket.created_by.last_name}"
                            trans_data['user_name'] = f"{ticket.worked_by.first_name} {ticket.worked_by.last_name}"
                        send_newticket_email.delay(trans_data)
                    else:
                        print('Celery process not responding')
                except Exception as e:
                    print('Notes upload email error',e)

        return notes

class AddTicketNoteDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TicketNotesDetails
        fields = '__all__'

class CreateCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryDetails
        fields = ('id','name', 'desc', 'status', 'created_by','department')
        extra_kwargs = {
            'id': {'required': False, 'allow_null': True}
        }

    def create(self, validated_data):
        return CategoryDetails.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.desc = validated_data.get('desc', instance.desc)
        instance.status = validated_data.get('status', instance.status)
        instance.created_by = validated_data.get('created_by', instance.created_by)
        instance.department = validated_data.get('department', instance.department)
        instance.updated_at = datetime.now(timezone.utc)
        instance.save()
        return instance

class CreateSubCategorySerializer(serializers.ModelSerializer):
    first_esc = serializers.IntegerField(required=False, allow_null=True, default=0)
    recurring_esc = serializers.IntegerField(required=False, allow_null=True, default=0)
    class Meta:
        model = SubCategoryDetails
        fields = ('id', 'name', 'desc', 'status', 'first_esc', 'recurring_esc', 'category', 'created_by')

    def create(self, validated_data):
        return SubCategoryDetails.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name', instance.name)
        instance.desc = validated_data.get('desc', instance.desc)
        instance.status = validated_data.get('status', instance.status)
        instance.first_esc = validated_data.get('first_esc', instance.first_esc)
        instance.recurring_esc = validated_data.get('recurring_esc', instance.recurring_esc)
        instance.category = validated_data.get('category', instance.category)
        instance.created_by = validated_data.get('created_by', instance.created_by)
        instance.updated_at = datetime.now(timezone.utc)
        instance.save()
        return instance

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryDetails
        fields = '__all__'

class CategoryListSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryDetails
        fields = '__all__'
    def to_representation(self, instance):
        """ Ensures extra fields are included in the response """
        data = super().to_representation(instance)
        data['department_name'] = instance.department.name
        return data

class SubCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = SubCategoryDetails
        fields = '__all__'

class UpdatedTicketDownloadSerializer(serializers.Serializer):
    ticket_id = serializers.IntegerField()

class TicketDateRangeSerializer(serializers.Serializer):
    start_time = serializers.DateField()
    end_time = serializers.DateField()

class StaffTicketListSerializer(serializers.Serializer):
    status_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    date_range = TicketDateRangeSerializer()
    # category_id = serializers.IntegerField(required=False, allow_null=True)
    is_escalate = serializers.BooleanField(required=False, allow_null=True)
    is_resolved = serializers.BooleanField(required=False, allow_null=True)

class ReAssignTicketSerializer(serializers.Serializer):
    assigned_by = serializers.IntegerField()
    assigned_to = serializers.IntegerField()
    is_reassign = serializers.BooleanField(default=False)
    comments = serializers.CharField(required=False)
    ticket_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )

class UpdateTicketStatusSerializer(serializers.Serializer):
    ticket_id = serializers.IntegerField()
    status_id = serializers.IntegerField()
    # comments = serializers.CharField()

class UserEscalateTicketSerializer(serializers.Serializer):
    ticket_id = serializers.IntegerField()
    comments = serializers.CharField()

class AllTicketListSerializer(serializers.Serializer):
    status_id =serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    category_id = serializers.IntegerField(required=False, allow_null=True)
    is_escalate = serializers.BooleanField(required=False, allow_null=True)
    staff_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    date_range = TicketDateRangeSerializer()
    unassigned = serializers.BooleanField(required=False)
    department_id = serializers.ListSerializer(
        child = serializers.IntegerField(required=False)
    )

class StaffProductionReportSerializer(serializers.Serializer):
    department_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    category_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    staff_id = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    range_key = serializers.CharField(required=False)
    date_range = TicketDateRangeSerializer()

class AllUserTicketListSerializer(serializers.Serializer):
    status = serializers.ListSerializer(
        child = serializers.IntegerField()
    )
    date_range = TicketDateRangeSerializer()
    # department_id = serializers.ListSerializer(
    #     child = serializers.IntegerField(required=False)
    # )


class UnifiedStatusNoteSerializer(serializers.Serializer):
    ticket_id = serializers.IntegerField()
    status_id = serializers.IntegerField()
    msg_notes = serializers.CharField(required=False, allow_blank=True)
    is_private = serializers.BooleanField(required=False)
    file = serializers.FileField(required=False)
    user_id = serializers.IntegerField()
    is_cycle_restrict = serializers.BooleanField()

    # def to_internal_value(self, data):
    #     data = super().to_internal_value(data)
    #     # Optional: force boolean conversion
    #     data['is_private'] = bool(int(data.get('is_private', 0)))
    #     return data

class GetSubCategoryListSerializer(serializers.Serializer):
    category_id = serializers.IntegerField()

class UserTicketListSerializer(serializers.Serializer):
    department_id = serializers.ListSerializer(
        child = serializers.IntegerField(required=False)
    )
    date_range = TicketDateRangeSerializer()


class UserObjSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'first_name', 'last_name', 'is_active', 'email')

class CategoryObjSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryDetails
        fields = ('id', 'name', 'desc', 'status')

class DeptUserSerializer(serializers.ModelSerializer):
    user_info = UserObjSerializer(many=True, source='user_dept')
    category_info = CategoryObjSerializer(many=True, source='category_dept')
    class Meta:
        model = Department
        fields = '__all__'

class DeptUserOnlySerializer(serializers.ModelSerializer):
    user_info = UserObjSerializer(many=True, source='user_dept')
    class Meta:
        model = Department
        fields = '__all__'

class DeptSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ('id', 'name', 'status')