from django.shortcuts import render
from rest_framework import generics, status
from rest_framework.parsers import MultiPartParser
from drf_yasg.utils import swagger_auto_schema
from rest_framework.decorators import api_view
from .serializers import DeptSerializer, TicketUploadSerializer,CreateCategorySerializer,DeptUserOnlySerializer,CreateSubCategorySerializer,TicketUploadDetailsSerializer,CategorySerializer,SubCategorySerializer,UpdatedTicketDownloadSerializer,StaffTicketListSerializer,ReAssignTicketSerializer,AddTicketNoteSerializer,AddTicketNoteDetailsSerializer,UpdateTicketStatusSerializer,UserEscalateTicketSerializer,StaffProductionReportSerializer,AllTicketListSerializer,AllUserTicketListSerializer,UnifiedStatusNoteSerializer,GetSubCategoryListSerializer,UserTicketListSerializer,DeptUserSerializer,CategoryListSerializer
from rest_framework.response import Response
from .models import TicketDetails,SubCategoryDetails,CategoryDetails,TicketHistoryDetails, TicketNotesDetails, User, TicketStatus,TicketAssignedHistory, TicketStatusHistory, TicketEscalationHistory
from django.db.models import F,Value, Case, When, IntegerField, CharField
from django.http import HttpResponse
from django.db.models.functions import Concat, ExtractYear, ExtractMonth
from datetime import datetime,timezone, timedelta, date
import os, mimetypes,re
from django.db import transaction
from authapi.models import HolidayList,Department,User,UserRole
from tracker.dx_datagrid import DxModelViewSet, DxAPIView, DxModelViewSetQuery
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.styles.borders import Border, Side
from openpyxl import Workbook
from django.core.files.storage import FileSystemStorage
from pathlib import Path
from django.core.files.base import ContentFile
from openpyxl.worksheet.dimensions import ColumnDimension, DimensionHolder
from openpyxl.utils import get_column_letter
from django.db.models.functions import TruncDate, TruncMonth, TruncYear
from django.db.models import Q, Count, F
from tracker.settings import FILE_PATH,EMAIL_TRIGGER
from tracker.custom_permissions import IsAdmin, IsBasicUser, IsManager, IsStaff
from tracker.celery import app
from .tasks_email import send_newticket_email,send_ticket_assign_mail_v2
from tracker.tasks_status import close_and_escalate_tickets,close_tickets,escalate_tickets,daily_ts_production_report,send_status_email,get_user_biomet_details,timesheet_remainder_email
from rest_framework.permissions import IsAuthenticated
from django.db.models import Prefetch


@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def CategoryList(request):
    is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False
    filter={}
    if not is_admin:
        filter['department_id'] = request.user.dept_id
    category_list = CategoryDetails.objects.select_related('department').filter(**filter).values().annotate(department_name=F('department__name')).order_by('id')
    return Response(category_list)

class ManagerCategoryList(generics.GenericAPIView):
    permission_classes = [IsManager|IsStaff|IsBasicUser|IsAdmin]
    def get(self,request):
        try:
            # department_id = request.user.dept_id
            category_list = CategoryDetails.objects.select_related('department').values().annotate(department_name=F('department__name')).order_by('id')
            return Response(category_list)
        except Exception as e:
            print('ManagerCategoryList Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdminCategoryList(generics.GenericAPIView):
    permission_classes = [IsAdmin]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self,request):
        try:
            department_id = request.data.get('department_id')
            filter = {}

            if department_id != []:
                filter['department_id__in'] = department_id

            category_list = CategoryDetails.objects.select_related('department').filter(**filter).values().annotate(department_name=F('department__name')).order_by('id')
            return Response(category_list)
        except Exception as e:
            print('AdminCategoryList Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DeptUserAndCategoryList(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self, request):
        try:
            filter = {'is_ticket':True,'status':True}
            is_manager =True if request.user.role_id == UserRole.RoleStatus.MANAGER else False
            staff_list = [UserRole.RoleStatus.MANAGER,UserRole.RoleStatus.STAFF,UserRole.RoleStatus.ADMIN]
            dept_id = request.data.get('department_id')

            if is_manager:
                dept_id = request.user.dept_id
                filter['id'] = dept_id
            if request.data.get('department_id') != [] and not is_manager:
                filter['id__in'] = dept_id

            user_filter = User.objects.filter(role_id__in=staff_list,is_active=True)
            category_filter = CategoryDetails.objects.filter(status=True)
            prefetch1 = Prefetch('user_dept',queryset=user_filter)
            prefetch2 = Prefetch('category_dept',queryset=category_filter)
            dept_obj = Department.objects.prefetch_related(prefetch1,prefetch2).filter(**filter)
            serializer = DeptUserSerializer(dept_obj, many=True)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            print('DeptUserList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class DeptAndUserList (generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self, request):
        try:
            filter = {'is_ticket':True,'status':True}
            is_manager =True if request.user.role_id == UserRole.RoleStatus.MANAGER else False
            staff_list = [UserRole.RoleStatus.MANAGER,UserRole.RoleStatus.STAFF,UserRole.RoleStatus.ADMIN]
            dept_id = request.data.get('department_id')

            if is_manager:
                dept_id = request.user.dept_id
                filter['id'] = dept_id
            if request.data.get('department_id') != [] and not is_manager:
                filter['id__in'] = dept_id

            user_filter = User.objects.filter(role_id__in=staff_list,is_active=True)
            prefetch1 = Prefetch('user_dept',queryset=user_filter)
            dept_obj = Department.objects.prefetch_related(prefetch1).filter(**filter)
            serializer = DeptUserOnlySerializer(dept_obj, many=True)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            print('DeptUserList error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def SubCategoryList(request):
    sub_category_list = SubCategoryDetails.objects.select_related('category').all().values().annotate(category_name=F('category__name')).order_by('id')
    return Response(sub_category_list)

class GetSubCategoryList(generics.GenericAPIView):
    permission_classes = []
    @swagger_auto_schema(request_body=GetSubCategoryListSerializer)
    def post(self,request):
        try:
            category_id = request.data.get('category_id')
            sub_category_list = SubCategoryDetails.objects.filter(category_id=category_id,status=True).values().annotate(category_name=F('category__name')).order_by('id')
            return Response(sub_category_list)
        except Exception as e:
            print('SubCategoryListView Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def StatusList(request):
    status_list = TicketStatus.objects.filter(is_active=True).values().order_by('id')
    return Response(status_list)

class CategoryCreateView(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=CreateCategorySerializer)
    def post(self, request):
        try:
            serializer = CreateCategorySerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            category = serializer.save()
            return Response(CategoryListSerializer(category).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            print('CategoryCreateView Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CategoryUpdateView(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=CreateCategorySerializer)
    def post(self, request):
        try:
            category_instance = CategoryDetails.objects.get(pk=request.data['id'])
            if category_instance:
                serializer_data = CreateCategorySerializer(instance=category_instance, data=request.data)
                serializer_data.is_valid(raise_exception=True)
                data_obj = serializer_data.save()
                out_data = CategoryListSerializer(data_obj).data
                return Response(out_data, status=status.HTTP_200_OK)
            else:
                raise Exception('No data found!')
        except Exception as e:
            print('CategoryUpdate Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class SubCategoryCreateView(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=CreateSubCategorySerializer)
    def post(self, request):
        try:
            serializer = CreateSubCategorySerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            sub_category = serializer.save()
            sub_category_obj = SubCategoryDetails.objects.select_related('category').filter(id=sub_category.id).annotate(category_name=F('category__name')).first()
            category_name = sub_category_obj.category_name
            response_data = CreateSubCategorySerializer(sub_category).data
            response_data['category_name'] = category_name
            return Response(response_data, status=status.HTTP_201_CREATED)
        except Exception as e:
            print('SubCategoryCreateView Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class SubCategoryUpdateView(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=CreateSubCategorySerializer)
    def post(self, request):
        try:
            sub_category_instance = SubCategoryDetails.objects.get(pk=request.data['id'])
            if sub_category_instance:
                serializer_data = CreateSubCategorySerializer(instance=sub_category_instance, data=request.data)
                serializer_data.is_valid(raise_exception=True)
                data_obj = serializer_data.save()
                out_data = SubCategorySerializer(data_obj).data
                return Response(out_data, status=status.HTTP_200_OK)
            else:
                raise Exception('No data found!')
        except Exception as e:
            print('SubCategoryUpdate Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TicketUpload(generics.GenericAPIView):
    parser_classes = ([MultiPartParser,])
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=TicketUploadSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            # base_user = request.user.role_id == UserRole.RoleStatus.BASIC
            # if base_user and user_id != int(request.data['created_by']):
            #     return Response({'detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)
            # request.data['created_by'] = user_id
            # request.data['updated_by'] = user_id
            serializer = TicketUploadSerializer(data=request.data, context={'user_id': user_id})
            serializer.is_valid(raise_exception=True)
            tic_info = serializer.save()
            try:
                tic_info = TicketDetails.objects.select_related('status', 'category', 'sub_category','department','tag_staff', 'created_by').get(id=tic_info.id)
                return Response(TicketUploadDetailsSerializer(tic_info).data, status=status.HTTP_201_CREATED)
            except Exception as e:
                print('Ticket updated, but error while serializing response:', str(e))
                return Response({'Invalid Data': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('TicketUpload Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TicketUpdate(generics.GenericAPIView):
    parser_classes = ([MultiPartParser,])
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=TicketUploadSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            # base_user = request.user.role_id == UserRole.RoleStatus.BASIC
            # if base_user and user_id != int(request.data['updated_by']):
            #     return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)
            doc_file_data = TicketDetails.objects.get(id = request.data['id'])
            if doc_file_data.status_id != TicketStatus.StatusStage.OPEN:
                return Response({'Detail': 'This process is not acceptable for your current ticket status'}, status=status.HTTP_403_FORBIDDEN)
            # request.data['updated_by'] = user_id
            # request.data['created_by'] = user_id
            serializer = TicketUploadSerializer(instance=doc_file_data,data=request.data, context={'user_id': user_id},partial=True)
            serializer.is_valid(raise_exception=True)
            tic_info = serializer.save()
            try:
                tic_info = TicketDetails.objects.select_related('status', 'category', 'sub_category','department','tag_staff', 'created_by').get(id=tic_info.id)
                return Response(TicketUploadDetailsSerializer(tic_info).data, status=status.HTTP_201_CREATED)
            except Exception as e:
                print('Ticket updated, but error while serializing response:', str(e))
                return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('TicketUpdate Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def queryset_for_ticket_list(self):
    """
    To retrieve a list of ticket details with related information and annotated fields for display

    :Parameters

    self - reference to the instance of the class (typically a view or manager)

    :Result

    returns a queryset of tickets with selected fields, annotated names from related models,
    and ordered by creation date in descending order
    """
    ticket_info = (
        TicketDetails.objects
        .select_related("status", "category", "sub_category", "department", "tag_staff", "created_by", "assigned_by")
        .annotate(status_name = F('status__name'),category_name = F('category__name'),
                sub_category_name = F('sub_category__name'), department_name = F('department__name'),
                ticket_number=Concat(Value('TCK-'), F('id'),  output_field=CharField()),
                tag_staff_name=Case(
                    When(tag_staff__isnull=False,
                        then=Concat(F("tag_staff__first_name"), Value(" "), F("tag_staff__last_name"))),
                    default=Value(""),
                    output_field=CharField()
                ),
                created_by_name=Concat(
                        F("created_by__first_name"), Value(" "), F("created_by__last_name")
                    ),
                assigned_by_name=Concat(
                        F("assigned_by__first_name"), Value(" "), F("assigned_by__last_name")
                    ))
        .values(
            "id","ticket_number", "title", "summary","org_file_name", "is_escalate", "status_id", "status_name","category_id", "category_name","is_cycle_restrict",
            "sub_category_id", "sub_category_name", "department_id","department_name","tag_staff_id","tag_staff_name","assigned_by_id","assigned_by_name","resolved_hours",
            "sender_notes","receiver_notes","created_by_id","created_by_name","created_at"
        )
    )

    return ticket_info

class UserTicketList(DxAPIView):
    permission_classes = [IsAdmin|IsStaff|IsBasicUser|IsManager]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def get_queryset(self): # def get(self):
        try:
            request = self.request
            user_id = request.user.id
            department_id = request.data.get('department_id')
            ticket_Info = queryset_for_ticket_list(self)
            filters = {'created_by':user_id,'is_active':True}
            if department_id != []:
                filters['department_id__in'] = department_id
            user_ticket_Info = ticket_Info.filter(**filters).order_by('-status_updated_at') #~Q(status=TicketStatus.StatusStage.RESOLVED)
            return user_ticket_Info
        except Exception as e:
            print('TicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AllUserTicketList(DxAPIView):
    permission_classes = [IsAdmin|IsStaff|IsBasicUser|IsManager]
    @swagger_auto_schema(request_body=AllUserTicketListSerializer)
    def get_queryset(self): # def post(self, request):
        try:
            request = self.request
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            department_id = request.data.get('department_id')
            status_ids = request.data.get('status')
            department_id = request.data.get('department_id')
            user_id = request.user.id
            ticket_Info = queryset_for_ticket_list(self)

            filters = {'created_by': user_id,
                    'created_at__range':[start_date,end_date],
                    }
            if status_ids != []:
                filters['status_id__in'] = status_ids
            if department_id != []:
                filters['department_id__in'] = department_id

            user_ticket_Info = ticket_Info.filter(**filters).order_by('-status_updated_at')
            return user_ticket_Info
        except Exception as e:
            print('TicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class StaffTicketList(DxAPIView):
    permission_classes=[IsAdmin|IsStaff|IsManager]
    # @swagger_auto_schema(request_body=StaffTicketListSerializer)
    def get_queryset(self): # def post(self, request):
        try:
            request = self.request
            user_id = request.user.id

            ticket_Info = queryset_for_ticket_list(self)
            filters = {'status': 1,
                        'is_active':True,'department_id':request.user.dept_id}

            user_ticket_Info = ticket_Info.filter(**filters)\
            .annotate(
                priority=Case(
                    When(tag_staff_id=user_id, then=Value(0)),
                    default=Value(1),
                    output_field=IntegerField()
                )
            ).order_by('priority','-id')

            return user_ticket_Info
        except Exception as e:
            print('StaffTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class StaffAssignedTicketList(DxAPIView):
    permission_classes=[IsAdmin|IsStaff|IsManager]
    @swagger_auto_schema(request_body=StaffTicketListSerializer)
    def get_queryset(self): # def post(self,request):
        try:
            request = self.request
            user_id = request.user.id
            # category_id = request.data.get('category_id')
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            status_id = request.data.get('status_id')
            # is_resolved = request.data.get('is_resolved')
            is_escalate = request.data.get('is_escalate')
            ticket_Info = queryset_for_ticket_list(self)

            filters = {'worked_by':user_id,
                        'created_at__range':[start_date,end_date]}
            if status_id == []:
                filters['status__in'] = [TicketStatus.StatusStage.INPROGRESS,TicketStatus.StatusStage.ONHOLD,TicketStatus.StatusStage.RESOLVED,TicketStatus.StatusStage.REOPEN,TicketStatus.StatusStage.CLOSED]
            if status_id:
                filters['status__in'] = status_id
            if is_escalate is False:
                filters['is_escalate'] = True

            user_ticket_Info = ticket_Info.filter(**filters).order_by('-id')

            return user_ticket_Info
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class StaffInprogressTicketList(DxAPIView):
    permission_classes=[IsAdmin|IsStaff|IsManager]
    # @swagger_auto_schema(request_body=StaffTicketListSerializer)
    def get_queryset(self):   # def get(self,request):
        try:
            request = self.request
            user_id = request.user.id

            ticket_Info = queryset_for_ticket_list(self)

            status_ids = [TicketStatus.StatusStage.INPROGRESS, TicketStatus.StatusStage.ONHOLD,TicketStatus.StatusStage.REOPEN]
            filters = {'worked_by':user_id,
                        'status__in':status_ids,
                        'is_active':True} #,'department_id':request.user.dept_id
            user_ticket_Info = ticket_Info.filter(**filters).order_by('-status_updated_at')

            return user_ticket_Info
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AllTicketList(DxAPIView): #generics.GenericAPIView
    permission_classes=[IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AllTicketListSerializer)
    def get_queryset(self): #def post(self,request):     
        try:
            request = self.request
            # user_id = request.user.id
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            category_id = request.data.get('category_id')
            status_id = request.data.get('status_id')
            is_escalate = request.data.get('is_escalate')
            staff_id = request.data.get('staff_id')
            unassigned = request.data.get('unassigned')
            is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False

            if is_admin:
                department_id = request.data.get('department_id')
            else:
                department_id = request.user.dept_id

            ticket_Info = queryset_for_ticket_list(self)
            filters = {'created_at__range':[start_date,end_date],
                    'status__in':[TicketStatus.StatusStage.OPEN,TicketStatus.StatusStage.INPROGRESS,TicketStatus.StatusStage.ONHOLD,TicketStatus.StatusStage.REOPEN]}
            if category_id != 0:
                filters['category'] = category_id
            if status_id != []:
                filters['status__in'] = status_id
            if staff_id != []:
                filters['worked_by__in'] = staff_id
            if is_escalate is False:
                filters['is_escalate'] = True
            if unassigned:
                filters['status__in'] = [TicketStatus.StatusStage.OPEN]
            if request.data.get('department_id') != [] and is_admin:
                filters['department_id__in'] = department_id
            if not is_admin:
                filters['department_id'] = department_id

            user_ticket_Info = ticket_Info.filter(**filters).order_by('-id')

            # return Response(user_ticket_Info,status=status.HTTP_200_OK)
            return user_ticket_Info
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AllTicketDetailsList(DxAPIView):
    permission_classes=[IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AllTicketListSerializer)
    def get_queryset(self):    # def post(self,request):
        try:
            request = self.request
            # user_id = request.user.id
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            category_id = request.data.get('category_id')
            status_id = request.data.get('status_id')
            is_escalate = request.data.get('is_escalate')
            staff_id = request.data.get('staff_id')
            is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False

            if is_admin:
                department_id = request.data.get('department_id')
            else:
                department_id = request.user.dept_id

            ticket_Info = queryset_for_ticket_list(self)
            filters = {'created_at__range':[start_date,end_date]}
            if category_id != 0:
                filters['category'] = category_id
            if status_id != []:
                filters['status__in'] = status_id
            if staff_id != []:
                filters['worked_by__in'] = staff_id
            if is_escalate is False:
                filters['is_escalate'] = True
            if request.data.get('department_id') != [] and is_admin:
                filters['department_id__in'] = department_id
            if not is_admin:
                filters['department_id'] = department_id

            user_ticket_Info = ticket_Info.filter(**filters).order_by('-id')
            return user_ticket_Info
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AssignTicket(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self,request):
        try:
            user_id = request.user.id
            ticket_id = request.data.get('ticket_id')

            ticket = TicketDetails.objects.select_related('status','created_by','assigned_by').filter(id=ticket_id).first()

            if ticket.created_by_id == user_id:
                return Response({"Detail": "Self-Assigned is disabled, Please select different ticket."}, status=status.HTTP_400_BAD_REQUEST)

            ticket.assigned_by_id = user_id
            ticket.worked_by_id = user_id
            ticket.status_id = TicketStatus.StatusStage.INPROGRESS
            ticket.status_updated_at = datetime.now(timezone.utc)
            ticket.save()

            assign_history_entries = []
            assign_history_entries.append(
                TicketAssignedHistory(
                    ticket=ticket,
                    assigned_to_id=user_id,
                    assigned_by_id=user_id,
                    is_reassign=False,
                )
            )

            status_history_entries = []
            status_history_entries.append(
                TicketStatusHistory(
                    ticket=ticket,
                    status_id = TicketStatus.StatusStage.INPROGRESS,
                    created_by_id = user_id,
                    created_at = datetime.now(timezone.utc)
                )
            )

            TicketStatusHistory.objects.bulk_create(status_history_entries)
            TicketAssignedHistory.objects.bulk_create(assign_history_entries)

            if EMAIL_TRIGGER:
                try:
                    result = app.control.broadcast('ping', reply=True, limit=1)
                    if result:
                        ticket_email_data_list = []
                        data = {
                            'type': 'Assign',
                            'ticket_id': ticket.id,
                            'created_by_email': ticket.created_by.email,
                            'created_by_name': f"{ticket.created_by.first_name} {ticket.created_by.last_name}" if ticket.created_by else '',
                            'assigned_by_name': f"{request.user.first_name} {request.user.last_name}",
                            'assigned_to_email': ticket.assigned_by.email if ticket.assigned_by else '',
                            'assigned_to_name': f"{ticket.assigned_by.first_name} {ticket.assigned_by.last_name}" if ticket.assigned_by else '',
                            'category_name': ticket.category.name if ticket.category else '',
                            'title': ticket.title,
                            'department':ticket.department_id,
                            'summary': ticket.summary,
                            'created_date': ticket.created_at,
                            'current_status': ticket.status.name if ticket.status else ''
                        }
                        ticket_email_data_list.append(data)
                        print('------>details sent')
                        send_ticket_assign_mail_v2.delay(ticket_email_data_list)
                    else:
                        print('Celery process not responding')
                except Exception as e:
                    print('Status Updation email error', e)

            return Response({'updated_ticket': 'ticket assigned successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            print('AssignTicket Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class ReAssignTicket(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=ReAssignTicketSerializer)
    def post(self,request):
        try:
            user_id = request.user.id
            user_dept = request.user.dept_id
            # assigned_by = request.data.get('assigned_by')
            assigned_to = request.data.get('assigned_to')
            ticket_ids = request.data.get('ticket_id')
            is_reassign = request.data.get('is_reassign')
            comments = request.data.get('comments')
            user_object = User.objects.filter(id=assigned_to).first()

            if not isinstance(ticket_ids, list):
                ticket_ids = [ticket_ids]
            if is_reassign:
                if ticket_ids == [] or assigned_to is None or comments == "":
                    return Response({'Detail': 'Select the tickets or fill the required fields.'}, status=status.HTTP_400_BAD_REQUEST)

            tickets = list(TicketDetails.objects.select_related('status','created_by','assigned_by').filter(id__in=ticket_ids))

            if any(ticket.status.id in (TicketStatus.StatusStage.RESOLVED, TicketStatus.StatusStage.CLOSED) for ticket in tickets):
                return Response({"Detail": "Could not reassign resolved ticket(s)."}, status=status.HTTP_400_BAD_REQUEST)

            for ticket in tickets:
            #     if ticket.department_id != user_object.dept_id:
            #         return Response({"Detail": "Could not reassign Another Department Staff."}, status=status.HTTP_400_BAD_REQUEST)

                if ticket.created_by_id == user_object.id or ticket.assigned_by_id == user_object.id:
                    return Response({"Detail": "Could not reassign Your Own Ticket, Please select different ticket."}, status=status.HTTP_400_BAD_REQUEST)

                if ticket.status_id == TicketStatus.StatusStage.OPEN:  # For manager assign to Resource
                    is_reassign = False
                    ticket.worked_by_id = assigned_to
                    ticket.assigned_by_id = assigned_to
                    ticket.status_id = TicketStatus.StatusStage.INPROGRESS
                    ticket.status_updated_at = datetime.now(timezone.utc)
                else: # For manager reassign to Resource
                    ticket.is_reassign = ticket.is_reassign + 1
                    ticket.worked_by_id = assigned_to
                    ticket.assigned_by_id = assigned_to
                
            ticket_count = TicketDetails.objects.bulk_update(tickets, ['assigned_by', 'worked_by','is_reassign','status','status_updated_at'])

            history_entries = []
            for ticket in tickets:
                history_entries.append(
                    TicketAssignedHistory(
                        ticket=ticket,
                        assigned_to_id=assigned_to,
                        comments=comments,
                        assigned_by_id=user_id,
                        is_reassign=is_reassign,
                    )
                )

            if not is_reassign:
                status_history_entries = []
                status_history_entries.append(
                    TicketStatusHistory(
                        ticket=ticket,
                        status_id = TicketStatus.StatusStage.INPROGRESS,
                        created_by_id = user_id,
                        created_at = datetime.now(timezone.utc)
                    )
                )
                TicketStatusHistory.objects.bulk_create(status_history_entries)

            TicketAssignedHistory.objects.bulk_create(history_entries)

            if EMAIL_TRIGGER:
                try:
                    result = app.control.broadcast('ping', reply=True, limit=1)
                    if result:
                        ticket_email_data_list = []
                        for ticket in tickets:
                            data = {
                                'type': 'Assign' if not is_reassign else 'Reassign',
                                'ticket_id': ticket.id,
                                'created_by_email': ticket.created_by.email,
                                'created_by_name': f"{ticket.created_by.first_name} {ticket.created_by.last_name}" if ticket.created_by else '',
                                'assigned_by_name': f"{request.user.first_name} {request.user.last_name}",
                                'assigned_to_email': ticket.assigned_by.email if ticket.assigned_by else '',
                                'assigned_to_name': f"{ticket.assigned_by.first_name} {ticket.assigned_by.last_name}" if ticket.assigned_by else '',
                                'category_name': ticket.category.name if ticket.category else '',
                                'title': ticket.title,
                                'department':ticket.department_id,
                                'summary': ticket.summary,
                                'created_date': ticket.created_at,
                                'current_status': ticket.status.name if ticket.status else ''
                            }
                            ticket_email_data_list.append(data)

                        send_ticket_assign_mail_v2.delay(ticket_email_data_list)
                    else:
                        print('Celery process not responding')
                except Exception as e:
                    print('Status Updation email error', e)

            return Response({'updated_tickets': ticket_ids}, status=status.HTTP_200_OK)
        except Exception as e:
            print('AssignTicket Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AddTicketNote(generics.GenericAPIView):
    parser_classes = ([MultiPartParser,])
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=AddTicketNoteSerializer)
    def post(self, request):
        try:
            # user_id = request.user.id
            ticket_id = request.data.get('ticket_id')
            latest_history = TicketDetails.objects.filter(id=ticket_id).first()
            created_by = latest_history.created_by_id
            base_user = request.user.role_id == UserRole.RoleStatus.BASIC

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)
            serializer = AddTicketNoteSerializer(data=request.data, context={'user_id': request.user.id})
            serializer.is_valid(raise_exception=True)
            tic_info = serializer.save()
            return Response(AddTicketNoteDetailsSerializer(tic_info).data, status=status.HTTP_201_CREATED)
        except Exception as e:
            print('TicketUpload Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def get_original_file_name(file_name,file_path):
    """
    To construct the full file path and extract the original file name if marked with '__ORIG__'
    :Parameters
    file_name - name of the file (string)
    file_path - relative path where the file is located (string)
    :Result
    returns a tuple containing the full file path and the original file name
    """
    if file_name != None and file_name != '':
        full_file_path = os.path.join(FILE_PATH,file_path,file_name)
    else:
        full_file_path = ''
        original_file_name = ''
        # raise Exception('file not found!')

    if '__ORIG__' in file_name:
        original_file_name = file_name.split('__ORIG__')[-1]
    else:
        original_file_name = file_name
    # print('fileeee',original_file_name)
    return full_file_path,original_file_name

class UpdatedTicketFileDownload(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self, request):
        try:
            id = request.data['ticket_id']
            latest_history = TicketDetails.objects.filter(id=id).first()
            file_name = latest_history.file_name
            file_path = latest_history.file_path
            created_by = latest_history.created_by_id
            base_user = request.user.role_id == UserRole.RoleStatus.BASIC

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)

            full_file_path,original_file_name = get_original_file_name(file_name,file_path)
            mime_type, _ = mimetypes.guess_type(full_file_path)
            if not mime_type:
                mime_type = "application/octet-stream"

            with open(full_file_path, 'rb') as file:
                response = HttpResponse(file.read(), content_type=mime_type)
                response['Content-Disposition'] = f'attachment; filename="{original_file_name}"'
                return response

        except Exception as e:
            print('DocFileDownload Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UpdatedNotesFileDownload(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self, request):
        try:
            id = request.data['ticket_id']
            latest_history = TicketNotesDetails.objects.select_related('ticket').filter(id=id).first()
            file_name = latest_history.file_name
            file_path = latest_history.file_path
            created_by = latest_history.ticket.created_by_id
            base_user = request.user.role_id == UserRole.RoleStatus.BASIC

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)

            full_file_path,original_file_name = get_original_file_name(file_name,file_path)
            mime_type, _ = mimetypes.guess_type(full_file_path)
            if not mime_type:
                mime_type = "application/octet-stream"

            with open(full_file_path, 'rb') as file:
                response = HttpResponse(file.read(), content_type=mime_type)
                response['Content-Disposition'] = f'attachment; filename="{original_file_name}"'
                return response

        except Exception as e:
            print('DocFileDownload Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

# class UserNotesList(generics.GenericAPIView):
#     permission_classes = []
#     @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
#     def post(self, request):
#         try:
#             user_id = request.user.id
#             ticket_id = request.data.get('ticket_id')
#             base_user = userRole(user_id=user_id)
#             if base_user:
#                 response = TicketNotesDetails.objects.filter(ticket_id=ticket_id, is_private=False).values()
#             else:
#                 response = TicketNotesDetails.objects.filter(ticket_id=ticket_id).values()
#             return Response(response, status=status.HTTP_200_OK)
#         except Exception as e:
#             print('UserNotesList Error: ', str(e))
#             return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UserNotesList(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]

    def is_base_user_object(user):
        return user and not user.is_superuser and not user.is_staff

    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            ticket_id = request.data.get('ticket_id')

            ticket = TicketDetails.objects.select_related('created_by', 'category', 'department').filter(id=ticket_id).first()
            
            created_by = ticket.created_by_id
            base_user = request.user.role_id == UserRole.RoleStatus.BASIC

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)
            if not ticket:
                return Response({'Invalid Data': 'Ticket not found'}, status=status.HTTP_404_NOT_FOUND)

            history = []
            # Ticket creation block
            if ticket.file_name != None:
                _, file_name = get_original_file_name(ticket.file_name, FILE_PATH)
            history.append({
                "type": "create",
                "data": {
                    "id":ticket.id,
                    "ticket_number": f"TCK-{ticket.id}",
                    "title": ticket.title,
                    "summary": ticket.summary,
                    "category": ticket.category.name,
                    "department": ticket.department.name,
                    "is_cycle_restrict":ticket.is_cycle_restrict,
                    "file_name": file_name if ticket.file_name else 'No file attachment',
                    "by": f"{ticket.created_by.first_name} {ticket.created_by.last_name}" if ticket.created_by else "System",
                    "created_at": ticket.created_at
                }
            })

            # Notes/messages block
            # is_base_user = userRole(user_id)
            notes_qs = TicketNotesDetails.objects.select_related('created_by','ticket').filter(ticket_id=ticket_id)
            is_base_user = True if user_id == ticket.created_by_id else False
            if is_base_user:
                notes_qs = notes_qs.filter(is_private=False)

            for n in notes_qs:
                visibility = "Private" if n.is_private else "Public"
                if n.file_name != None:
                    file_name = get_original_file_name(n.file_name, FILE_PATH)[1] if n.file_name else 'No file attachment'
                history.append({
                    "type": "message",
                    "data": {
                        "id":n.id,
                        "user_type": "staff" if n.is_staff else "user",
                        "by": f"{n.created_by.first_name} {n.created_by.last_name}" if n.created_by else "System",
                        "message_type": visibility,
                        "message": n.msg_notes,
                        "file_name": file_name if n.file_name else 'No file attachment',
                        "created_at": n.created_at
                    }
                })

            sorted_history = sorted(history, key=lambda x: x["data"]["created_at"] or timezone.now(), reverse=True)
            return Response(sorted_history, status=status.HTTP_200_OK)

        except Exception as e:
            print('UserNotesList Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)


def userRole(user_id):
    """
    To determine the user's role based on their ID and check if the user is a regular user.
    :Parameters
    user_id - ID of the user (integer)
    :Result
    returns True if the user is a regular user (not a superuser or staff), otherwise returns False
    """
    user_object = User.objects.filter(id=user_id).first()
    if user_object.is_superuser or user_object.is_staff:
        return False
    return True

class UpdateTicketStatus(generics.GenericAPIView): # not used
    permission_classes = [IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=UpdateTicketStatusSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            status_id = request.data.get('status_id')
            ticket_id = request.data.get('ticket_id')
            # comments = request.data.get('comments')

            ticket_object = TicketDetails.objects.select_related('category','status','created_by').filter(id=ticket_id).first()
            current_status = ticket_object.status_id
            reopen = ticket_object.is_reopen
            base_user = userRole(user_id=user_id)

            if base_user: # Base user -> Resolved to Closed / Reopen
                if current_status == TicketStatus.StatusStage.RESOLVED:
                    if status_id == TicketStatus.StatusStage.CLOSED or status_id == TicketStatus.StatusStage.REOPEN:
                        ticket_object.status_id = status_id
                        ticket_object.status_updated_at = datetime.now(timezone.utc)
                        if status_id == TicketStatus.StatusStage.CLOSED:
                            ticket_object.is_active = False
                            ticket_object.closed_by = TicketDetails.ClosedByType.USER
                        if status_id == TicketStatus.StatusStage.REOPEN:
                            ticket_object.is_reopen = reopen + 1
                            # ticket_object.comments = comments
                        ticket_object.save()
                    else:
                        # raise Exception("Base users can only move a Resolved ticket to Closed or Reopen.")
                        return Response({'Invalid Request': "Base users can only move a Resolved ticket to Closed or Reopen."}, status=status.HTTP_400_BAD_REQUEST)
                    
                else:
                    # raise Exception("Base users are not allowed to change ticket status from the current state.")
                    return Response({'Invalid Request': "Base users are not allowed to change ticket status from the current state."}, status=status.HTTP_400_BAD_REQUEST)

            else: # Admin user -> open to Inprogress / Onhold / Resolved
                allowed_transitions = {
                        TicketStatus.StatusStage.OPEN:
                        [
                            TicketStatus.StatusStage.INPROGRESS,
                        ],
                    TicketStatus.StatusStage.INPROGRESS:
                        [
                            TicketStatus.StatusStage.ONHOLD,
                            TicketStatus.StatusStage.RESOLVED,
                        ],
                    TicketStatus.StatusStage.ONHOLD:
                        [
                            TicketStatus.StatusStage.INPROGRESS,
                            TicketStatus.StatusStage.RESOLVED,
                        ],
                }

                if status_id in allowed_transitions.get(current_status, []):
                    if status_id == TicketStatus.StatusStage.RESOLVED:
                        history = TicketStatusHistory.objects.filter(
                            ticket_id=ticket_id
                        ).order_by('created_at')

                        total_inprogress_seconds = 0
                        inprogress_start_time = None

                        for entry in history:
                            if entry.status_id == TicketStatus.StatusStage.INPROGRESS:
                                inprogress_start_time = entry.created_at

                            elif inprogress_start_time and entry.status_id != TicketStatus.StatusStage.INPROGRESS:
                                time_diff = entry.created_at - inprogress_start_time
                                total_inprogress_seconds += time_diff.total_seconds()
                                inprogress_start_time = None

                            if entry.status_id == TicketStatus.StatusStage.RESOLVED:
                                if inprogress_start_time:
                                    time_diff = entry.created_at - inprogress_start_time
                                    total_inprogress_seconds += time_diff.total_seconds()
                                break

                        ticket_object.resolved_hours = round(total_inprogress_seconds / 3600, 2) if total_inprogress_seconds else None
                    ticket_object.status_id = status_id
                    ticket_object.status_updated_at = datetime.now(timezone.utc)
                    ticket_object.save()

                else:
                    # raise Exception(
                    #     f"Invalid status transition from {TicketStatus.StatusStage(current_status).name} to {TicketStatus.StatusStage(status_id).name} for staff."
                    # )
                    return Response({'Invalid Data': f"Invalid status transition from {TicketStatus.StatusStage(current_status).name} to {TicketStatus.StatusStage(status_id).name} for staff."}, status=status.HTTP_400_BAD_REQUEST)

            ticket_history = TicketStatusHistory(
                ticket_id=ticket_object.id,
                status=ticket_object.status,
                created_by_id=user_id
            )
            ticket_history.save()

            if EMAIL_TRIGGER and ticket_object.status.id != TicketStatus.StatusStage.CLOSED:
                    try:
                        result = app.control.broadcast('ping', reply=True, limit=1)
                        if result:
                            trans_data = {}
                            trans_data['type'] = "Status"
                            trans_data['ticket_id'] = ticket_object.id
                            trans_data['category_name'] = ticket_object.category.name
                            trans_data['title'] = ticket_object.title
                            trans_data['summary'] = ticket_object.summary
                            trans_data['current_status'] = ticket_object.status.name
                            trans_data['user_mail'] = ticket_object.created_by.email
                            trans_data['user_name'] = f"{ticket_object.created_by.first_name} {ticket_object.created_by.last_name}"
                            if ticket_object.status.id == TicketStatus.StatusStage.REOPEN:
                                trans_data['type'] = "Reopen"
                                trans_data['comments'] = ticket_object.comments
                                trans_data['user_mail'] = ticket_object.worked_by.email
                            send_newticket_email.delay(trans_data)
                        else:
                            print('Celery process not responding')
                    except Exception as e:
                        print('Status Updation email error',e)

            return Response("Status updated successfully", status=status.HTTP_200_OK)
        except Exception as e:
            print('UpdateTicketStatus Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class UserEscalateTicket(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UserEscalateTicketSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            ticket_id = request.data.get('ticket_id')
            comments = request.data.get('comments')

            ticket_object = TicketDetails.objects.select_related('category','status','assigned_by','created_by').filter(id=ticket_id).first()
            if ticket_object.created_by_id != user_id:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_400_BAD_REQUEST)

            if not ticket_object.status.is_escalate:
                return Response({'Detail': 'This status of the ticket does not allow escalation.'}, status=status.HTTP_400_BAD_REQUEST)

            if ticket_object.is_escalate:
                return Response({'Detail': 'Ticket is already escalated.'}, status=status.HTTP_400_BAD_REQUEST)
            
            if not comments:
                return Response({'Detail': 'Please fill the Comments field'}, status=status.HTTP_400_BAD_REQUEST)

            ticket_object.is_escalate = True
            ticket_object.escalation_count = ticket_object.escalation_count + 1
            ticket_object.esc_updated_at = datetime.now(timezone.utc)
            ticket_object.save()

            esc_hist = TicketEscalationHistory(
                ticket = ticket_object,
                comments = comments,
                trigger_type = TicketEscalationHistory.EscTriggerType.USER,
                created_by_id = user_id
            )
            esc_hist.save()

            if EMAIL_TRIGGER:
                try:
                    result = app.control.broadcast('ping', reply=True, limit=1)
                    if result:
                        trans_data = {}
                        trans_data['type'] = "Escalate"
                        trans_data['ticket_id'] = ticket_object.id
                        trans_data['category_name'] = ticket_object.category.name
                        trans_data['title'] = ticket_object.title
                        trans_data['department'] = ticket_object.department_id
                        trans_data['summary'] = ticket_object.summary
                        trans_data['created_date'] = ticket_object.created_at
                        trans_data['current_status'] = ticket_object.status.name
                        trans_data['current_status_id'] = ticket_object.status_id
                        trans_data['user_mail'] = ticket_object.assigned_by.email if ticket_object.assigned_by else ''
                        trans_data['user_name'] = f"{ticket_object.created_by.first_name} {ticket_object.created_by.last_name}"
                        trans_data['comment_for'] = f"{ticket_object.assigned_by.first_name} {ticket_object.assigned_by.last_name}" if ticket_object.assigned_by else ''
                        send_newticket_email.delay(trans_data)
                    else:
                        print('Celery process not responding')
                except Exception as e:
                    print('Status Updation email error',e)

            return Response({'Ticket Escalated Successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserEscalateTicket Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

@swagger_auto_schema(methods=['GET'])
@api_view(['GET'])
def bak_db(request):
    # send_alloc_email.delay(validated_data)
    try:
        result = app.control.broadcast('ping', reply=True, limit=1, timeout=2.5)
        if result:
            backup_dbs = daily_ts_production_report.delay("req")
        else:
            print('Celery process not responding')
        # holidays = set(HolidayList.objects.filter(status=True).values_list('holiday_date', flat=True))
        # sel = close_tickets(holidays)
        # esc = escalate_tickets(holidays)
        # return Response(sel,esc)
    except Exception as e:
        print('Allocation email error',e)
    return Response("success")

class ChangeTicketReadStatus(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self,request):
        try:
            user_id = request.user.id
            ticket_id = request.data.get('ticket_id')
            ticket_object = TicketDetails.objects.select_related('created_by','worked_by').filter(id=ticket_id).first()
            # base_user = userRole(user_id=user_id)
            base_user = request.user.role_id == UserRole.RoleStatus.BASIC
            created_by = ticket_object.created_by_id

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)

            res = {'No need to update status'}
            if user_id == ticket_object.created_by_id and ticket_object.sender_notes is True:
                ticket_object.sender_notes = False
                ticket_object.save()
                res = {'Status updated successfully'}
            if user_id == ticket_object.worked_by_id and ticket_object.receiver_notes is True:
                ticket_object.receiver_notes = False
                ticket_object.save()
                res = {'Status updated successfully'}

            return Response(res, status=status.HTTP_200_OK)
        except Exception as e:
            print('ChangeTicketReadStatus Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class StaffProductionReport(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=StaffProductionReportSerializer)
    def post(self, request):
        try:
            if request.data['range_key'] == 'daily':
                report_data = self.daily_report(request.data,request)
            if request.data['range_key'] == 'monthly':
                report_data = self.monthly_report(request.data,request)
            if request.data['range_key'] == 'yearly':
                report_data = self.yearly_report(request.data,request)
            if request.data['range_key'] == 'quartely':
                report_data = self.quarterly_report(request.data,request)
            return Response(report_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('CompletedTicketReport Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

    def get_valid_working_dates(self,start_date, end_date):
        holiday_dates = HolidayList.objects.filter(
            holiday_date__range=[start_date, end_date]
        ).values_list('holiday_date', flat=True)

        holidays = set(date.strftime('%Y-%m-%d') for date in holiday_dates)
        valid_dates = []
        current_date = start_date
        while current_date <= end_date:
            date_str = current_date.strftime('%Y-%m-%d')
            if current_date.weekday() not in [5, 6] and date_str not in holidays:
                valid_dates.append(date_str)
            current_date += timedelta(days=1)

        return valid_dates

    def get_valid_working_months(self, start_date, end_date):
        months = set()
        current = start_date.replace(day=1)
        while current <= end_date:
            months.add(current.strftime('%Y-%m-01'))
            # Move to the next month
            if current.month == 12:
                current = current.replace(year=current.year + 1, month=1)
            else:
                current = current.replace(month=current.month + 1)
        return sorted(list(months))

    def format_final_data(self, tickets, valid_dates, functiontype):
        grouped = {}
        for ticket in tickets:
            if functiontype == 'month':
                report_date_str = ticket['report_month'].strftime('%Y-%m-01')
                date_key = 'month'
            elif functiontype == 'year':
                report_date_str = ticket['report_year'].strftime('%Y-01-01')
                date_key = 'year'
            else:
                report_date_str = ticket['report_date'].strftime('%Y-%m-%d')
                date_key = 'date'

            if report_date_str not in valid_dates:
                continue

            uid = ticket['assigned_by']
            if uid not in grouped:
                grouped[uid] = {
                    'assigned_by': uid,
                    'user_name': ticket['user_name'],
                    'data': {}
                }
            grouped[uid]['data'][report_date_str] = ticket['tot_tickets']

        result = []
        for user_id, user_info in grouped.items():
            user_data = []
            for date in valid_dates:
                user_data.append({
                    date_key: date,
                    'tot_prod': user_info['data'].get(date, None)
                })

            result.append({
                'assigned_by': user_id,
                'user_name': user_info['user_name'],
                'data': user_data
            })

        return result

    def get_quarterly_list(self, start_date, end_date):
        quarters = []
        current = start_date
        while current <= end_date:
            year = current.year
            quarter = (current.month - 1) // 3 + 1
            q_str = f"{year}' Q{quarter}"
            if q_str not in quarters:
                quarters.append(q_str)
            if current.month > 9:
                current = datetime(year + 1, 1, 1).date()
            else:
                next_month = ((quarter * 3) % 12) + 1
                next_year = year if next_month > 1 else year + 1
                current = datetime(next_year, next_month, 1).date()
        return quarters

    def ticket_quarterly_data(self, tickets, quarterly_list):
        task_data_dict = {}

        for t in tickets:
            month = t['month']
            year = t['year']
            assigned_by = t['assigned_by']
            user_name = t['username']
            tot_prod = t['tot_prod']

            if month in [1, 2, 3]:
                quarter = 'Q1'
            elif month in [4, 5, 6]:
                quarter = 'Q2'
            elif month in [7, 8, 9]:
                quarter = 'Q3'
            else:
                quarter = 'Q4'

            quarter_key = f"{year}' {quarter}"
            data_key = (assigned_by, quarter_key)

            if data_key in task_data_dict:
                task_data_dict[data_key]['tot_prod'] += tot_prod
            else:
                task_data_dict[data_key] = {
                    'quarterly_date': quarter_key,
                    'quarterly': quarter,
                    'year': year,
                    'assigned_by': assigned_by,
                    'user_name': user_name,
                    'tot_prod': tot_prod
                }

        task_data_flat = list(task_data_dict.values())
        # print('task_data_flat',task_data_flat)
        return self.ticket_quarterly_format(task_data_flat, quarterly_list)

    def ticket_quarterly_format(self, task_data, quarterly_list):
        grouped = {}

        for task in task_data:
            tid = task['assigned_by']
            if tid not in grouped:
                grouped[tid] = {
                    'assigned_by': tid,
                    'user_name': task['user_name'],
                    'data': []
                }
            grouped[tid]['data'].append({
                'quarterly_date': task['quarterly_date'],
                'quarterly': task['quarterly'],
                'year': task['year'],
                'tot_prod': task['tot_prod']
            })
        # print('grouped_data',grouped)
        for tid in grouped:
            grouped[tid]['data'] = self.fill_quarter_empty(grouped[tid]['data'], quarterly_list)

        return list(grouped.values())

    def fill_quarter_empty(self, quarter_data, quarter_list):
        out = {}
        for q in quarter_data:
            out[q['quarterly_date']] = q

        for q_str in quarter_list:
            if q_str not in out:
                year, quarter = q_str.split("'")
                out[q_str] = {
                    'quarterly_date': q_str,
                    'quarterly': quarter.strip(),
                    'year': int(year),
                    'tot_prod': None
                }
        # print('out',out)
        return [out[k] for k in sorted(out)]

    def monthly_report(self, request,user):
        date_range = request['date_range']
        start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
        end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date()
        valid_months = self.get_valid_working_months(start_date, end_date)
        user_ids = User.objects.filter(is_staff=True).values_list('id', flat=True)
        # is_admin = True if user.user.role_id == UserRole.RoleStatus.ADMIN else False

        # if is_admin:
        #     department_id = user.data.get('department_id')
        # else:
        #     department_id = user.user.dept_id

        filters = {
            'status_id__in': [TicketStatus.StatusStage.RESOLVED,TicketStatus.StatusStage.CLOSED],
            'status_updated_at__range': [date_range['start_time'], date_range['end_time']],
            'assigned_by_id__in': user_ids,
            # 'department_id__in': department_id
        }

        if request['category_id'] != []:
            filters['category_id__in'] = request['category_id']

        if request['staff_id'] != []:
            filters['assigned_by_id__in'] = request['staff_id']

        # if request['department_id'] != []:
        #     filters['department_id__in'] = department_id

        # if not is_admin:
        #     filters['department_id'] = department_id

        tot_user_data = TicketDetails.objects.annotate(report_month=TruncMonth('status_updated_at')) \
            .filter(**filters) .values('assigned_by', 'report_month') \
            .annotate(
                tot_tickets=Count('id'),
                user_name=Concat(
                        F("assigned_by__first_name"), Value(" "), F("assigned_by__last_name")
                    )
            ).order_by('assigned_by', 'report_month')
        # print('tot_user_date',list(tot_user_data))

        tot_per_month_data = (
            TicketDetails.objects.annotate(start_month=TruncMonth('status_updated_at')).filter(**filters)\
            .values('start_month').annotate(tot_prod=Count('id')).order_by('start_month')
        )
        # print('tot_per_month_data',list(tot_per_month_data))

        final_json = self.format_final_data(list(tot_user_data), valid_months,functiontype='month')
        out_data = {
            'prs_task_data': final_json,
            'prs_task_tot_data': tot_per_month_data
        }

        return out_data

    def daily_report(self, request,user):
        date_range = request['date_range']
        start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
        end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
        valid_dates = self.get_valid_working_dates(start_date, end_date)
        user_ids = User.objects.filter(is_staff=True).values_list('id', flat=True)
        # is_admin = True if user.user.role_id == UserRole.RoleStatus.ADMIN else False

        # if is_admin:
        #     department_id = user.data.get('department_id')
        # else:
        #     department_id = user.user.dept_id

        filters = {
            'status_id__in': [TicketStatus.StatusStage.RESOLVED,TicketStatus.StatusStage.CLOSED],
            'status_updated_at__range': [start_date, end_date],
            'assigned_by_id__in': user_ids,
            # 'department_id__in':department_id
        }

        if request['category_id'] != []:
            filters['category_id__in'] = request['category_id']

        if request['staff_id'] != []:
            filters['assigned_by_id__in'] = request['staff_id']

        # if request['department_id'] != []:
        #     filters['department_id__in'] = department_id

        # if not is_admin:
        #     filters['department_id'] = department_id

        tot_user_data = TicketDetails.objects.annotate(report_date=TruncDate('status_updated_at')) \
        .filter(**filters).values('assigned_by', 'report_date') \
        .annotate(
            tot_tickets=Count('id'),
            user_name=Concat(
                        F("assigned_by__first_name"), Value(" "), F("assigned_by__last_name")
                    )
        ).order_by('assigned_by', 'report_date')
        # print('tot_user_data',list(tot_user_data))

        tot_per_day_data = (
        TicketDetails.objects.annotate(start_date=TruncDate('status_updated_at')).filter(**filters)\
        .values('start_date').annotate(tot_prod=Count('id')).order_by('start_date')
        )
        # print('tot_per_day_data',list(tot_per_day_data))

        final_json = self.format_final_data(list(tot_user_data), valid_dates, functiontype=None)
        out_data = {}
        out_data['prs_task_data'] = final_json
        out_data['prs_task_tot_data'] = tot_per_day_data

        return out_data

    def yearly_report(self, request,user):
        date_range = request['date_range']
        start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
        end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date()
        user_ids = User.objects.filter(is_staff=True).values_list('id', flat=True)
        years = [f"{year}-01-01" for year in range(start_date.year, end_date.year + 1)]
        # is_admin = True if user.user.role_id == UserRole.RoleStatus.ADMIN else False

        # if is_admin:
        #     department_id = user.data.get('department_id')
        # else:
        #     department_id = user.user.dept_id

        filters = {
            'status_id__in': [TicketStatus.StatusStage.RESOLVED,TicketStatus.StatusStage.CLOSED],
            'status_updated_at__range': [date_range['start_time'], date_range['end_time']],
            'assigned_by_id__in': user_ids,
            # 'department_id__in': department_id
        }

        if request['category_id'] != []:
            filters['category_id__in'] = request['category_id']

        if request['staff_id'] != []:
            filters['assigned_by_id__in'] = request['staff_id']

        # if request['department_id'] != []:
        #     filters['department_id__in'] = department_id

        # if not is_admin:
        #     filters['department_id'] = department_id

        tickets = TicketDetails.objects.annotate(report_year=TruncYear('status_updated_at'))\
            .filter(**filters).values('assigned_by', 'report_year')\
            .annotate(
                tot_tickets=Count('id'),
                user_name=Concat(
                        F("assigned_by__first_name"), Value(" "), F("assigned_by__last_name")
                    )
            ).order_by('assigned_by', 'report_year')
        # print('tickets',list(tickets))

        tot_yearly_data = TicketDetails.objects.annotate(report_year=TruncYear('status_updated_at'))\
            .filter(**filters).values('report_year').annotate(tot_prod=Count('id')).order_by('report_year')
        # print('tot_yearly_data',list(tot_yearly_data))

        final_json = self.format_final_data(list(tickets), years, functiontype='year')
        out_data = {}
        out_data['prs_task_data'] = final_json
        out_data['prs_task_tot_data'] = tot_yearly_data

        return out_data

    def quarterly_report(self, request,user):
        date_range = request['date_range']
        try:
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date()
        except ValueError as e:
            return {"error": f"Invalid date format or value: {str(e)}"}
        user_ids = User.objects.filter(is_staff=True).values_list('id', flat=True)
        q_list = self.get_quarterly_list(start_date, end_date)
        # is_admin = True if user.user.role_id == UserRole.RoleStatus.ADMIN else False

        # if is_admin:
        #     department_id = user.data.get('department_id')
        # else:
        #     department_id = user.user.dept_id

        filters = {
            'status_id__in': [TicketStatus.StatusStage.RESOLVED,TicketStatus.StatusStage.CLOSED],
            'status_updated_at__range': [start_date, end_date],
            'assigned_by_id__in': user_ids,
            # 'department_id__in': department_id
        }

        if request['category_id'] != []:
            filters['category_id__in'] = request['category_id']
        if request['staff_id'] != []:
            filters['assigned_by_id__in'] = request['staff_id']
        # if request['department_id'] != []:
        #     filters['department_id__in'] = department_id

        # if not is_admin:
        #     filters['department_id'] = department_id

        tickets = TicketDetails.objects.filter(**filters).annotate(
            month=ExtractMonth('status_updated_at'),
            year=ExtractYear('status_updated_at'),
            username = Concat(
                        F("assigned_by__first_name"), Value(" "), F("assigned_by__last_name")
                    )
        ).values('assigned_by', 'username', 'month', 'year') \
        .annotate(tot_prod=Count('id')).order_by('year', 'month', 'assigned_by')
        # print('tickets',tickets)

        task_data = self.ticket_quarterly_data(tickets, q_list)

        return {
            'prs_task_data': task_data,
            'prs_task_tot_data': []
        }

class StaffProductionReportExport(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager]
    def create_row(self, row_num, col_num, row_title, worksheet, is_row, is_ind, col_width, format_flag=False):
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        #create columns header
        cell = worksheet.cell(row=row_num, column=col_num)
        cell.value = row_title
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell.font = Font(bold=True, size = "10")
        cell.border = thin_border
        cell.fill = PatternFill(start_color="8ea9db", fill_type = "solid")
        if format_flag:
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        column = str(chr(64 + col_num))
        worksheet.column_dimensions[column].width = col_width
        if not is_ind:
            if is_row:
                worksheet.merge_cells(start_row=row_num, start_column=col_num, end_row=row_num, end_column=col_num)
            else:
                worksheet.merge_cells(start_row=row_num, start_column=col_num, end_row=row_num, end_column=col_num+1)

    def client_task_export(self, export_data, request,title):
        try:
            # print(export_data, 'export_data')
            workbook = Workbook()
            workbook.remove(workbook.active)
            date_range = request['date_range']
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d')
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d')
            worksheet = workbook.create_sheet(title='Production Report', index=1)
            row_num = 1
            # Column headers
            header_list = ['SNo.', 'Staff name', 'Total Production']
            scope_list = []
            if request["range_key"] == "yearly":
                for data in export_data['prs_task_tot_data']:
                    scope_list.append(data['report_year'].strftime('%Y'))
            elif request['range_key'] == 'quartely':
                for data in export_data['prs_task_data'][0]['data']:
                    scope_list.append(str(data['quarterly_date']))
            elif request["range_key"] == "monthly":
                for data in export_data['prs_task_tot_data']:
                    scope_list.append(data['start_month'].strftime('%b %y'))
            else:
                for data in export_data['prs_task_tot_data']:
                    scope_list.append(data['start_date'].strftime('%b %d'))
            row_num = 1
            cell = worksheet.cell(row=row_num, column=2)
            cell.value = 'SE Tracker:'+ title + ' Staff Production Reports from - ' + start_date.strftime('%m-%d-%Y') + '- to -' + end_date.strftime('%m-%d-%Y')
            cell.font = Font(bold=True)
            row_num = row_num + 1
            col = 1
            header_list.extend(scope_list)
            for header_val in header_list:
                if col == 2:
                    self.create_row(row_num, col, header_val, worksheet, True, False, 30)
                    col += 1
                elif col in [1]:
                    self.create_row(row_num, col, header_val, worksheet, True, False, 8, True)
                    col += 1
                else:
                    self.create_row(row_num, col, header_val, worksheet, True, False, 13, True)
                    col += 1

            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                top=Side(style='thin'), bottom=Side(style='thin'))
            slno = 1
            for data, tot in zip(export_data['prs_task_data'], export_data['grand_tot_task']):
                row_num += 1
                row = []
                row.append(slno)
                row.append(data['user_name']) if data['user_name'] else row.append('')
                row.append(tot[data['user_name']]) if tot[data['user_name']] else row.append('')
                for date_str in scope_list:
                    is_found = False
                    for dat in data['data']:
                        if request["range_key"] == "yearly":
                            dat_date = datetime.strptime(dat['year'], '%Y-%m-%d').date()
                            if dat_date == datetime.strptime(date_str, '%Y').date():
                                row.append(dat['tot_prod']) if dat['tot_prod'] != None else row.append('')
                                is_found =True
                                break
                        elif request['range_key'] == 'quartely':
                            # dat_date = datetime.strptime(dat['quarterly_date'], '%Y-%m-%d').date()
                            if dat['quarterly_date'] == date_str:
                                row.append(dat['tot_prod']) if dat['tot_prod'] != None else row.append('')
                                is_found =True
                                break
                        elif request['range_key'] == 'monthly':
                            dat_date = datetime.strptime(dat['month'], '%Y-%m-%d').date()
                            if dat_date.strftime('%b %y') == date_str:
                                row.append(dat['tot_prod']) if dat['tot_prod'] != None else row.append('')
                                is_found =True
                                break
                        else:
                            dat_date = datetime.strptime(dat['date'], '%Y-%m-%d').date()
                            if dat_date == datetime.strptime(date_str, '%b %d').date().replace(year=dat_date.year):
                                row.append(dat['tot_prod']) if dat['tot_prod'] != None else row.append('')
                                is_found =True
                                break
                    if not is_found:
                        row.append('')
                for col_num, cell_value in enumerate(row, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    cell.border = thin_border
                    cell.font = Font(size="10")
                    if col_num > 2:
                        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                    if col_num > 0 :
                        column = str(chr(64 + col_num))
                        worksheet.column_dimensions[column].width = 23
                slno+=1
            col_no=1
            row_num+=1
            self.create_row(row_num, col_no, 'Grand Total', worksheet, False, False, 13)
            col_no+=2
            if request['range_key'] != 'quartely':
                sum_tot_prod = sum(item['tot_prod'] for item in export_data['prs_task_tot_data'])
                self.create_row(row_num, col_no, sum_tot_prod, worksheet, True, False, 13, True)
            else:
                sum_tot_prod = sum(item[key] for item in export_data['grand_tot_task'] for key in item)
                self.create_row(row_num, col_no, sum_tot_prod, worksheet, True, False, 13, True)
            col_no+=1
            if request['range_key'] != 'quartely':
                for dat in export_data['prs_task_tot_data']:
                    self.create_row(row_num, col_no, dat['tot_prod'], worksheet, True, False, 13, True)
                    col_no +=1
            else:
                tot_prod_sums = {}
                for dat in export_data['prs_task_data']:
                    for item in dat['data']:
                        quarterly_date = item['quarterly_date']
                        tot_prod = item['tot_prod']
                        if quarterly_date in tot_prod_sums:
                            if tot_prod != None and tot_prod_sums[quarterly_date] != None :
                                tot_prod_sums[quarterly_date] += tot_prod
                            elif tot_prod != None and tot_prod_sums[quarterly_date] == None :
                                tot_prod_sums[quarterly_date] = 0
                                tot_prod_sums[quarterly_date] += tot_prod
                        else:
                            tot_prod_sums[quarterly_date] = tot_prod
                for key, val in tot_prod_sums.items():
                    self.create_row(row_num, col_no, val, worksheet, True, False, 13, True)
                    col_no+=1
            client_name = self.get_client_name(request)
            f_name = 'ByProcess'
            if client_name:
                range_key, date_val = self.file_name(request['range_key'], start_date)
                file_name = f"StaffProductionReport_{f_name}_{range_key}_from_{start_date.strftime('%m-%d-%Y')}_to_{end_date.strftime('%m-%d-%Y')}"
            else:
                file_name = f"StaffProductionReport_{f_name}_{start_date.strftime('%m-%d-%Y')}_to_{end_date.strftime('%m-%d-%Y')}"
            # print("file_name: ", file_name)
            response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename={0}.xlsx'.format(file_name)
            response['Access-Control-Expose-Headers'] = "Content-Disposition"
            workbook.save(response)
            return response
        except Exception as e:
            print('client_task_excel_export error: ', str(e))
            raise Exception(str(e))

    def get_client_name(self, request):
        grp_name = None
        if request['category_id']==0:
            grp_name = 'AllClient'
        elif request['category_id'] == 1:
            grp_name = CategoryDetails.objects.filter(id=request['category_id']).values('name')
            grp_name = grp_name[0]['name']
        return grp_name

    def file_name(self, range_key, req_date):
        if range_key == 1 or range_key == 'daily':
            range_key_val = 'Daily'
            file_date = req_date.strftime('%m%d%Y')
        elif range_key == 2 or range_key == 'monthly':
            range_key_val = 'Monthly'
            file_date = req_date.strftime('%b%Y')
        elif range_key == 3 or range_key == 'quartely':
            range_key_val = 'Quarterly'
            file_date = req_date.strftime('%b%Y')
        elif range_key == 4 or range_key == 'yearly':
            range_key_val = 'Yearly'
            file_date = req_date.strftime('%Y')
        return range_key_val, file_date

    @swagger_auto_schema(request_body=StaffProductionReportSerializer)
    def post(self,request):
        try:
            if request.data['range_key'] == 'daily':
                report_data = StaffProductionReport().daily_report(request.data,request)
                title = 'Daily'
            elif request.data['range_key'] == 'monthly':
                report_data = StaffProductionReport().monthly_report(request.data,request)
                title = 'Monthly'
            elif request.data['range_key'] == 'quartely':
                report_data = StaffProductionReport().quarterly_report(request.data,request)
                title = 'Quartely'
            elif request.data['range_key'] == 'yearly':
                report_data = StaffProductionReport().yearly_report(request.data,request)
                title = 'Yearly'
            grand_tot_task = []
            for dat in report_data['prs_task_data']:
                grd_tot_prs_task = {}
                sum_prod = sum(item['tot_prod'] for item in dat['data'] if item['tot_prod'] != None)
                grd_tot_prs_task[dat['user_name']] = sum_prod
                grand_tot_task.append(grd_tot_prs_task)
            report_data['grand_tot_task'] = grand_tot_task
            # print('report',report_data)
            data = self.client_task_export(report_data, request.data,title=title)
            return data
        except Exception as e:
            print('ClientTaskReportExport Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TicketHistoryDetails(generics.GenericAPIView):
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self, request):
        try:
            user_id = request.user.id
            ticket_id = request.data.get('ticket_id')
            ticket = TicketDetails.objects.select_related('created_by').filter(id=ticket_id).first()
 
            if not ticket:
                return Response({'Invalid Data': 'Ticket not found'}, status=status.HTTP_404_NOT_FOUND)

            base_user = request.user.role_id == UserRole.RoleStatus.BASIC
            created_by = ticket.created_by_id

            if base_user and request.user.id != created_by:
                return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_401_UNAUTHORIZED)

            history = []

            # 1. Ticket Creation
            if ticket.file_name != None:
                _, file_name = get_original_file_name(ticket.file_name, FILE_PATH)
            history.append({
                "type": "create",
                "data": {
                    "id":ticket.id,
                    "ticket_number": f"TCK-{ticket.id}",
                    "title": ticket.title,
                    "summary": ticket.summary,
                    "category": ticket.category.name,
                    "department": ticket.department.name,
                    "file_name": file_name if ticket.file_name else 'No file attachment',
                    "by": f"{ticket.created_by.first_name} {ticket.created_by.last_name}" if ticket.created_by else "System",
                    "created_at": ticket.created_at
                }
            })

            # 2. Assignment/Reassignment
            assigns = TicketAssignedHistory.objects.select_related('assigned_by', 'assigned_to').filter(ticket=ticket)
            for a in assigns:
                action = "Reassigned" if a.is_reassign else "Assigned"
                history.append({
                    "type": "assignment",
                    "data": {
                        "by": f"{a.assigned_by.first_name} {a.assigned_by.last_name}" if a.assigned_by else "System",
                        "assign_type": action,
                        "description":f"{action} Ticket",
                        "file_name": 'No file attachment',
                        "message": f"Assigned to {a.assigned_to.first_name} {a.assigned_to.last_name}" if a.assigned_to else 'Unknown',
                        "created_at": a.created_at
                    }
                })

            # 3. Status Changes
            statuses = TicketStatusHistory.objects.select_related('status', 'created_by').filter(ticket=ticket)
            for s in statuses:
                history.append({
                    "type": "status_update",
                    "data": {
                        "by": f"{s.created_by.first_name} {s.created_by.last_name}" if s.created_by else "System",
                        "message": f"Status changed to {s.status.name if s.status else 'Unknown'}",
                        "file_name": 'No file attachment',
                        "description":f"{s.status.name if s.status else 'Unknown'}",
                        "created_at": s.created_at
                    }
                })

            # 4. Notes/messages
            notes = TicketNotesDetails.objects.select_related('created_by').filter(ticket=ticket)
            is_base_user = True if user_id == ticket.created_by_id else False
            if is_base_user:
                notes = notes.filter(is_private=False)
            for n in notes:
                visibility = "Private" if n.is_private else "Public"
                if n.file_name != None:
                    file_name = get_original_file_name(n.file_name, FILE_PATH)[1] if n.file_name else 'No file attachment'
                history.append({
                    "type": "message",
                    "data": {
                        "id":n.id,
                        "user_type": "staff" if n.is_staff else "user",
                        "by": f"{n.created_by.first_name} {n.created_by.last_name}" if n.created_by else "System",
                        "message_type":visibility,
                        "description":f"{visibility} message",
                        "message": n.msg_notes,
                        "file_name": file_name  if n.file_name else 'No file attachment',
                        "created_at": n.created_at
                    }
                })

            # 5. Escalations
            escalations = TicketEscalationHistory.objects.select_related('created_by').filter(ticket=ticket)
            for e in escalations:
                trig = "Automated" if e.trigger_type == TicketEscalationHistory.EscTriggerType.AUTOMATE else "User"
                message = (
                    e.comments
                    if trig == "User"
                    else "Timebound escalation due to lack of progress."
                )
                history.append({
                    "type": "escalation",
                    "data": {
                        "type":trig,
                        "description":f"{trig} escalation",
                        "file_name": 'No file attachment',
                        "by": f"{e.created_by.first_name} {e.created_by.last_name}" if e.created_by else trig,
                        "message": message,
                        "created_at": e.created_at
                    }
                })

            # Sort all by created_at
            sorted_history = sorted(history, key=lambda x: x["data"]["created_at"] or timezone.now(), reverse=True)

            return Response(sorted_history, status=status.HTTP_200_OK)

        except Exception as e:
            print('TicketHistoryDetails Error:', str(e))
            return Response({'Invalid Data': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AllTicketListExcelExp(generics.GenericAPIView):
    def create_excel(self, ipa_info, req_data,title):
        workbook = Workbook()
        workbook.remove(workbook.active)
        worksheet = workbook.create_sheet(title='Reports', index=1)
        row_num = 1
        cell = worksheet.cell(row=row_num, column=2)
        date_range = req_data.get('date_range')
        start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
        end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date()
        if isinstance(start_date, str):
            start_date = datetime.strptime(start_date, "%Y-%m-%d")
        if isinstance(end_date, str):
            end_date = datetime.strptime(end_date, "%Y-%m-%d")
        cell.value = 'SE Tracker:'+ title +' Reports from - ' + start_date.strftime("%m/%d/%Y") + ' to ' + end_date.strftime("%m/%d/%Y")
        cell.font = Font(bold=True)
        row_num += 1

        columns = ["SNo.","Created By Name","Created At","Ticket Number", "Title", "Summary", "File Name", "Is Escalated",
                "Status Name", "Category Name","Subcategory Name", "Department Name",
                "Tagged Staff Name"]

        column_width = []
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        slno = 1
        for col_num, column_title in enumerate(columns, 1):
            cell = worksheet.cell(row=row_num, column=col_num)
            cell.value = column_title
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.font = Font(bold=True, size=10)
            cell.border = thin_border
            cell.fill = PatternFill(start_color="8ea9db", fill_type="solid")
            column_width.append(len(str(column_title)) * 1.32)

        for ipa in ipa_info.iterator():
            row_num += 1
            # stored_file_name = ipa['file_name']
            # default_file_path = FILE_PATH
            # try:
            #     _, original_file_name = get_original_file_name(stored_file_name, default_file_path)
            # except Exception:
            #     original_file_name = stored_file_name  # Fallback if something goes wrong
            row = [slno,ipa['created_by_name'],ipa['created_at'].strftime("%m/%d/%Y %I:%M %p") if ipa['created_at'] else '',
                ipa['ticket_number'], ipa['title'], ipa['summary'], ipa['org_file_name'],
                "Yes" if ipa['is_escalate'] else "No", ipa['status_name'],
                ipa['category_name'],ipa['sub_category_name'],ipa['department_name'],ipa['tag_staff_name'],
            ]

            for col_num, cell_value in enumerate(row, 1):
                cell = worksheet.cell(row=row_num, column=col_num)
                cell.value = cell_value
                cell.border = thin_border
                cell.font = Font(size=10)
                if column_width[col_num - 1] < len(str(cell_value)):
                    column_width[col_num - 1] = len(str(cell_value))
            slno+=1

        dim_holder = DimensionHolder(worksheet=worksheet)
        for col in range(worksheet.min_column, worksheet.max_column + 1):
            dim_holder[get_column_letter(col)] = ColumnDimension(worksheet, min=col, max=col, width=column_width[col - 1])
        worksheet.column_dimensions = dim_holder

        date_format = date.today().strftime("%m%d%y")
        file_name = 'SE Tracker_' + "_" + date_format
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = f'attachment; filename={file_name}.xlsx'
        response['Access-Control-Expose-Headers'] = "Content-Disposition"
        workbook.save(response)
        return response

    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AllTicketListSerializer)
    def post(self,request):
        try:
            # user_id = request.user.id
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            category_id = request.data.get('category_id')
            status_id = request.data.get('status_id')
            is_escalate = request.data.get('is_escalate')
            staff_id = request.data.get('staff_id')
            ticket_Info = queryset_for_ticket_list(self)
            is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False

            if is_admin:
                department_id = request.data.get('department_id')
            else:
                department_id = request.user.dept_id

            filters = {'created_at__range':[start_date, end_date],
                    'status__in':[TicketStatus.StatusStage.OPEN,TicketStatus.StatusStage.INPROGRESS,TicketStatus.StatusStage.ONHOLD,TicketStatus.StatusStage.REOPEN]}
            if category_id != 0:
                filters['category'] = category_id
            if status_id != []:
                filters['status__in'] = status_id
            if staff_id != []:
                filters['worked_by__in'] = staff_id
            if is_escalate is False:
                filters['is_escalate'] = True
            if request.data.get('department_id') != [] and is_admin:
                filters['department_id__in'] = department_id
            if not is_admin:
                filters['department_id'] = department_id

            user_ticket_Info = ticket_Info.filter(**filters)
            excel_file = self.create_excel(ipa_info=user_ticket_Info,req_data=request.data,title="Outstanding")
            return excel_file
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AllTicketWithCloseListExcelExp(generics.GenericAPIView):

    permission_classes = [IsAdmin|IsManager]
    @swagger_auto_schema(request_body=AllTicketListSerializer)
    def post(self,request):
        try:
            # user_id = request.user.id
            date_range = request.data.get('date_range')
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            category_id = request.data.get('category_id')
            status_id = request.data.get('status_id')
            is_escalate = request.data.get('is_escalate')
            staff_id = request.data.get('staff_id')
            ticket_Info = queryset_for_ticket_list(self)
            is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False

            if is_admin:
                department_id = request.data.get('department_id')
            else:
                department_id = request.user.dept_id

            filters = {'created_at__range':[start_date, end_date]}
            if category_id != 0:
                filters['category'] = category_id
            if status_id != []:
                filters['status__in'] = status_id
            if staff_id != []:
                filters['worked_by__in'] = staff_id
            if is_escalate is False:
                filters['is_escalate'] = True
            if request.data.get('department_id') != [] and is_admin:
                filters['department_id__in'] = department_id
            if not is_admin:
                filters['department_id'] = department_id

            user_ticket_Info = ticket_Info.filter(**filters)
            excel_file = AllTicketListExcelExp.create_excel(self,ipa_info=user_ticket_Info,req_data=request.data,title="AllTicket")
            return excel_file
        except Exception as e:
            print('AssignedTicketList Error: ', str(e))
            return Response({'Invalid Requset': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class StaffUserList(generics.GenericAPIView):
    permission_classes=[IsManager|IsStaff|IsAdmin]
    def get(self, request):
        try:
            department_id = request.user.dept_id
            staff_list = [UserRole.RoleStatus.MANAGER,UserRole.RoleStatus.STAFF,UserRole.RoleStatus.ADMIN]
#dept_id=department_id,
            user_info = User.objects.filter(role_id__in=staff_list,is_active=True).values(
                'username', 'id', 'email', 'first_name', 'last_name', 'role_id',
                'pseudo_name', 'user_info', 'timeshtlist_sts', 'shift_id', 'shift_frm',
                'shift_to', 'timechk_sts', 'dept_id', 'bm_usr_id', 'entry_date', 'date_joined',
                'gender', 'is_active'
            ).annotate(dept_name=F('dept__name'))
            return Response(user_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserList Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class AdminStaffUserList(generics.GenericAPIView):
    permission_classes=[IsAdmin]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self, request):
        try:
            department_id = request.data.get('department_id')
            filter = {'role_id__in':[UserRole.RoleStatus.MANAGER,UserRole.RoleStatus.STAFF],'is_active':True}
            if department_id != []:
                filter['dept_id__in'] = department_id
            user_info = User.objects.filter(**filter).values(
                'username', 'id', 'email', 'first_name', 'last_name', 'role_id',
                'pseudo_name', 'user_info', 'timeshtlist_sts', 'shift_id', 'shift_frm',
                'shift_to', 'timechk_sts', 'dept_id', 'bm_usr_id', 'entry_date', 'date_joined',
                'gender', 'is_active'
            ).annotate(dept_name=F('dept__name'))
            return Response(user_info, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserList Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

def clean_name(name):
        """Remove special characters except spaces and underscores, and replace spaces with underscores."""
        name = re.sub(r'[^a-zA-Z0-9 _]', '', name)
        return name.replace(" ", "_").lower()

def handle_uploaded_file(file_content, department_id, user_id, ticket_id, type):
        """
        To handle uploading of a file, storing it with versioning and generating a structured file path.
        :Parameters
        file_content - uploaded file object (InMemoryUploadedFile or TemporaryUploadedFile)
        department_id - ID of the department the file is associated with (integer)
        user_id - ID of the user uploading the file (integer)
        ticket_id - ID of the ticket the file is linked to (integer)
        type - string indicating the file context ('note' for TicketNotesDetails or any other value for TicketDetails)
        :Result
        returns a tuple containing the relative file path (string), the saved file name with version and original name metadata (string), and the latest version string (e.g., '1.0', '1.1')
        """
        department_name = Department.objects.get(id=department_id).name

        date_object = datetime.now().date()
        year, month, day = str(date_object.year), str(date_object.month), str(date_object.day)
        relative_path = os.path.join(department_name, year, month, day)
        absolute_path = os.path.join(FILE_PATH, relative_path)
        Path(absolute_path).mkdir(parents=True, exist_ok=True)

        file_name_raw, file_ext = os.path.splitext(file_content.name)
        cleaned_file_name = clean_name(file_name_raw)
        user_name = User.objects.get(id=user_id).first_name
        if type=="note":
            previous_version = TicketNotesDetails.objects.filter(ticket_id=ticket_id).order_by('-created_at').first()
        else:
            previous_version = TicketDetails.objects.filter(id=ticket_id).first()

        if previous_version and previous_version.file_path:
            # previous_file_name = os.path.basename(previous_version.file_path)
            # version_match =  re.search(rf"{re.escape(cleaned_file_name)}_(\d+){re.escape(file_ext)}", previous_file_name)
            # if version_match:
            #     last_version = int(version_match.group(1))
            #     print('last_version',last_version)
            # else:
            #     last_version = 1
            major, minor = map(int, previous_version.version.split('.'))
            if minor == 9:
                major += 1
                minor = 0
            else:
                minor += 1
            latest_version = f"{major}.{minor}"
        else:
            latest_version = '1.0'
        versioned_file_name = f"{cleaned_file_name}_{user_name}_{latest_version}__ORIG__{cleaned_file_name}{file_ext}"
        fs = FileSystemStorage(location=absolute_path)
        fs.save(versioned_file_name, ContentFile(file_content.read()))

        return relative_path, versioned_file_name,latest_version

class UpdateStatusAndNote(generics.GenericAPIView):

    def exclude_weekends_and_holidays(start, end, holidays):
        holidays = {h.date() if isinstance(h, datetime) else h for h in holidays}
        total = timedelta()
        current = start

        while current < end:
            current_date = current.date()
            if current.weekday() < 5 and current_date not in holidays:
                next_check = min(end, current.replace(hour=23, minute=59, second=59, microsecond=999999))
                total += next_check - current
            current += timedelta(days=1)
            current = current.replace(hour=0, minute=0, second=0, microsecond=0)

        return total

    parser_classes = [MultiPartParser]
    permission_classes = [IsAdmin|IsManager|IsStaff]
    @swagger_auto_schema(request_body=UnifiedStatusNoteSerializer)
    def post(self, request):
        try:
            with transaction.atomic():
                data = request.data
                user_id = request.user.id
                # ticket_id = int(data.get('ticket_id'))
                # status_id = int(data.get('status_id'))
                # is_cycle_restrict = data.get('is_cycle_restrict')
                # msg_notes = data.get('msg_notes')
                # is_private = str(data.get('is_private', 'false')).strip().lower() in ('true', '1')

                serializer = UnifiedStatusNoteSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                validated_data = serializer.validated_data

                is_cycle_restrict = validated_data.get('is_cycle_restrict', False)
                is_private = validated_data.get('is_private',False)
                # is_private = str(data.get('is_private', 'false')).strip().lower() in ('true', '1')
                msg_notes = validated_data.get('msg_notes', '')
                status_id = validated_data.get('status_id')
                ticket_id = validated_data.get('ticket_id')

                ticket_object = TicketDetails.objects.select_related('category', 'status', 'created_by').filter(id=ticket_id).first()
                if not ticket_object:
                    raise Exception("Ticket not found")
                current_status = ticket_object.status_id
                # reopen = ticket_object.is_reopen
                base_user = userRole(user_id=user_id)
                user_object = User.objects.filter(id=user_id).first()

                allowed_transitions = {
                    TicketStatus.StatusStage.OPEN: [TicketStatus.StatusStage.INPROGRESS],
                    TicketStatus.StatusStage.INPROGRESS: [TicketStatus.StatusStage.ONHOLD, TicketStatus.StatusStage.RESOLVED],
                    TicketStatus.StatusStage.ONHOLD: [TicketStatus.StatusStage.INPROGRESS, TicketStatus.StatusStage.RESOLVED],
                    TicketStatus.StatusStage.REOPEN: [TicketStatus.StatusStage.INPROGRESS,TicketStatus.StatusStage.ONHOLD, TicketStatus.StatusStage.RESOLVED],
                }
                if status_id in allowed_transitions.get(current_status, []) and msg_notes:
                    holiday_qry = HolidayList.objects.filter(
                        holiday_date__year=datetime.today().year,
                        status=True
                    )
                    holiday_list = set(
                        h.holiday_date.date() if hasattr(h.holiday_date, "date") else h.holiday_date
                        for h in holiday_qry
                    )
                    total_inprogress_seconds = 0
                    inprogress_start_time = None
                    if status_id == TicketStatus.StatusStage.RESOLVED:
                        history = TicketStatusHistory.objects.filter(ticket_id=ticket_id).order_by('created_at')
                        inprogress_like_statuses = [TicketStatus.StatusStage.INPROGRESS, TicketStatus.StatusStage.REOPEN]

                        for i, entry in enumerate(history):
                            current_status = entry.status_id

                            if current_status in inprogress_like_statuses:
                                if inprogress_start_time is None:
                                    inprogress_start_time = entry.created_at

                            elif inprogress_start_time:
                                # Status changed to something other than inprogress or reopen (like ONHOLD, RESOLVED)
                                time_diff = UpdateStatusAndNote.exclude_weekends_and_holidays(inprogress_start_time, entry.created_at, holiday_list)
                                total_inprogress_seconds += time_diff.total_seconds()
                                inprogress_start_time = None

                        # Close any open in-progress block at time of RESOLVED now
                        if inprogress_start_time:
                            time_diff = UpdateStatusAndNote.exclude_weekends_and_holidays(inprogress_start_time, datetime.now(timezone.utc), holiday_list)
                            total_inprogress_seconds += time_diff.total_seconds()

                    ticket_object.resolved_hours = round(total_inprogress_seconds / 3600, 2) if total_inprogress_seconds else None
                    ticket_object.status_id = status_id
                    ticket_object.status_updated_at = datetime.now(timezone.utc)
                    if user_object.role_id in (1, 4) and status_id == TicketStatus.StatusStage.RESOLVED and is_cycle_restrict:
                        ticket_object.is_cycle_restrict = is_cycle_restrict
                    if user_id == ticket_object.worked_by_id and not ticket_object.sender_notes and not is_private:
                        ticket_object.sender_notes = True

                    ticket_object.save()
                else:
                    # raise Exception(f"Invalid transition from {TicketStatus.StatusStage(current_status).name} to {TicketStatus.StatusStage(status_id).name}.")
                    return Response({'Invalid Data': f"Invalid transition from {TicketStatus.StatusStage(current_status).name} to {TicketStatus.StatusStage(status_id).name}."}, status=status.HTTP_400_BAD_REQUEST)
            
                
                    
                TicketStatusHistory.objects.create(
                    ticket_id=ticket_object.id,
                    status=ticket_object.status,
                    created_by_id=user_id
                )

                file_obj = request.FILES.get('file')
                is_staff = True if user_id == ticket_object.worked_by_id else False
                file_name, file_path, version = '', '', ''
                if file_obj:
                    file_path, file_name, version = handle_uploaded_file(
                        file_content=file_obj,
                        department_id=ticket_object.department_id,
                        user_id=user_id,
                        ticket_id=ticket_id,
                        type="note"
                    )

                notes_data = {
                    "ticket": ticket_object,
                    "msg_notes": msg_notes,
                    "file_name": file_name,
                    "file_path": file_path,
                    "version": version,
                    "is_staff":is_staff,
                    "created_by_id": user_id,
                    "is_private": is_private if not base_user else False
                }

                TicketNotesDetails.objects.create(**notes_data)
                # ticket = TicketDetails.objects.select_related('category','worked_by','status','created_by').filter(id=ticket_id).first()
                

                if EMAIL_TRIGGER:
                    try:
                        result = app.control.broadcast('ping', reply=True, limit=1)
                        if current_status != ticket_object.status_id:
                            is_private = False
                        if result and not is_private:
                            trans_data = {}
                            trans_data['type'] = "Status"
                            trans_data['ticket_id'] = ticket_object.id
                            trans_data['category_name'] = ticket_object.category.name
                            trans_data['title'] = ticket_object.title
                            trans_data['department'] = ticket_object.department_id
                            trans_data['summary'] = ticket_object.summary
                            trans_data['current_status'] = ticket_object.status.name
                            trans_data['user_mail'] = ticket_object.created_by.email
                            trans_data['user_name'] = f"{ticket_object.created_by.first_name} {ticket_object.created_by.last_name}"
                            # if ticket_object.status.id == TicketStatus.StatusStage.REOPEN:
                            #     trans_data['type'] = "Reopen"
                            #     # trans_data['comments'] = ticket_object.comments
                            #     trans_data['user_mail'] = ticket_object.worked_by.email
                            send_newticket_email.delay(trans_data)
                    except Exception as e:
                        print('Email error:', e)

                return Response("Status and note updated successfully", status=status.HTTP_200_OK)

        except Exception as e:
            print('Unified API Error:', str(e))
            return Response({'Invalid Data': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class UserCloseAndReopenTicket(generics.GenericAPIView):
    parser_classes = [MultiPartParser]
    permission_classes = [IsAdmin|IsManager|IsStaff|IsBasicUser]
    @swagger_auto_schema(request_body=UnifiedStatusNoteSerializer)
    def post(self, request):
        try:
            with transaction.atomic():
                data = request.data
                user_id = request.user.id
                # ticket_id = data.get('ticket_id')
                # status_id = data.get('status_id')

                serializer = UnifiedStatusNoteSerializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                validated_data = serializer.validated_data

                is_private = validated_data.get('is_private',False)
                # is_private = str(data.get('is_private', 'false')).strip().lower() in ('true', '1')
                msg_notes = validated_data.get('msg_notes', '')
                status_id = int(validated_data.get('status_id'))
                ticket_id = int(validated_data.get('ticket_id'))

                ticket_object = TicketDetails.objects.select_related('category', 'status', 'created_by','worked_by').filter(id=ticket_id).first()

                if not ticket_object:
                    raise Exception("Ticket not found")
                if ticket_object.created_by_id != user_id:
                    return Response({'Detail': 'Authentication mismatch with the user'}, status=status.HTTP_400_BAD_REQUEST)

                current_status = ticket_object.status_id
                reopen = ticket_object.is_reopen
                is_base_user = True if user_id == ticket_object.created_by_id else False
                # base_user = userRole(user_id=user_id)
                
                if is_base_user:
                    if current_status == TicketStatus.StatusStage.RESOLVED:
                        if status_id == TicketStatus.StatusStage.REOPEN and ticket_object.is_cycle_restrict:
                            # raise Exception("This Ticket Reopen Access Restricted By Manager.")
                            return Response({'Invalid Data': "This Ticket Reopen Access Restricted By Manager."}, status=status.HTTP_400_BAD_REQUEST)
                        if status_id in [TicketStatus.StatusStage.CLOSED, TicketStatus.StatusStage.REOPEN]:
                            ticket_object.status_id = status_id
                            ticket_object.status_updated_at = datetime.now(timezone.utc)
                            if status_id == TicketStatus.StatusStage.CLOSED:
                                ticket_object.is_active = False
                                ticket_object.closed_by = TicketDetails.ClosedByType.USER
                            elif status_id == TicketStatus.StatusStage.REOPEN:
                                ticket_object.is_reopen = reopen + 1
                            ticket_object.save()
                        else:
                            # raise Exception("Base users can only move a Resolved ticket to Closed or Reopen.")
                            return Response({'Invalid Data': "Base users can only move a Resolved ticket to Closed or Reopen."}, status=status.HTTP_400_BAD_REQUEST)
                    else:
                        # raise Exception("Base users are not allowed to change ticket status from the current state.")
                        return Response({'Invalid Data': "Base users can only move a Resolved ticket to Closed or Reopen."}, status=status.HTTP_400_BAD_REQUEST)
                else:
                        # raise Exception("Base users are not allowed to change ticket status from the current state.")
                        return Response({'Invalid Request': "Base users can only move a Resolved ticket to Closed or Reopen."}, status=status.HTTP_400_BAD_REQUEST)

                TicketStatusHistory.objects.create(
                    ticket_id=ticket_object.id,
                    status=ticket_object.status,
                    created_by_id=user_id
                )

                # msg_notes = data.get('msg_notes')
                # is_private = data.get('is_private', False)
                file_obj = request.FILES.get('file')
                file_name, file_path, version = '', '', ''
                if file_obj:
                    file_path, file_name, version = handle_uploaded_file(
                        file_content=file_obj,
                        department_id=ticket_object.department_id,
                        user_id=user_id,
                        ticket_id=ticket_id,
                        type="note"
                    )

                notes_data = {
                    "ticket": ticket_object,
                    "msg_notes": msg_notes,
                    "file_name": file_name,
                    "file_path": file_path,
                    "version": version,
                    "created_by_id": user_id,
                    "is_private": is_private if not is_base_user else False
                }

                TicketNotesDetails.objects.create(**notes_data)

                if ticket_object.created_by_id == user_id and ticket_object.receiver_notes is False:
                    ticket_object.receiver_notes = True
                    ticket_object.save()

                if EMAIL_TRIGGER:
                    if ticket_object.status.id == TicketStatus.StatusStage.REOPEN:
                        try:
                            result = app.control.broadcast('ping', reply=True, limit=1)
                            if result:
                                trans_data = {}
                                trans_data['type'] = "Status"
                                trans_data['ticket_id'] = ticket_object.id
                                trans_data['category_name'] = ticket_object.category.name
                                trans_data['title'] = ticket_object.title
                                trans_data['department'] = ticket_object.department_id
                                trans_data['summary'] = ticket_object.summary
                                trans_data['current_status'] = ticket_object.status.name
                                trans_data['user_mail'] = ticket_object.worked_by.email
                                trans_data['user_name'] = f"{ticket_object.worked_by.first_name} {ticket_object.worked_by.last_name}"
                                trans_data['requested_by'] = f"{ticket_object.created_by.first_name} {ticket_object.created_by.last_name}"
                                trans_data['type'] = "Reopen"
                                trans_data['comments'] = msg_notes
                                # trans_data['user_mail'] = ticket_object.worked_by.email
                                send_newticket_email.delay(trans_data)
                        except Exception as e:
                            print('Email error:', e)

                return Response("Status and note updated successfully", status=status.HTTP_200_OK)

        except Exception as e:
            print('Unified API Error:', str(e))
            return Response({'Invalid Data': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TicketStatusCount(generics.GenericAPIView):
    permission_classes=[IsAdmin|IsManager]
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self,request):
        try:
            # user_id = request.user.id
            date_range = request.data['date_range']
            start_date = datetime.strptime(date_range['start_time'], '%Y-%m-%d').date()
            end_date = datetime.strptime(date_range['end_time'], '%Y-%m-%d').date() + timedelta(days=1)
            filters = {'status_updated_at__range': [start_date, end_date]}  #'status_updated_at__date':datetime.now().date()
            rec_final_list = []
            is_admin = True if request.user.role_id == UserRole.RoleStatus.ADMIN else False

            if is_admin:
                department_id = request.data.get('department_id')
            else:
                department_id = request.user.dept_id
                filters['department_id'] = department_id

            if request.data.get('department_id') != []:
                filters['department_id__in'] = department_id

            tickets = TicketDetails.objects.filter(**filters)

            status_counts = tickets.values('status_id').annotate(count=Count('id'))
            status_map = {
                TicketStatus.StatusStage.OPEN: 'open_tickets',
                TicketStatus.StatusStage.INPROGRESS: 'inprogress_tickets',
                TicketStatus.StatusStage.ONHOLD: 'hold_tickets',
                TicketStatus.StatusStage.RESOLVED: 'resolved_tickets',
                TicketStatus.StatusStage.CLOSED: 'closed_tickets',
                TicketStatus.StatusStage.REOPEN: 'reopen_tickets',
            }

            outstanding_statuses = {
                TicketStatus.StatusStage.OPEN,
                TicketStatus.StatusStage.INPROGRESS,
                TicketStatus.StatusStage.ONHOLD,
                TicketStatus.StatusStage.REOPEN,
            }

            rec_list_info = {v:0  for v in status_map.values()}
            rec_list_info['total_tickets'] = tickets.count()
            rec_list_info['outstanding_tickets'] = 0

            for entry in status_counts:
                status_id = entry['status_id']
                count = entry['count']
                if status_id in status_map:
                    rec_list_info[status_map[status_id]] = count
                if status_id in outstanding_statuses:
                    rec_list_info['outstanding_tickets'] += count

            rec_final_list.append(rec_list_info)
            return Response(rec_final_list,status=status.HTTP_200_OK)
        except Exception as e:
            print('TicketStatusCount API Error:', str(e))
            return Response({'Invalid Data': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
class Deptlist(generics.GenericAPIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request):
        try:
            dept_data = Department.objects.filter(is_ticket=True,status=True).all()
            out_data = DeptSerializer(dept_data, many=True).data
            return Response(out_data, status=status.HTTP_200_OK)
        except Exception as e:
            print('Deptlist Error: ', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
class UserCategoryList(generics.GenericAPIView):
    permission_classes = [IsManager|IsStaff|IsBasicUser|IsAdmin] #IsManager|IsStaff|IsBasicUser|IsAdmin
    @swagger_auto_schema(request_body=UserTicketListSerializer)
    def post(self,request):
        try:
            department_id = request.data.get("department_id")
            filters = {'is_ticket':True,'status':True}

            if department_id != []:
                filters['id__in'] = department_id

            user_filter = User.objects.filter(role_id=UserRole.RoleStatus.STAFF,is_active=True)
            category_filter = CategoryDetails.objects.filter(status=True)
            prefetch1 = Prefetch('user_dept',queryset=user_filter)
            prefetch2 = Prefetch('category_dept',queryset=category_filter)
            dept_obj = Department.objects\
            .prefetch_related(prefetch1,prefetch2)\
            .filter(**filters)
            serializer = DeptUserSerializer(dept_obj, many=True)

            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            print('UserCategoryList Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class TicketHistoryDetailsExport(generics.GenericAPIView):

    def create_excel(self, log_data, title):
        workbook = Workbook()
        workbook.remove(workbook.active)
        worksheet = workbook.create_sheet(title='Reports')
        row_num = 1

        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        # Header
        cell = worksheet.cell(row=row_num, column=2)
        cell.value = f'SE Tracker: {title} Logs'
        cell.font = Font(bold=True)
        row_num += 2

        # Ticket Summary Header
        cell = worksheet.cell(row=row_num, column=2)
        cell.value = 'Ticket Summary'
        cell.font = Font(bold=True)
        row_num += 1

        # Ticket Summary Columns
        summary_columns = [
            "S.No", "Event Type", "Created At", "Ticket Number", "Title", "Summary",
            "Category", "Department", "File Name", "By"
        ]
        summary_column_width = []

        for col_num, column_title in enumerate(summary_columns, 1):
            cell = worksheet.cell(row=row_num, column=col_num)
            cell.value = column_title
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.font = Font(bold=True, size=10)
            cell.border = thin_border
            cell.fill = PatternFill(start_color="8ea9db", fill_type="solid")
            summary_column_width.append(len(str(column_title)) * 1.2)

        slno = 1
        for item in log_data:
            if item.get('type', '').capitalize() == 'Create':
                row_num += 1
                data = item.get('data', {})
                created_at = data.get('created_at')
                if isinstance(created_at, datetime):
                    created_at_str = created_at.strftime("%m/%d/%Y %I:%M %p")
                elif isinstance(created_at, str) and created_at:
                    created_at_str = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ").strftime("%m/%d/%Y %I:%M %p")
                else:
                    created_at_str = ''

                row = [
                    slno,
                    item.get('type', '').capitalize(),
                    created_at_str,
                    data.get('ticket_number', ''),
                    data.get('title', ''),
                    data.get('summary', ''),
                    data.get('category', ''),
                    data.get('department', ''),
                    data.get('file_name', ''),
                    data.get('by', '')
                ]

                for col_num, cell_value in enumerate(row, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    cell.border = thin_border
                    cell.font = Font(size=10)
                    if summary_column_width[col_num - 1] < len(str(cell_value)):
                        summary_column_width[col_num - 1] = len(str(cell_value)) + 2
                slno += 1

        summary_dim_holder = DimensionHolder(worksheet=worksheet)
        for col in range(1, len(summary_column_width) + 1):
            summary_dim_holder[get_column_letter(col)] = ColumnDimension(
                worksheet, min=col, max=col, width=summary_column_width[col - 1]
            )
        worksheet.column_dimensions = summary_dim_holder

        row_num += 2
        cell = worksheet.cell(row=row_num, column=2)
        cell.value = 'Ticket History'
        cell.font = Font(bold=True)
        row_num += 1

        history_columns = [
            "S.No", "Event Type","Created At","Created By","Description", "Message",  "File Name"
        ]
        history_column_width = []

        for col_num, column_title in enumerate(history_columns, 1):
            cell = worksheet.cell(row=row_num, column=col_num)
            cell.value = column_title
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.font = Font(bold=True, size=10)
            cell.border = thin_border
            cell.fill = PatternFill(start_color="8ea9db", fill_type="solid")
            history_column_width.append(len(str(column_title)) * 1.2)

        # Fill History Data
        slno = 1
        for item in log_data:
            if item.get('type', '').capitalize() != 'Create':
                row_num += 1
                data = item.get('data', {})
                created_at = data.get('created_at')
                if isinstance(created_at, datetime):
                    created_at_str = created_at.strftime("%m/%d/%Y %I:%M %p")
                elif isinstance(created_at, str) and created_at:
                    created_at_str = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ").strftime("%m/%d/%Y %I:%M %p")
                else:
                    created_at_str = ''

                row = [
                    slno,
                    item.get('type', '').capitalize(),
                    created_at_str,
                    data.get('by', ''),
                    data.get('description',''),
                    data.get('message', ''),
                    data.get('file_name', ''),
                ]

                for col_num, cell_value in enumerate(row, 1):
                    cell = worksheet.cell(row=row_num, column=col_num)
                    cell.value = cell_value
                    cell.border = thin_border
                    cell.font = Font(size=10)
                    if history_column_width[col_num - 1] < len(str(cell_value)):
                        history_column_width[col_num - 1] = len(str(cell_value)) + 2
                slno += 1

        # Set History Column Widths
        history_dim_holder = DimensionHolder(worksheet=worksheet)
        for col in range(1, len(history_column_width) + 1):
            history_dim_holder[get_column_letter(col)] = ColumnDimension(
                worksheet, min=col, max=col, width=history_column_width[col - 1]
            )
        worksheet.column_dimensions.update(history_dim_holder)

        file_name = f'SE_Tracker_{title}_Logs_{date.today().strftime("%m%d%y")}.xlsx'
        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = f'attachment; filename={file_name}'
        response['Access-Control-Expose-Headers'] = "Content-Disposition"
        workbook.save(response)
        return response

    permission_classes=[IsManager|IsAdmin|IsStaff]
    @swagger_auto_schema(request_body=UpdatedTicketDownloadSerializer)
    def post(self,request):
        try:
            json_response = TicketHistoryDetails.post(self, request)
            log_data = json_response.data if hasattr(json_response, 'data') else json_response
            sorted_history = sorted(log_data, key=lambda x: x["data"]["created_at"] or timezone.now())
            excel_file = self.create_excel(log_data=sorted_history,title="History Details")
            return excel_file
        except Exception as e:
            print('TicketHistoryDetailsExport Error:', str(e))
            return Response({'Invalid Request': str(e)}, status=status.HTTP_400_BAD_REQUEST)