from django.db import models
from authapi.models import User,Department
from tracker.settings import FILE_PATH

class CategoryDetails(models.Model):
    name =  models.CharField(max_length=250, null=True, blank=True)
    desc = models.TextField(blank=True, null=True)
    status = models.BooleanField(null=True, blank=True, default=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='category_dept', null=True, blank=True)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['name', 'department'], name='unique_category_department')
        ]

class SubCategoryDetails(models.Model):
    name =  models.CharField(max_length=250, null=True, blank=True)
    desc = models.TextField(blank=True, null=True)
    status = models.BooleanField(null=True, blank=True, default=True)
    category = models.ForeignKey(CategoryDetails,on_delete=models.CASCADE,  related_name='cate_subcategory', null=True, blank= True)
    first_esc = models.IntegerField(default=0, null=True)
    recurring_esc = models.IntegerField(default=0, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['name', 'category'], name='unique_sub_category_per_category')
        ]

class TicketStatus(models.Model):
    class StatusStage(models.IntegerChoices):
        OPEN = 1
        INPROGRESS = 2
        ONHOLD = 3
        RESOLVED = 4
        CLOSED = 5
        REOPEN = 6
    name = models.CharField(max_length=100, null=True, blank=True)
    desc = models.CharField(max_length=100, null=True, blank=True)
    status = models.BooleanField(default=True, null=True)
    outstanding_status = models.BooleanField(default=True, null=True)
    is_active = models.BooleanField(default=True, null=True)
    is_escalate = models.BooleanField(default=False,null=True)
    order_id = models.IntegerField(default=0, null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    updated_at = models.DateTimeField(null=True, blank=True)

class TicketDetails(models.Model):
    class ClosedByType(models.IntegerChoices):
        USER = 0
        AUTOMATE = 1
    title   = models.TextField(blank=True, null=True)
    summary = models.TextField(blank=True, null=True)
    file_path = models.FilePathField(path=FILE_PATH, null=True, blank=True)
    file_name = models.CharField(max_length=250, blank=True, null=True)
    org_file_name = models.CharField(max_length=250, blank=True, null=True)
    version = models.CharField(max_length=250, blank=True, null=True)
    status = models.ForeignKey(TicketStatus, related_name='ticket_status_id', on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(CategoryDetails, related_name='ticket_category_id', on_delete=models.CASCADE, null=True, blank=True)
    sub_category = models.ForeignKey(SubCategoryDetails,related_name='ticket_sub_category_id', on_delete=models.CASCADE, null=True, blank=True)
    department = models.ForeignKey(Department,related_name='ticket_department_id', on_delete=models.CASCADE, null=True, blank=True)
    tag_staff = models.ForeignKey(User, related_name='ticket_staff_id', on_delete=models.CASCADE, null=True, blank=True)
    worked_by = models.ForeignKey(User, related_name='ticket_worked_by_id', on_delete=models.CASCADE, null=True, blank=True)
    assigned_by = models.ForeignKey(User, related_name='ticket_assigned_by_id', on_delete=models.CASCADE, null=True, blank=True)
    is_escalate = models.BooleanField(default=False,null=True)
    is_cycle_restrict = models.BooleanField(default=False,null=True)
    escalation_count = models.IntegerField(default=0,null=True)
    is_reassign = models.IntegerField(default=0,null=True)
    is_reopen = models.IntegerField(default=0, null=True)
    is_active = models.BooleanField(default=True,null=True)
    sender_notes = models.BooleanField(default=False,null=True)
    receiver_notes = models.BooleanField(default=False,null=True)
    resolved_hours = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    closed_by = models.IntegerField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    status_updated_at = models.DateTimeField(null=True, blank=True)
    esc_updated_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(User, related_name='ticket_user_id', on_delete=models.CASCADE, null=True, blank=True)

class TicketHistoryDetails(models.Model):
    title   = models.TextField(blank=True, null=True)
    summary = models.TextField(blank=True, null=True)
    file_path = models.FilePathField(path=FILE_PATH, null=True, blank=True)
    file_name = models.CharField(max_length=250, blank=True, null=True)
    org_file_name = models.CharField(max_length=250, blank=True, null=True)
    version = models.CharField(max_length=250, blank=True, null=True)
    comments = models.TextField(blank=True, null=True)
    ticket = models.ForeignKey(TicketDetails, related_name='ticket_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    status = models.ForeignKey(TicketStatus, related_name='ticket_status_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    category = models.ForeignKey(CategoryDetails, related_name='ticket_category_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    sub_category = models.ForeignKey(SubCategoryDetails,related_name='ticket_sub_category_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    department = models.ForeignKey(Department,related_name='ticket_department_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    tag_staff = models.ForeignKey(User, related_name='ticket_staff_hist_id', on_delete=models.CASCADE, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_by = models.ForeignKey(User, related_name='ticket_upd_user_hist_id', on_delete=models.CASCADE, null=True, blank=True)

class TicketNotesDetails(models.Model):
    msg_notes = models.TextField(blank=True, null=True)
    is_private = models.BooleanField(default=False, null=True)
    is_staff = models.BooleanField(default=False, null=True)
    status = models.ForeignKey(TicketStatus, related_name='ticketnotes_status_id', on_delete=models.CASCADE, null=True, blank=True)
    ticket = models.ForeignKey(TicketDetails, related_name='ticketnotes_ticket_id', on_delete=models.CASCADE, null=True, blank=True)
    file_path = models.FilePathField(path=FILE_PATH, null=True, blank=True)
    file_name = models.CharField(max_length=250, blank=True, null=True)
    org_file_name = models.CharField(max_length=250, blank=True, null=True)
    version = models.CharField(max_length=250, blank=True, null=True)
    created_by = models.ForeignKey(User, related_name='notes_user_id', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)

class TicketStatusHistory(models.Model):
    ticket = models.ForeignKey(TicketDetails, related_name='ticketstatus_ticket_id', on_delete=models.CASCADE, null=True, blank=True)
    status = models.ForeignKey(TicketStatus, related_name='ticketstatus_status_id', on_delete=models.CASCADE, null=True, blank=True)
    created_by = models.ForeignKey(User, related_name='ticketstatus_user_id', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)

class TicketAssignedHistory(models.Model):
    ticket = models.ForeignKey(TicketDetails, related_name='ticketassign_ticket_id', on_delete=models.CASCADE, null=True, blank=True)
    assigned_by = models.ForeignKey(User, related_name='ticketassign_assigned_by_id', on_delete=models.CASCADE, null=True, blank=True)
    assigned_to = models.ForeignKey(User, related_name='ticketassign_assigned_to_id', on_delete=models.CASCADE, null=True, blank=True)
    comments = models.TextField(blank=True, null=True)
    is_reassign = models.BooleanField(default=False,null=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)

class TicketEscalationHistory(models.Model):
    class EscTriggerType(models.IntegerChoices):
        USER = 0
        AUTOMATE = 1
    ticket = models.ForeignKey(TicketDetails, related_name='ticketesc_ticket_id', on_delete=models.CASCADE, null=True, blank=True)
    comments = models.TextField(blank=True, null=True)
    trigger_type = models.IntegerField(null=True, blank=True)
    created_by = models.ForeignKey(User, related_name='ticketesc_user_id', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)
