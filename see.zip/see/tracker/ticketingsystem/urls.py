from django.urls import path
from . import views
from ticketingsystem.views import *


urlpatterns = [
    path('staff_user_list/', views.StaffUserList.as_view()),
    path('staff_user_list/admin/', views.AdminStaffUserList.as_view()), # not used
    path('category_list/',views.ManagerCategoryList.as_view()),
    path('category_list/admin/',views.AdminCategoryList.as_view()), # not used
    path('dept_user_and_category/',views.DeptUserAndCategoryList.as_view()),
    path('dept_and_user/',views.DeptAndUserList.as_view()),
    path('sub_category_list/',views.SubCategoryList),
    path('dept_list_ticket/', views.Deptlist.as_view()),
    path('category/sub_category_list',views.GetSubCategoryList.as_view()),
    path('ticket_status_list/',views.StatusList),
    path('create_category/', views.CategoryCreateView.as_view()),
    path('create_sub_category/',views.SubCategoryCreateView.as_view()),
    path('update_category/', views.CategoryUpdateView.as_view()),
    path('update_sub_category/',views.SubCategoryUpdateView.as_view()),
    path('ticket_upload/', views.TicketUpload.as_view()),
    path('ticket_update/', views.TicketUpdate.as_view()),
    path('ticket_list/user',views.UserTicketList.as_view()),
    path('ticket_list/user_all',views.AllUserTicketList.as_view()),
    path('ticket_list/staff',views.StaffTicketList.as_view()),
    path('ticket_assigned_list/staff_assigned',views.StaffAssignedTicketList.as_view()),
    path('ticket_assigned_list/staff_inp',views.StaffInprogressTicketList.as_view()),
    path('ticket_assigned_list/report',views.AllTicketList.as_view()),
    path('ticket_assigned_list/all_ticket_report',views.AllTicketDetailsList.as_view()),
    path('ticket_assigned_list/report_export',views.AllTicketListExcelExp.as_view()),
    path('ticket_all_list/report_all_export',views.AllTicketWithCloseListExcelExp.as_view()),
    path('assign_ticket',views.AssignTicket.as_view()),
    path('reassign_ticket',views.ReAssignTicket.as_view()),
    path('updated_ticket_file/download',views.UpdatedTicketFileDownload.as_view()),
    path('updated_note_file/download',views.UpdatedNotesFileDownload.as_view()),
    path('ticket_note/update',views.AddTicketNote.as_view()),
    path('ticket_notes_list',views.UserNotesList.as_view()),
    path('ticket_user/escalate',views.UserEscalateTicket.as_view()),
    path('ticket_status_update',views.UpdateTicketStatus.as_view()), # not used
    path('status_update/close_and_reopen',views.UserCloseAndReopenTicket.as_view()),
    path('ticket_update/note_and_status',views.UpdateStatusAndNote.as_view()),
    path('ticket_notify/status_update',views.ChangeTicketReadStatus.as_view()),
    path('backup_database/',bak_db),
    path('ticket/staff_production_report',views.StaffProductionReport.as_view()),
    path('ticket/staff_production_report/export',views.StaffProductionReportExport.as_view()),
    path('ticket_details/history',views.TicketHistoryDetails.as_view()),
    path('ticket_Status/rec_count',views.TicketStatusCount.as_view()),
    path('ticket_Status/user_category_list',views.UserCategoryList.as_view()),
    path('ticket_details/history_export',views.TicketHistoryDetailsExport.as_view())
]