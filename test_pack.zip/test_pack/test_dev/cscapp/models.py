from django.db import models
from datetime import datetime


class PARTTYPETBL(models.Model):
    parttype_name = models.CharField(max_length=255, unique=True)

class PROJECTLISTTBL(models.Model):
    projects_name = models.CharField(max_length=255, unique=True)

class BOMSheet(models.Model):
    part_no = models.CharField(max_length=50)
    level = models.FloatField()
    revision = models.CharField(max_length=20)
    part_description = models.TextField()
    qty = models.FloatField()
    process_type = models.CharField(max_length=50)
    scope = models.CharField(max_length=50)
    method = models.CharField(max_length=50)
    is_nesting_needed = models.CharField(max_length=10)
    unique_csc_id = models.CharField(max_length=100)
    order_index = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order_index', 'id']

class CRCSCTBL(models.Model):
    part_num = models.CharField(max_length=100)
    rev = models.CharField(max_length=10)
    desc = models.CharField(max_length=200)
    part_typ = models.ForeignKey(PARTTYPETBL, on_delete=models.CASCADE, null=True, blank=True)  # Store the value directly
    projects = models.ForeignKey(PROJECTLISTTBL, on_delete=models.CASCADE, null=True, blank=True)  # Store the value directly
    rm_base = models.CharField(max_length=100)
    process_base = models.CharField(max_length=100)
    oh_profit_base = models.CharField(max_length=100)
    remarks = models.CharField(max_length=100)
    updated_on = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100)
    unique_csc_id = models.CharField(max_length=100, blank=True, editable=False)
    csc_status = models.CharField(max_length=100, null=True, blank=True)
    total_cost = models.FloatField(null=True, blank=True)
    rejected_reason = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.part_num

    def save(self, *args, **kwargs):
        if not self.unique_csc_id:  # Only generate a new ID if it doesn't already exist
            self.unique_csc_id = generate_unique_csc_id(self.part_num, self.rev)
        super().save(*args, **kwargs)


def get_existing_versions(part_no, revision):
    existing_versions = BOMSheet.objects.filter(
        part_no=part_no,
        revision=revision
    ).values_list('unique_csc_id', flat=True)

    versions = []
    for id in existing_versions:
        parts = id.split('-')
        if len(parts) == 5 and parts[-1].isdigit():
            versions.append(int(parts[-1]))

    return versions

def generate_unique_csc_id(part_no, revision):
    """Generate a unique CSC ID based on the highest existing version."""
    existing_versions = get_existing_versions(part_no, revision)
    # Determine the next version
    if existing_versions:
        next_version = max(existing_versions) + 1
    else:
        next_version = 1
    current_month_year = datetime.now().strftime("%b-%y")

    unique_csc_id = f"{part_no}-{revision}-{next_version}-{current_month_year}"
    return unique_csc_id