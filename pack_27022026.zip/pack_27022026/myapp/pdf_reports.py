import io

import matplotlib # type: ignore
matplotlib.use("Agg")
# import matplotlib.pyplot as plt
import datetime
from reportlab.lib import colors # type: ignore
from reportlab.lib.pagesizes import A4, landscape # type: ignore
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle # type: ignore
from reportlab.lib.units import mm # type: ignore
from reportlab.platypus import ( # type: ignore
    BaseDocTemplate, PageTemplate, Frame,
    Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, Image
)

from matplotlib.figure import Figure # type: ignore
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas # type: ignore

from .models import *
from django.db.models import Sum


def _header_footer(canvas, doc, csc_text: str):
    """
    Draws header/footer on every page.
    You can draw Paragraphs in onPage callbacks too (not just drawString),
    as demonstrated in common ReportLab patterns. [5](https://stackoverflow.com/questions/8827871/a-multilineparagraph-footer-and-header-in-reportlab)
    """
    canvas.saveState()

    # Header
    page_w, page_h = doc.pagesize
    canvas.setFont("Helvetica-Bold", 9)
    canvas.drawString(doc.leftMargin, page_h - 10*mm, csc_text) # doc.height + doc.topMargin - 8

    # Footer (page number)
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.grey)
    canvas.drawRightString(
        doc.leftMargin + doc.width,
        doc.bottomMargin - 12,
        f"Page {doc.page}"
    )
    canvas.restoreState()


# -----------------------------
# Helpers: Matplotlib chart -> ReportLab Image
# -----------------------------
def build_cost_graph_image(totals, width=240*mm, height=70*mm):
    """
    Creates a PNG bar chart in-memory and returns a Platypus Image flowable.
    Report generation often uses matplotlib -> image -> PDF embedding. [3](https://woteq.com/how-to-generate-charts-with-reportlab-and-matplotlib/)
    """
    labels = ["Direct RM", "Allowance", "Process", "Surface", "Overhead", "Profit"]
    values = [
        float(totals.get("total_direct_rm", 0) or 0),
        float(totals.get("total_allowance", 0) or 0),
        float(totals.get("total_process_cost", 0) or 0),
        float(totals.get("total_surface", 0) or 0),
        float(totals.get("total_oh_and_others", 0) or 0),
        float(totals.get("total_profit", 0) or 0),
    ]

    # Create figure WITHOUT pyplot
    fig = Figure(figsize=(10, 2.8))
    canvas = FigureCanvas(fig)
    ax = fig.add_subplot(111)

    ax.bar(labels, values, color="#4e79a7")
    ax.set_title("Cost Breakup", fontsize=12)
    ax.tick_params(axis="x", rotation=20)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()

    buf = io.BytesIO()
    canvas.print_png(buf)   # direct PNG render from Agg canvas
    buf.seek(0)

    img = Image(buf, width=width, height=height)
    img.hAlign = "LEFT"
    return img



# -----------------------------
# Helpers: Table styles
# -----------------------------
def _table_style_headered():
    return TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E6EEF8")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ])


def _kv_table(data_pairs, col_widths):
    """
    data_pairs: list of tuples [(label, value), ...]
    Produces 2-column table: label | value
    """
    rows = []
    for k, v in data_pairs:
        rows.append([str(k), "" if v is None else str(v)])

    t = Table(rows, colWidths=col_widths, hAlign="LEFT")
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
        ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    return t

def fmt3(x):
    """Return numbers as string rounded to 3 decimals; keep blanks for None."""
    if x is None or x == "":
        return ""
    try:
        return f"{float(x):.3f}"
    except (TypeError, ValueError):
        return str(x)

# -----------------------------
# Main builder
# -----------------------------
def build_csc_pdf_bytes(csc_id: int) -> bytes:
    # ---------- Load CSC ----------
    csc = CRCSCTBL.objects.get(id=csc_id)

    # ---------- Load BOMs ----------
    boms = list(
        BOMSheet.objects
        .filter(unique_csc_id=csc.unique_csc_id)
        .order_by("order_index", "id")
    )
    bom_ids = [b.id for b in boms]

    # ---------- Load summaries ----------
    summaries = (
        BomSummary.objects
        .filter(bom_id__in=bom_ids)
        .select_related("bom")
    )
    summary_by_bom = {s.bom_id: s for s in summaries}

    agg = summaries.aggregate(
        total_direct_rm=Sum("direct_rm"),
        total_allowance=Sum("allowance"),
        total_process_cost=Sum("process_cost"),
        total_surface=Sum("surface_finish_cost"),
        total_oh_and_others=Sum("oh_and_others"),
        total_profit=Sum("profit"),
        total_cpu=Sum("cpu"),
        total_cpa=Sum("cpa"),
        sum_weight=Sum("weight"),
        sum_total_weight=Sum("total_weight"),
    )
    totals = {k: float(v or 0) for k, v in agg.items()}

    # ---------- OH Profit ----------
    oh_rows = OH_ProfitData_child.objects.filter(bom_id__in=bom_ids)
    oh_bof_rows = OH_ProfitBOFData_child.objects.filter(bom_id__in=bom_ids)

    oh_by_bom = {}
    for r in oh_rows:
        oh_by_bom.setdefault(r.bom_id, []).append(r)

    oh_bof_by_bom = {}
    for r in oh_bof_rows:
        oh_bof_by_bom.setdefault(r.bom_id, []).append(r)

    # ---------- Material/Process by part_no (no FK) ----------
    materials = SMMaterial.objects.filter(unique_csc_id=csc.unique_csc_id)
    material_by_part = {m.part_no: m for m in materials}

    processes = SMProcess.objects.filter(unique_csc_id=csc.unique_csc_id)
    process_by_part = {}
    for p in processes:
        process_by_part.setdefault(p.part_no, []).append(p)

    # ---------- Start PDF ----------
    buffer = io.BytesIO()

    # Landscape is useful for wide BOM summary tables
    pagesize = landscape(A4)

    doc = BaseDocTemplate(
        buffer,
        pagesize=pagesize,
        leftMargin=10*mm,
        rightMargin=10*mm,
        topMargin=25*mm,
        bottomMargin=18*mm
    )

    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")
    header_text = f"CSC {csc.unique_csc_id} | Part {csc.part_num} Rev {csc.rev}"
    template = PageTemplate(
        id="main",
        frames=[frame],
        onPage=lambda canv, d: _header_footer(canv, d, header_text)
    )
    doc.addPageTemplates([template])

    styles = getSampleStyleSheet()
    H1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=14, spaceAfter=6)
    H2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=11, spaceBefore=8, spaceAfter=6)
    N = ParagraphStyle("N", parent=styles["Normal"], fontSize=9, leading=11)

    story = []

    # ---------- CSC Header ----------
    story.append(Paragraph("CSC COST SHEET REPORT", H1))
    story.append(Paragraph(f"Generated on: {datetime.now().strftime('%d-%b-%Y %H:%M')}", N))
    story.append(Spacer(1, 4))

    csc_kv = [
        ("CSC UNIQUE ID", csc.unique_csc_id),
        ("PART NUMBER", csc.part_num),
        ("REVISION", csc.rev),
        ("DESCRIPTION", csc.desc),
        ("ESTIMATED BY", csc.updated_by),
        ("REVIEWED BY", csc.reviewed_by or ""),
        ("RM BASE", csc.rm_base),
        ("PROCESS BASE", csc.process_base),
        ("OH PROFIT BASE", csc.oh_profit_base),
        ("STATUS", csc.csc_status or ""),
    ]
    story.append(Paragraph("CSC DETAILS", H2))
    story.append(_kv_table(csc_kv, col_widths=[45*mm, 200*mm]))
    story.append(Spacer(1, 8))

    # ---------- BOM Summary Table ----------
    story.append(Paragraph("BOM SUMMARY", H2))

    bom_header = [
        "S.No", "Part No", "Level", "Rev", "Description", "Qty",
        "Direct RM", "Allowance", "Process", "Surface", "OH", "Profit", "CPA", "Total Wt"
    ]
    bom_data = [bom_header]

    for i, bom in enumerate(boms, start=1):
        s = summary_by_bom.get(bom.id)
        bom_data.append([
            i,
            bom.part_no,
            fmt3(bom.level),
            bom.revision,
            (bom.part_description or "")[:40],
            fmt3(bom.qty),
            fmt3((s.direct_rm if s else 0) or 0),
            fmt3((s.allowance if s else 0) or 0),
            fmt3((s.process_cost if s else 0) or 0),
            fmt3((s.surface_finish_cost if s else 0) or 0),
            fmt3((s.oh_and_others if s else 0) or 0),
            fmt3((s.profit if s else 0) or 0),
            fmt3((s.cpa if s else 0) or 0),
            fmt3((s.total_weight if s else 0) or 0),
        ])


    # Totals row
    bom_data.append([
        "", "", "", "", "TOTAL", "",
        fmt3(totals["total_direct_rm"]),
        fmt3(totals["total_allowance"]),
        fmt3(totals["total_process_cost"]),
        fmt3(totals["total_surface"]),
        fmt3(totals["total_oh_and_others"]),
        fmt3(totals["total_profit"]),
        fmt3(totals["total_cpa"]),
        fmt3(totals["sum_total_weight"]),
    ])


    # Table supports repeating header rows using repeatRows, good for multi-page tables. [2](https://docs.reportlab.com/reportlab/userguide/ch7_tables/)
    col_widths = [10*mm, 25*mm, 12*mm, 12*mm, 70*mm, 12*mm, 18*mm, 18*mm, 18*mm, 18*mm, 18*mm, 18*mm, 18*mm, 20*mm]
    t_bom = Table(bom_data, colWidths=col_widths, repeatRows=1, hAlign="LEFT")
    t_bom.setStyle(_table_style_headered())
    story.append(t_bom)
    story.append(Spacer(1, 10))

    # ---------- Graph View ----------
    story.append(Paragraph("GRAPH VIEW (Cost Breakup)", H2))
    story.append(build_cost_graph_image(totals))
    story.append(PageBreak())

    # ---------- Expanded per BOM ----------
    story.append(Paragraph("EXPANDED BOM DETAILS", H1))
    story.append(Spacer(1, 6))

    for idx, bom in enumerate(boms, start=1):
        s = summary_by_bom.get(bom.id)
        m = material_by_part.get(bom.part_no)
        procs = process_by_part.get(bom.part_no, [])
        oh_list = oh_by_bom.get(bom.id, [])
        oh_bof_list = oh_bof_by_bom.get(bom.id, [])

        story.append(Paragraph(f"{idx}. BOM: {bom.part_no} | Level {bom.level} | Rev {bom.revision}", H2))
        story.append(Paragraph(f"{bom.part_description or ''}", N))
        story.append(Spacer(1, 4))

        # BOM cost snapshot
        snap = [
            ("Direct RM", (s.direct_rm if s else 0) or 0),
            ("Allowance", (s.allowance if s else 0) or 0),
            ("Process", (s.process_cost if s else 0) or 0),
            ("Surface", (s.surface_finish_cost if s else 0) or 0),
            ("OH", (s.oh_and_others if s else 0) or 0),
            ("Profit", (s.profit if s else 0) or 0),
            ("CPA", (s.cpa if s else 0) or 0),
            ("Total Wt", (s.total_weight if s else 0) or 0),
        ]
        story.append(_kv_table(snap, col_widths=[35*mm, 60*mm]))
        story.append(Spacer(1, 6))

        # SM Material
        story.append(Paragraph("SM MATERIAL", H2))
        if m:
            mat_pairs = [
                ("Material Grade", m.material_grade),
                ("RM Price/Kg", m.rm_price_per_kg),
                ("Length", m.length),
                ("Width", m.width),
                ("Thickness", m.thickness),
                ("Finish Weight", m.finish_weight),
                ("Direct RM Cost", m.direct_rm_cost),
                ("Allowance Cost", m.allowance_cost),
                ("Remarks", m.remarks or ""),
            ]
            story.append(_kv_table(mat_pairs, col_widths=[45*mm, 200*mm]))
        else:
            story.append(Paragraph("No SM Material found for this part.", N))
        story.append(Spacer(1, 6))

        # SM Process table
        story.append(Paragraph("SM PROCESS", H2))
        proc_header = [
            "Process Type", "Process Desc", "Mech/Hyd", "Machine Type",
            "No of Ops", "Parts/Cycle", "Norms", "Cost Unit", "Remarks"
        ]
        proc_data = [proc_header]
        for p in procs:
            proc_data.append([
                p.process_type,
                p.process_description,
                p.mechanical_hydraulic or "",
                p.machinetype or "",
                fmt3(p.no_of_operations),
                fmt3(p.parts_per_cycle),
                fmt3(p.norms),
                fmt3(p.process_cost_unit),
                p.remarks or "",
            ])


        t_proc = Table(
            proc_data if len(proc_data) > 1 else [proc_header, ["-", "-", "-", "-", "-", "-", "-", "-", "-"]],
            colWidths=[20*mm, 55*mm, 20*mm, 45*mm, 15*mm, 18*mm, 15*mm, 18*mm, 40*mm],
            repeatRows=1,  # repeat header after page split [2](https://docs.reportlab.com/reportlab/userguide/ch7_tables/)
            hAlign="LEFT"
        )
        t_proc.setStyle(_table_style_headered())
        story.append(t_proc)
        story.append(Spacer(1, 6))

        # OH Profit
        story.append(Paragraph("OH PROFIT", H2))
        oh_header = ["Process Type", "OH RM", "OH CONV", "OH BOF", "Profit RM", "Profit CONV", "Profit BOF", "Remarks"]
        oh_data = [oh_header]
        for o in oh_list:
            oh_data.append([
                o.process_type or "",
                fmt3(o.oh_rm),
                fmt3(o.oh_conv),
                fmt3(o.oh_bof),
                fmt3(o.profit_rm),
                fmt3(o.profit_conv),
                fmt3(o.profit_bof),
                (o.remarks or "")[:40],
            ])


        t_oh = Table(
            oh_data if len(oh_data) > 1 else [oh_header, ["-", 0, 0, 0, 0, 0, 0, "-"]],
            colWidths=[35*mm, 18*mm, 18*mm, 18*mm, 18*mm, 18*mm, 18*mm, 60*mm],
            repeatRows=1,  # repeats header on split [2](https://docs.reportlab.com/reportlab/userguide/ch7_tables/)
            hAlign="LEFT"
        )
        t_oh.setStyle(_table_style_headered())
        story.append(t_oh)
        story.append(Spacer(1, 6))

        # OH Profit BOF/BOSF
        story.append(Paragraph("OH PROFIT BOF / BOSF", H2))
        bof_header = ["Process Type", "OH BOF", "Profit BOF", "Warranty", "Inbound Logistics", "Remarks"]
        bof_data = [bof_header]
        for o in oh_bof_list:
            bof_data.append([
                o.process_type or "",
                fmt3(o.oh_bof),
                fmt3(o.profit_bof),
                fmt3(o.warranty_cost),
                fmt3(o.inbound_logistics),
                (o.remarks or "")[:60],
            ])


        t_bof = Table(
            bof_data if len(bof_data) > 1 else [bof_header, ["-", 0, 0, 0, 0, "-"]],
            colWidths=[40*mm, 22*mm, 22*mm, 22*mm, 30*mm, 95*mm],
            repeatRows=1,  # repeats header on split [2](https://docs.reportlab.com/reportlab/userguide/ch7_tables/)
            hAlign="LEFT"
        )
        t_bof.setStyle(_table_style_headered())
        story.append(t_bof)

        # Page break between BOMs
        if idx != len(boms):
            story.append(PageBreak())

    # Build PDF from flowables; Platypus builds by consuming flowables into frames/pages. [1](https://docs.reportlab.com/reportlab/userguide/ch5_platypus/)[4](https://github.com/MatthewWilkes/reportlab/blob/master/src/reportlab/platypus/doctemplate.py)
    doc.build(story)

    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes