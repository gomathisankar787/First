export const environment = {
  production: true,
  api_server:'http://192.168.15.160:8585/api' //live
  // api_server:'https://192.168.8.100:6567' //live
};
