import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/shared/services/toast.service';
import { ApiSharedService } from 'src/app/shared/http/api-shared.service';
import { Roles, UserModel } from 'src/app/shared/models/user.model'
import { LoginService } from 'src/app/core/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  formLogin!:FormGroup;
  submitted = false;
  isLoading = false;
  currentYear:any = new Date();

  constructor(private router: Router, private formBuilder: FormBuilder, private toast:ToastService, private apiservice: ApiSharedService,private loginService: LoginService,) { }

  ngOnInit(): void {
    this.formLogin = this.formBuilder.group(
      {
        username: ['',[ Validators.required,
                        Validators.minLength(2),
                        Validators.maxLength(20)]],
        password: ['',[ Validators.required,
                        Validators.minLength(4),
                        Validators.maxLength(40)]]
      }
    );
  }

  recoverypwd(){}

  // Form Builder and Form Validations
  // convenience getter for easy access to form fields
  get f() { return this.formLogin.controls; }

  onSubmit() {
    this.submitted = true;
    this.isLoading = true;
    // stop here if form is invalid
    if (this.formLogin.invalid) {
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid credentials: Invalid/ Empty username & password, please enter valid credentials!',
        "autoClose":false
      }
      this.toast.warning(objj)
      this.isLoading = false;
      return;
    }
    var user = {
      'username':this.formLogin.value.username,
      'password':window.btoa(this.formLogin.value.password)
    }
    this.apiservice.checkLogin(user).subscribe((data:any) => {
      var loginUsr = JSON.parse(window.atob(data.info));
      var usr_model:UserModel = <UserModel>loginUsr;
      usr_model.email = this.formLogin.value.username;
      usr_model.avatar = 1;
      if (loginUsr.user_info){
        let avatorId = loginUsr.user_info;
        if (avatorId > 0){
          usr_model.avatar = avatorId;
        }
      }
      this.loginService.login(data,usr_model).subscribe(status_js => {
        let loginInfo:any = status_js.user;
        loginInfo.verified_profile ? this.router.navigate(['home','homePage']) : this.router.navigate(['home','usrprofile'])
        // this.router.navigate(['home','homePage'])
      });
      this.isLoading = false;
    },err => {// Errors will call this callback instead:
      var objj={}
      let value:any;
      if (err.status==404 ||err.status==400){
        for (let key in err.error) {
          value = key +' : '+ err.error[key];
        }
        objj={
          "Type":2,
          "Title":'Warning',
          "Message":value,
          "autoClose":false
        }
      }else{
        objj={
          "Type":3,
          "Title":'Error',
          "Message":'Failed to process your request..., Please try again later!',
          "autoClose":false
        }
      }
      this.toast.warning(objj)
      this.isLoading = false;
    });
  }

  onReset() {
    this.submitted = false;
    this.formLogin.reset();
  }
}
