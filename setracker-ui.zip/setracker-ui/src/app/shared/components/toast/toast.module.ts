import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ToastRoutingModule } from './toast-routing.module';
import { ToastComponent } from './toast.component';


@NgModule({
  declarations: [
    ToastComponent
  ],
  imports: [
    CommonModule,
    ToastRoutingModule
  ],
  exports: [ToastComponent]
})
export class ToastModule { }
