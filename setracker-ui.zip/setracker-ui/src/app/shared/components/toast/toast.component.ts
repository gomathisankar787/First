import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ToastService } from '../../services/toast.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.scss']
})
export class ToastComponent implements OnInit {

  constructor(private toastServ:ToastService) { }

  toastAlert!:Subscription;
  Message:any;
  Title:any;

  ngOnInit(): void {
    // console.log('Toast Event called...')
    this.toastAlert = this.toastServ.toast$.subscribe(
      alertInfo => {
        var alertInfos = alertInfo;
        this.Title = alertInfos.Title;
        this.Message = alertInfos.Message;
        this.openToast(alertInfo.Type);
        if(alertInfos.autoClose==true){
          setTimeout(() => {
            this.closeToast();
          },3000);
        }
    });
  }

  ngOnDestroy() {
    if(this.toastAlert){
      this.toastAlert.unsubscribe();
    }
  }

  toastAlertMdl:any;
  openToast(toatsNumber:any){
    let toast =  document.getElementById('liveToast'+toatsNumber);//select id of toast
    this.toastAlertMdl = new (window as any).bootstrap.Toast(toast,{ autohide: false });//inizialize it
    this.toastAlertMdl.show();
  }

  closeToast(){
    this.toastAlertMdl.hide();
  }
}
