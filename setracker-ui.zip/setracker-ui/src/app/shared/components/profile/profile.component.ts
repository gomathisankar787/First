import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/core/services/login.service';
import { UserService } from 'src/app/core/services/user.service';
import { ApiSharedService } from '../../http/api-shared.service';
import { ProfileService } from '../../services/profile.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent {

  profileForm!:FormGroup;

  constructor(private api:ApiSharedService,private fb:FormBuilder,private router:Router,private toast:ToastService,private userServ:UserService,private prfService:ProfileService,private loginServ:LoginService){
    this.profileForm = this.fb.group({
      id:[null],
      first_name:['',Validators.required],
      last_name:['',Validators.required],
      email:[''],
      username:[''],
      password:[null],
      gender:[this.usrGender],
      user_info:[this.avatarIndex]
    })
  }

  userInfo:any;
  usrProfile:any = [];
  usrGender:any = "M";
  avatarIndex:any = 1;
  usrAvatar:any = "assets/img/user/ava_male_2.svg";
  isPwdChange:boolean = false;
  profileHeader:string = 'My Profile';
  btnEventName:string = "Update Profile";
  ngOnInit(): void{

    this.userInfo = this.userServ.getUser();
    this.isPwdChange = (this.userInfo.verified_profile==false) ? true : false;
    this.profileHeader = (this.userInfo.verified_profile==false) ? 'Profile Verification' : 'My Profile';
    this.btnEventName = (this.userInfo.verified_profile==false) ? 'Verify Profile' : 'Update Profile';

    this.api.getProfileInfo({}).subscribe({
      next:(data)=>{
        this.usrProfile = data[0];
        this.usrGender = this.usrProfile.gender;
        this.avatarIndex = this.usrProfile.user_info;
        this.profileForm.patchValue(this.usrProfile);
        // this.isPwdChange = true;
      }
    })
  }

  get f(){
    return this.profileForm.controls;
  }

  formControlNamesMapping:any = {
    id:'ID',
    first_name:'First Name',
    last_name:'Last Name',
    email:'Email',
    username:'User Name',
    password:'Password',
    gender:'Gender',
    user_info:'Avatar'
  };

  getFieldName(fieldName: string): string {
    return this.formControlNamesMapping[fieldName] || fieldName;
  }

  changeGender(event:any){
    this.usrGender = event.target.value;
    this.avatarIndex = 1;

    if(this.usrGender =='M'){
      this.usrAvatar = "assets/img/user/ava_male_2.svg";
    }else if(this.usrGender =='F'){
      this.usrAvatar = "assets/img/user/ava_female.svg";
    }
  }

  avatarclick(event:any,index:any){
    this.avatarIndex = index;
  }

  resetPassword(event:any){
    this.isPwdChange = event.target.checked;
  }

  onSubmit(){
    if(this.profileForm.valid){
      if(this.isPwdChange){
        let usrPasswrod = this.profileForm.controls["password"].value;
        if(!usrPasswrod){
          let objj={
            'Type':2,
            'Title':'Warning',
            'Message':'Invalid Request: Password may not be left blank; please check your input!',
            'autoClose':false
          }
          this.toast.warning(objj);
          return;
        }
      }
      this.updateProfile(this.profileForm.value);
    }else{

      const controls = this.profileForm.controls;
      for (const name in controls) {
        if (controls[name].errors?.['required']) {
          let errorObj:any={
            'Type':2,
            'Title':'Warning',
            'Message':'Invalid Request: '+ '"'+this.getFieldName(name)+'"' +' is required; please double-check your input!',
            'autoClose':false
          }
          this.toast.warning(errorObj);
          return
        }
      }
      
    }
  }

  updateProfile(event:any){
    let formData = event;
    let object={
      "first_name": formData.first_name,
      "last_name": formData.last_name,
      "user_info": this.avatarIndex,
      "gender": formData.gender,
      "password": this.isPwdChange? btoa(formData.password) : '',
      "pwd_flag": this.isPwdChange,
      "id": formData.id
    }
    this.api.updateProfileInfo(object).subscribe({
      next:(res)=>{
        let objj={
          'Type':1,
          'Title':'Info',
          'Message':'Your request has been successfully updated...',
          'autoClose':false
        }
        this.toast.info(objj);

        var usrInfo = JSON.stringify(res) //JSON.stringify(res['user_info'])
        this.loginServ.updateUser(usrInfo)
        this.prfService.profileUpdateCall(this.userServ.getUser());
        if(this.userInfo.verified_profile==false){
          this.router.navigate(['home/homePage']);
        }else{
          this.isPwdChange = false;
          this.profileForm.get("password")?.setValue(null);
        }
        return;
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  gotoHome(){
    this.router.navigate(['/home/homePage']);
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
