import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { VersionhistoryComponent } from './versionhistory.component';

const routes: Routes = [{ path: '', component: VersionhistoryComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class VersionhistoryRoutingModule { }
