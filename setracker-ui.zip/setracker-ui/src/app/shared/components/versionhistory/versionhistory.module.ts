import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { VersionhistoryRoutingModule } from './versionhistory-routing.module';
import { VersionhistoryComponent } from './versionhistory.component';
import { ToastModule } from '../toast/toast.module';
import { NgxPaginationModule } from 'ngx-pagination';


@NgModule({
  declarations: [
    VersionhistoryComponent
  ],
  imports: [
    CommonModule,
    VersionhistoryRoutingModule,
    NgxPaginationModule,
    ToastModule
  ]
})
export class VersionhistoryModule { }
