import { Component, OnInit } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ApiSharedService } from '../../http/api-shared.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-versionhistory',
  templateUrl: './versionhistory.component.html',
  styleUrls: ['./versionhistory.component.scss']
})
export class VersionhistoryComponent implements OnInit {

  constructor(private api:ApiSharedService,private toast:ToastService) { }

  p:any = 1;
  versionList:any=[];
  Spinsubmitted:boolean=false;
  ngOnInit(): void {
    // this.api.getVersionhistory().subscribe(data=>{
    //   this.versionList =data;
    //   var strDataList1:any=[];
    //   var strDataList2:any=[];
    //   for(let ind in this.versionList){
    //     this.versionList[ind].function.sort((a:any,b:any) => a.function.localeCompare(b.function)); //Sorting
    //     var funcdata =this.versionList[ind].function;
    //     strDataList1=[];
    //     strDataList2=[];
    //     for(let key in funcdata){
    //       if(funcdata[key].description){

    //         strDataList1 =funcdata[key].description.split(/\r?\n\r?\n/);  //split(/\r?\n/);
    //         funcdata[key].description =strDataList1;
    //         var arrList = funcdata[key].description;
    //         var header:any=[];

    //         for(let ind in arrList){
    //           strDataList2 = arrList[ind].split(/\r?\n/);
    //           header.push(strDataList2)
    //         }
    //         funcdata[key].description = header;

    //       }
    //     }
    //   }
    // },err=>{
    //   let value:any;
    //   if (err.status!=500){
    //     for (let key in err.error) {
    //       value = key +' : '+ err.error[key];
    //     }
    //     let objj={
    //       "Type":2,
    //       "Title":'Warning',
    //       "Message":value,
    //       "autoClose":false
    //     }
    //     this.toast.error(objj)
    //   }else{
    //     let objj={
    //       "Type":3,
    //       "Title":'Error',
    //       "Message":'Failed to process your request..., Please try again later!',
    //       "autoClose":false
    //     }
    //     this.toast.error(objj)
    //   }
    // })
  }

  getVersion(){
    this.Spinsubmitted =true;
    this.api.getVersionhistory().subscribe(data=>{
      this.Spinsubmitted =false;
      this.versionList =data;
      var strDataList1:any=[];
      var strDataList2:any=[];

      for(let ind in this.versionList){
        this.versionList[ind].function.sort((a:any,b:any) => a.function.localeCompare(b.function)); //Sorting
        var funcdata =this.versionList[ind].function;
        strDataList1=[];
        strDataList2=[];
        for(let key in funcdata){
          if(funcdata[key].description){

            strDataList1 =funcdata[key].description.split(/\r?\n\r?\n/);
            funcdata[key].description =strDataList1;
            var arrList = funcdata[key].description;
            var header:any=[];

            for(let ind in arrList){
              strDataList2 = arrList[ind].split(/\r?\n/);
              header.push(strDataList2)
            }
            funcdata[key].description = header;
          }
        }
      }
    },err=>{
      this.Spinsubmitted =false;
      let value:any;
      if (err.status!=500){
        for (let key in err.error) {
          value = key +' : '+ err.error[key];
        }
        let objj={
          "Type":2,
          "Title":'Warning',
          "Message":value,
          "autoClose":false
        }
        this.toast.error(objj)
      }else{
        let objj={
          "Type":3,
          "Title":'Error',
          "Message":'Failed to process your request..., Please try again later!',
          "autoClose":false
        }
        this.toast.error(objj)
      }
    })
  }
}
