import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { LoginService } from 'src/app/core/services/login.service';
import { ApiSharedService } from 'src/app/shared/http/api-shared.service';

@Component({
  selector: 'app-pagenotfound',
  templateUrl: './pagenotfound.component.html',
  styleUrls: ['./pagenotfound.component.scss']
})
export class PagenotfoundComponent implements OnInit {

  constructor(private router:Router, private apiService:ApiSharedService, private loginService:LoginService) { }

  ngOnInit(): void {
  }

  btnBack2Login(){
    // console.log('B2L')
    this.apiService.Logout().subscribe(data =>{
      this.loginService.logout()
      this.router.navigate(['/login']);
    })
  }

}
