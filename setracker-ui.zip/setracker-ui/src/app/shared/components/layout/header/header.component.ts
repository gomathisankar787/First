import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services/user.service';
import { LoginService } from 'src/app/core/services/login.service';
import { ApiSharedService } from 'src/app/shared/http/api-shared.service';
import { Subscription } from 'rxjs';
import { ProfileService } from 'src/app/shared/services/profile.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  profileSubscrb!:Subscription;

  constructor(private router:Router, private usrService: UserService, private loginService:LoginService, private apiService: ApiSharedService,private prfService:ProfileService) { 
    this.profileSubscrb = prfService.profileUpdated$.subscribe(
      profileInfo => {
        this.usrInfo = profileInfo;
    });
  }

  usrInfo:any={};
  rlActive:any='';

  ngOnInit(): void {
    this.usrInfo = this.usrService.getUser();
  }

  signOut(){
    this.router.navigate(['/login']);
    this.apiService.Logout().subscribe(data =>{
      this.loginService.logout()
      this.router.navigate(['/login']);
    })
  }

  moveToHome(){
    this.router.navigate(['/home/homePage']);
  }
}
