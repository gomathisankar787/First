import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { environment } from 'src/environments/environment';
import { ResToken } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class ApiSharedService {
  server_api = environment.api_server;
  constructor(private httpclient: HttpClient) { }

  public checkLogin(user:any){
    return this.httpclient.post<ResToken>(`${this.server_api}/authapi/login/`,user)
  }

  Logout(){
    return this.httpclient.post(`${this.server_api}/authapi/logout/`,{})
  }

  getUserInfo(token:any){ // need to change
    return this.httpclient.post<any>(`${this.server_api}/authapi/tkn_usr_info/`,token);
  }

  getProfileInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/user_profile_view/`,obj);
  }

  updateProfileInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/upd_profile_by_user/`,obj);
  }

  //version-history
  // getVersionhistory(){
  //   return this.httpclient.get<any>(`${this.server_api}/admin_controls/ua_version_history/`);
  // }

  //auto-reload -Browser cache(refresh)
  // autoReload(){
  //   return this.httpclient.get<any>(`${this.server_api}/admin_controls/get_version/`);
  // }
}
