import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { UserModel } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor() { }

  // Observable string sources
  private profileUpdateSource = new Subject<UserModel>();
  // Observable string streams
  profileUpdated$ = this.profileUpdateSource.asObservable();
  // Service message commands
  profileUpdateCall(profile: UserModel) {
    this.profileUpdateSource.next(profile);
  }

  // private notificatioUpdateSource = new Subject<Notification>();
  // notificationUpdated$ = this.notificatioUpdateSource.asObservable();
  // notificationUpdateCall(notification: Notification){
  //   this.notificatioUpdateSource.next(notification);
  // }
}
