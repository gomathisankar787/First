import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Toast,ToastType } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  constructor() { }
  private  toastEvent= new Subject<Toast>();
  toast$ = this.toastEvent.asObservable();

  toast(toastMessage:Toast){
    this.toastEvent.next(toastMessage);
  }

  success(toastAlert:any){
    this.toast(toastAlert);
  }

  info(toastAlert:any){
    this.toast(toastAlert);
  }

  warning(toastAlert:any){
    this.toast(toastAlert);
  }

  error(toastAlert:any){
    this.toast(toastAlert);
  }

}
