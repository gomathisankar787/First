export class UserModel{
  id:number;
  email:string;
  role:string;
  first_name:string;
  last_name:string;
  gender:string;
  avatar:number;
  constructor(id:number,email:string,role:string,first_name:string,last_name:string,gender:string,avatar:number){
    this.id = id;
    this.email = email;
    this.role = role;
    this.first_name = first_name;
    this.last_name = last_name;
    this.gender = gender;
    this.avatar = avatar;
  }
}

export class ResToken{
  info:string;
  token:string;
  constructor(info:string,token:string){
    this.info = info;
    this.token = token;
  }
}

export enum Roles{
  Admin = 'Admin',
  Basic = 'Basic'
}

export class Toast{
  Type!: ToastType;
  Title!:string;
  Message!: string;
  autoClose!: boolean;
  keepAfterRouteChange!: boolean;
  fade!: boolean;

  constructor(init?:Partial<Toast>) {
    Object.assign(this, init);
  }
}

export enum ToastType {
  Success,
  Info,
  Warning,
  Error
}
