import { Component } from '@angular/core';
import  packageInfo   from '../../package.json';
import { ApiSharedService } from './shared/http/api-shared.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'spark-timehub';
  private curVersion = packageInfo.version;

  constructor(private api:ApiSharedService) { }

  ngOnInit(): void {
    // this.printLogo();
    // this.checkVersion();
  }

  printLogo(){
    // console.log("\r\n (                                           \r\n )\\ )      (              (                  \r\n(()\/(      )\\  )    (     )\\ )  (  (     (   \r\n \/(_)) (  ((_)\/((   )\\   (()\/(  )\\))(   ))\\  \r\n(_))   )\\  _ (_))\\ ((_)   ((_))((_))\\  \/((_) \r\n\/ __| ((_)| |_)((_)| __|  _| |  (()(_)(_))   \r\n\\__ \\\/ _ \\| |\\ V \/ | _| \/ _` | \/ _` | \/ -_)  \r\n|___\/\\___\/|_| \\_\/  |___|\\__,_| \\__, | \\___|  \r\n                               |___\/         \r\n")
    // console.log("Please share any constraints and issues at s-e-n-o-t-i-f-i-c-a-t-i-o-n-s-@-s-o-l-v-e-d-g-e-.-i-n");// This is for your consideration that your account may be deactivated for miscellanous activity.")
  }

  // private checkVersion() {
  //   this.api.autoReload().subscribe((response:any) =>{
  //     if(response.length>0){
  //       const version = response[0].ui_version;

  //       const hashChanged = this.hasHashChanged(this.curVersion, version);
  //       this.curVersion = version;
  //       const chkVersion =sessionStorage.getItem('versionCheck')
  //       if (hashChanged && !chkVersion) {
  //         sessionStorage.setItem('versionCheck','true')
  //         window.location.reload();
  //       }
  //     }
  //   },(err:any) =>{
  //     console.error(err, 'Could not get version');
  //   })
  // }

  private hasHashChanged(curVersion: string, newVersion: any) {
    if (!curVersion || curVersion === '{{POST_BUILD_ENTERS_HASH_HERE}}') {
      return false;
    }
    return curVersion !== newVersion;
  }
}

// test code
