import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class SharedDataService {

  constructor() { }

  private paramSource = new BehaviorSubject<any|unknown>('');
  navItem$ = this.paramSource.asObservable();
  changeNav(obj:any) {
    this.paramSource.next(obj);
  }
}
