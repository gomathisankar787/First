import { TestBed } from '@angular/core/testing';

import { ApiPrivateService } from './api-private.service';

describe('ApiPrivateService', () => {
  let service: ApiPrivateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiPrivateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
