import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http'
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiPrivateService {

  server_api = environment.api_server;

  constructor(private httpclient: HttpClient) { }

  //Active Lists
  getActiveUsers(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/act_user_list/`);
  }
  getActiveProjects(){
    return this.httpclient.get<any>(`${this.server_api}/workportal/act_project_list/`);
  }

  //home
  getTodayTaskDate(){
    return this.httpclient.get<any>(`${this.server_api}/workportal/get_today_date/`);
  }
  getTodayTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/today_timesht_list/`,obj);
  }
  getPriorTaskDate(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/get_last_task_date/`,obj);
  }
  getPriorTasks(){
    return this.httpclient.get<any>(`${this.server_api}/workportal/prv_day_task_list/`);
  }
  getOtherTasks(obj:any,params:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/selected_timesht_list/`,obj,{ params:params });
  }
  searchInTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/usr_task_search/`,obj);
  }
  getPendingTasks(obj:any,params:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/usr_incomplet_task_list`,obj,{ params:params });
  }
  //home - Create Tasks
  createTask(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/create_task/`,obj);
  }
  createPriorTask(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/create_prv_day_task/`,obj);
  }
  updateTask(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/update_task/`,obj); 
  }
  getTaskStatusInfo(){
    return this.httpclient.get<any>(`${this.server_api}/workportal/task_status_info/`);
  }
  deleteUsrTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/delete_task/`,obj)
  }

  //Timesheet - Admin
  getAdminTimesheetInfo(obj:any,params:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/admtimesht_list/`,obj,{ params:params});
  }
  adminSearchInTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/adm_task_search/`,obj);
  }
  adminCreateUsrTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/admtimesht_add/`,obj);
  }
  adminUpdateUsrTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/admtimesht_edit/`,obj);
  }
  adminExportTimesheet(obj:any){
    return this.httpclient.post<Blob>(`${this.server_api}/workportal/adm_timesheet_export/`,obj,{ observe: 'response', responseType: 'blob' as 'json' });
  }
  adminDeleteusrTasks(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/delete_task_by_adm/`,obj)
  }

  //Timesheet - User
  getUserTimesheetInfo(obj:any,params:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/usr_report_preview/`,obj,{ params:params});
  }

  //Production - Admin
  getAdminProdReport(obj:any,params:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/adm_prod_report/`,obj,{ params:params});
  }
  adminExportProduction(obj:any){
    return this.httpclient.post<Blob>(`${this.server_api}/workportal/adm_prod_excel_export/`,obj,{ observe: 'response', responseType: 'blob' as 'json' });
  }
  getUserProdDetails(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/adm_prod_detail_view/`,obj);
  }

  //Production - User
  getUserProdReport(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/user_prod_report/`,obj);
  }
  getProdDetails(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/usr_prod_detail_view/`,obj);
  }

  //Attendance - Admin
  getAttendanceInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/adm_attendance_report/`,obj);
  }

  //Attendance - User
  getUsrAttendanceInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/usr_attendance_report/ `,obj);
  }

  //Manage Users
  getUserRoles(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/rolelist/`);
  }
  getWorkShifts(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/usr_shift_info/`);
  }
  createUserInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/register/`,obj);
  }
  updateUserInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/user_update/`,obj);
  }
  getUserInfo(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/user_list/`);
  }
  getUserBiometricInfo(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/get_user_biomet_details/`,obj);
  }
  getUserBiometricDate(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/get_first_biomet_date/`,obj);
  }
  updateUserStatus(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/act_deact/`,obj);
  }
  updateTimeSheetSts(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/timeshtlist_act_deact/`,obj);
  }

  //Manage Department
  createDepartments(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/dept_create/`,obj);
  }
  updateDepartments(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/dept_update/`,obj);
  }
  getDepartmentInfo(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/dept_list/`);
  }

  //Manage Projects
  getProjectInfo(){
    return this.httpclient.get<any>(`${this.server_api}/workportal/project_list/`);
  }
  createProject(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/create_project/`,obj);
  }
  updateProject(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/update_project/`,obj);
  }

  //Settings - Holiday
  getHolidays(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/holiday_list/`);
  }
  getYearlyHolidays(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/yearly_holyday_list/`,obj);
  }
  createHoliday(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/add_holiday/`,obj);
  }
  updateHoliday(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/update_holiday/`,obj);
  }
  updateHolidayStatus(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/holidaylist_actdeact/`,obj);
  }

  //Settings - Biometric
  getBiometConfig(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/bio_database_config/`);
  }
  updUsrBiometrics(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/workportal/biometric_update_user_list/`,obj);
  }

  //Notification System
  getNotificationLists(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/notif_sys_list/`);
  }
  updateNotification(obj:any){
    return this.httpclient.post<any>(`${this.server_api}/authapi/notif_sys_update/`,obj);
  }
  getDeptUserInfo(){
    return this.httpclient.get<any>(`${this.server_api}/authapi/dept_user_list/`);
  }
}
