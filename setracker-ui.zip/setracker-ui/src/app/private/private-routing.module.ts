import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrivateComponent } from './private.component';
import { RoleGuard } from '../core/guards/role.guard';
import { Roles } from '../shared/models/user.model';
import { AuthGuard } from '../core/guards/auth.guard';

const routes: Routes = [
  { path: '',component: PrivateComponent,
    canActivate:[RoleGuard],
    children:[
      { path: 'homePage',canActivate:[RoleGuard],data:{roles:[Roles.Admin,Roles.Basic]}, loadChildren: () => import('./components/home/home.module').then(m => m.HomeModule) },
      { path: 'admin',canActivate:[RoleGuard],data:{roles:[Roles.Admin,Roles.Basic]}, loadChildren: () => import('./components/admin/admin.module').then(m => m.AdminModule) },
      { path: 'reports',canActivate:[RoleGuard],data:{roles:[Roles.Admin,Roles.Basic]}, loadChildren: () => import('./components/reports/reports.module').then(m => m.ReportsModule) },
      // { path: 'version',canActivate:[AuthGuard], loadChildren: () => import('../shared/components/versionhistory/versionhistory.module').then(m => m.VersionhistoryModule) },
      { path: 'usrprofile', loadChildren: () => import('../shared/components/profile/profile.module').then(m => m.ProfileModule) },
      { path: '', redirectTo:'homePage',pathMatch:'full'}
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrivateRoutingModule { }
