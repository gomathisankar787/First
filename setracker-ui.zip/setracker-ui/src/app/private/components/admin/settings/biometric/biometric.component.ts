import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-biometric',
  templateUrl: './biometric.component.html',
  styleUrls: ['./biometric.component.scss']
})
export class BiometricComponent {

  constructor(public datepipe:DatePipe,private api:ApiPrivateService,private toast:ToastService){}

  startDateRange:any = this.datepipe.transform(new Date(new Date().getFullYear(),new Date().getMonth(),1), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  maxiDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  selUsrDept:any;
  departmentList:any = [];
  selDeptUsr:any;
  departmentUsers:any = [];
  updateSpinner:boolean = false;
  biometricInfo:any=[];

  ngOnInit(): void{
    this.api.getBiometConfig().subscribe({
      next:(response)=>{
        this.biometricInfo = response;
      }
    })

    this.api.getDeptUserInfo().subscribe({
      next:(response)=>{
        this.departmentList = response;    
      }
    })
  }

  setMonthRange(event:any){
    let date:any = new Date(event.target.value);
    this.startDateRange =  this.datepipe.transform(new Date(event.target.value).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');

    // Calculate the end date of the month
    const nextMonth = (date.getMonth() === 11) ? 0 : date.getMonth() + 1;
    const nextYear = (nextMonth === 0) ? date.getFullYear() + 1 : date.getFullYear();
    this.maxiDate = this.datepipe.transform(new Date(nextYear, nextMonth, 0).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
    this.endDateRange = this.datepipe.transform(new Date(nextYear, nextMonth, 0).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  }

  getUserDepartment(event:any){
    if(event){
      this.selDeptUsr = null;
      let deptId = event.id;
      if(deptId!=0){
        let deptUsers = this.departmentList.filter((items:any)=> items.id == deptId);
        let Users:any = deptUsers[0].user_info;
        if(Users.length){
          this.departmentUsers = Users.filter((data:any)=> data.is_active == true);
          this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
          this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
          this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
        }else{
          let objj={
            "Type":2,
            "Title":'Warning',
            "Message":'Invalid Data: Selected department does not have any resource, Please select valid department!',
            "autoClose":false
          }
          this.toast.warning(objj);
          this.departmentUsers = [];
          return;
        }
      }
    }else{
      this.departmentUsers = [];
      this.selDeptUsr = null;
    }
  }

  updateUsrBiometric(){
    // this.updateSpinner = true;
    if(!this.selUsrDept){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Department is undefined, Please select department!',
        "autoClose":true
      }
      this.toast.warning(objj);
      // this.updateSpinner = false;
      return;
    }

    if(this.isEmptyArray(this.selDeptUsr)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource is undefined, Please select resource!',
        "autoClose":true
      }
      this.toast.warning(objj);
      // this.updateSpinner = false;
      return;
    }

    let object={
      "user_list": this.selDeptUsr,
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      }
    }
    this.api.updUsrBiometrics(object).subscribe({
      next:(response)=>{
        this.selUsrDept = null;
        this.selDeptUsr = null;
        this.updateSpinner = false;
        let alertMsg={
          'Type':1,
          'Title':'Info',
          'Message':'Your request has been successfully updated...',
          'autoClose':true
        }
        this.toast.info(alertMsg);
        return
      },error:(err)=>{
        this.updateSpinner = false;
        this.errorToast(err);
      }
    })
  }

  //*Other Events*//
  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  isEmptyArray(array: any[]): boolean {
    return array.length === 0;
  }

  //*Toast event*//
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
