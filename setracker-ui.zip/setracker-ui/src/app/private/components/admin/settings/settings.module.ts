import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsComponent } from './settings.component';
import { HolidayComponent } from './holiday/holiday.component';
import { DxDataGridModule, DxDateBoxModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { BiometricComponent } from './biometric/biometric.component';


@NgModule({
  declarations: [
    SettingsComponent,
    HolidayComponent,
    BiometricComponent
  ],
  imports: [
    CommonModule,
    SettingsRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    DxDateBoxModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  providers:[DatePipe]
})
export class SettingsModule { }
