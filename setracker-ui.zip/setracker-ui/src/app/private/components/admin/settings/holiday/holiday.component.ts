import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-holiday',
  templateUrl: './holiday.component.html',
  styleUrls: ['./holiday.component.scss']
})
export class HolidayComponent {

  searchText:any = "";
  holidayDetails:any = [];
  holidayLoader:boolean = false;
  holidayActiveStatus:any = [{ id:1, status:true, name:'Enable' },{ id:2, status:false, name:'Disable' }];
  currentYear = new Date();
  shiftLists:any = [];
  workShifts:any = [];
  wrkShiftlists:any = [];
  isEditing:boolean = true;
  selWrkShift:any;

  constructor(private api:ApiPrivateService,private toast:ToastService,public datepipe: DatePipe){}

  ngOnInit():void{
    this.api.getWorkShifts().subscribe({
      next:(response)=>{
        this.workShifts = response;
        let object={ id:0, shift_name:'All Shifts' }
        // this.shiftLists = response; // this.shiftLists.push(object);
        this.shiftLists = [object,...response];
        this.shiftLists.sort((a:any, b:any) => (a.id<b.id? -1 : 1));
      }
    })

    this.getHolidayDetails();
  }

  getHolidayDetails(){
    this.holidayLoader = true;
    let object={
      "year": this.currentYear.getFullYear(),
      "shift_id": this.selShiftId
    }
    this.api.getYearlyHolidays(object).subscribe({
      next:(response)=>{
        this.holidayDetails = response;
        this.holidayLoader = false;

        let currentYear = new Date().getFullYear();
        let previewYear = this.currentYear.getFullYear();
        if(currentYear!==previewYear){
          this.isEditing = false;
          for(let index in this.holidayDetails){
            this.holidayDetails[index]["currentYear"] = false
          }
        }else if(currentYear===previewYear){
          this.isEditing = true;
          for(let index in this.holidayDetails){
            this.holidayDetails[index]["currentYear"] = true
          }
        }
      },error:(err)=>{
        this.holidayLoader = false;
        this.errorToast(err);
      }
    })
  }

  selHolidayYear(event:any){
    this.currentYear =  new Date(event.value);
  }

  selShiftId:any = 0;
  preview(){
    this.holidayLoader = true;

    let object={
      "year": this.currentYear.getFullYear(),
      "shift_id": this.selShiftId
    }
    this.api.getYearlyHolidays(object).subscribe({
      next:(response)=>{
        this.holidayDetails = response;
        this.holidayLoader = false;

        let currentYear = new Date().getFullYear();
        let previewYear = this.currentYear.getFullYear();
        if(currentYear!==previewYear){
          this.isEditing = false;
          for(let index in this.holidayDetails){
            this.holidayDetails[index]["currentYear"] = false
          }
        }else if(currentYear===previewYear){
          this.isEditing = true;
          for(let index in this.holidayDetails){
            this.holidayDetails[index]["currentYear"] = true
          }
        }

      },error:(err)=>{
        this.holidayLoader = false;
        this.errorToast(err);
      }
    })
  }

  //Create Holiday
  holidayCreateMdl:any;
  currentDate:any =this.datepipe.transform(new Date(), 'yyyy-MM-dd');
  holidayName:any;
  holidayDesc:any;

  openCreateModel(){
    this.holidayCreateMdl = new (window as any).bootstrap.Modal(document.getElementById('holidayModelC')!)
    this.holidayCreateMdl.show();

    this.api.getWorkShifts().subscribe({
      next:(response)=>{
        this.wrkShiftlists = response;
        this.selWrkShift = this.wrkShiftlists.map((i:any) => i.id);
      }
    })
  }

  saveHoliSpinner:boolean = false;
  createHoliday(){
    this.saveHoliSpinner = true;
    if(!this.selWrkShift || !this.selWrkShift.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Shift is undefined, Please select a shift!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.saveHoliSpinner = false;
      return;
    }

    if(!this.currentDate){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.saveHoliSpinner = false;
      return;
    }

    if(!this.holidayName?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Holiday Name Is Undefined, Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.saveHoliSpinner = false;
      return
    }

    let object={
      "shift": this.selWrkShift? this.selWrkShift : [],
      "holiday_date": this.convert(this.currentDate),
      "holiday": this.holidayName,
      "desc": this.holidayDesc,
      "status": true
    }
    this.api.createHoliday(object).subscribe({
      next:(response)=>{
        this.saveHoliSpinner = false;
        this.getHolidayDetails();
        this.closeCreateModel();
      },error:(err)=>{
        this.saveHoliSpinner = false;
        this.errorToast(err);
      }
    })
  }

  closeCreateModel(){
    this.holidayCreateMdl.hide();
    this.currentDate = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
    this.holidayName = null;
    this.holidayDesc = null;
    this.selWrkShift = null;
  }

  updateHolidayStatus(event:any){
    this.api.updateHolidayStatus({"id": event.id}).subscribe({
      next:(response)=>{
        let gridInfo = this.holidayDetails.find((data:any)=> data.id == event.id)
        if(gridInfo){
          gridInfo.status = response.timeshtlist_sts;
        }
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        return
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  updateHoliday(event:any){
    this.holidayLoader = true;
    if(event.changes.length){
      var shiftId:any=[];
      var editData = event.changes[0].data;
      var dataKey = event.changes[0].key;

      let holidayName = editData.holiday? editData.holiday : dataKey.holiday;
      let holidayDate = editData.holiday_date? editData.holiday_date : dataKey.holiday_date;

      if(editData.shift_id){
        shiftId.push(editData.shift_id);
      }else{
        shiftId.push(dataKey.shift_id);
      }

      let updateObj={
        "id": dataKey.id,
        "holiday_date":this.convert(holidayDate),
        "holiday":holidayName,
        "shift":shiftId,
        "desc": dataKey.desc,
        "status": dataKey.status
      }
      this.api.updateHoliday(updateObj).subscribe({
        next:(response)=>{
          this.holidayLoader = false;
          let gridInfo = this.holidayDetails.find((data:any)=> data.id == dataKey.id)
          if(gridInfo){
            gridInfo.holiday_date = response.holiday_date;
            gridInfo.holiday = response.holiday;
            gridInfo.shift_id = [response.shift];
          }
          let objj={
            "Type":1,
            "Title":'Info',
            "Message":'Your request has been successfully updated...',
            "autoClose":true
          }
          this.toast.info(objj);
          return
        },error:(err)=>{
          this.holidayLoader = false;
          this.errorToast(err);
        }
      })
    }else{
      this.holidayLoader = false;
    }
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  searchShift(event:any,ngShift:any){
    ngShift.filter(event.target.value)
  }

  searchWrkShift(event:any,ngWrkShift:any){
    ngWrkShift.filter(event.target.value)
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
