import { Component } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent {

  constructor(){}

  ngOnInit():void{

  }

  tabHeader:string ="Holiday";
  callTabEvents(title:string){
    this.tabHeader = title
  }
}
