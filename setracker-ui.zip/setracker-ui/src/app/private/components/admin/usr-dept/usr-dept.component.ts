import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-usr-dept',
  templateUrl: './usr-dept.component.html',
  styleUrls: ['./usr-dept.component.scss']
})
export class UsrDeptComponent {

  deptLoader:boolean = false;
  searchText:any = "";
  deptDetails:any = [];
  deptActiveStatus:any = [{ id:1, status:true, name:'Active' },{ id:2, status:false, name:'In-Active' }];;

  //Department Variables
  deptCreateMdl:any;
  deptUpdateMdl:any;
  deptName:any;
  deptDesc:any;
  updateDeptName:any;
  updateDeptDesc:any;
  constructor(private api:ApiPrivateService,private toast:ToastService){}

  ngOnInit(): void{
    this.getDeptDetails();
  }

  getDeptDetails(){
    this.deptLoader = true;
    this.api.getDepartmentInfo().subscribe({
      next:(response)=>{
        this.deptDetails = response;
        this.deptLoader = false;
      },error: (err)=>{
        this.deptLoader = false;
        this.errorToast(err);
      }
    })
  }

  //Department Create
  createSpinner:boolean = false;
  openDeptModal(){
    this.deptCreateMdl = new (window as any).bootstrap.Modal(document.getElementById('exampleModalScrollableC')!)
    this.deptCreateMdl.show();
  }

  createDepartment(){
    this.createSpinner = true;
    if(!this.deptName?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Department Name Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.createSpinner = false;
      return
    }

    if(!this.deptDesc?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Description Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.createSpinner = false;
      return
    }

    let object={
      "name": this.deptName,
      "description": this.deptDesc,
      "status": true
    }
    this.api.createDepartments(object).subscribe({
      next:(response)=>{
        this.createSpinner = false;
        this.closeDeptModal();
        this.getDeptDetails();
        let objj={
          "Type":1,
          "Title":"Info",
          "Message":"Your request has been successfully created...",
          "autoClose": true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.createSpinner = false;
        this.errorToast(err);
      }
    })
  }

  closeDeptModal(){
    this.deptCreateMdl.hide();
    this.deptName = null;
    this.deptDesc = null;
  }

  //Department Update
  updDeptInfo:any = [];
  updateSpinner:boolean = false;
  openUpdDeptModal(event:any){
    this.deptUpdateMdl = new (window as any).bootstrap.Modal(document.getElementById('exampleModalScrollableU')!)
    this.deptUpdateMdl.show();
    this.updDeptInfo = event;
    this.updateDeptName = event.name;
    this.updateDeptDesc = event.description;
  }

  updateDepartment(){
    this.updateSpinner = true;

    if(!this.updateDeptName?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Department Name Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.updateSpinner = false;
      return
    }

    if(!this.updateDeptDesc?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Description Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.updateSpinner = false;
      return
    }

    let object={
      "id": this.updDeptInfo.id,
      "name": this.updateDeptName,
      "description": this.updateDeptDesc,
      "status": this.updDeptInfo.status
    }
    this.api.updateDepartments(object).subscribe({
      next:(response)=>{
        this.updateSpinner = false;
        this.closeUpdDeptModal();
        let gridInfo = this.deptDetails.find((data:any)=> data.id == response.id)
        if(gridInfo){
          gridInfo.name = response.name,
          gridInfo.description = response.description,
          gridInfo.status = response.status
        }
        let objj={
          "Type":1,
          "Title":"Info",
          "Message":"Your request has been successfully updated...",
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.updateSpinner = false;
        this.errorToast(err);
      }
    })
  }

  closeUpdDeptModal(){
    this.deptUpdateMdl.hide();
    this.updDeptInfo = [];
    this.updateDeptName = null;
    this.updateDeptDesc = null;
  }

  updateDeptStatus(event:any){
    let object={
      "id": event.id,
      "name": event.name,
      "description": event.description,
      "status": !event.status
    }
    this.api.updateDepartments(object).subscribe({
      next:(response)=>{
        let gridInfo = this.deptDetails.find((data:any)=> data.id == response.id)
        if(gridInfo){
          gridInfo.name = response.name,
          gridInfo.description = response.description,
          gridInfo.status = response.status
        }
        let objj={
          "Type":1,
          "Title":"Info",
          "Message":"Your request has been successfully updated...",
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  reload(){
    this.getDeptDetails();
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
