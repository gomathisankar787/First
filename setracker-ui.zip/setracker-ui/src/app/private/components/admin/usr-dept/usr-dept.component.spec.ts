import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsrDeptComponent } from './usr-dept.component';

describe('UsrDeptComponent', () => {
  let component: UsrDeptComponent;
  let fixture: ComponentFixture<UsrDeptComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UsrDeptComponent]
    });
    fixture = TestBed.createComponent(UsrDeptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
