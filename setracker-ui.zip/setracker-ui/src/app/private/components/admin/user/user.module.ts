import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { CreateUserComponent } from './create-user/create-user.component';
import { DxDataGridModule, DxDateBoxModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  declarations: [
    UserComponent,
    CreateUserComponent
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    DxDateBoxModule
  ]
})
export class UserModule { }
