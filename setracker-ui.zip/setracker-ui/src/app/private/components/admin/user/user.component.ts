import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { Location } from '@angular/common';
import { ToastService } from 'src/app/shared/services/toast.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent {
 
  constructor(private api:ApiPrivateService,private toast:ToastService,private router:Router,private location: Location){}

  loadingVisible:boolean = false;
  usrDetails:any = [];
  usrCreateMdl:any;

  //Default lists
  searchText:any = "";
  usrActiveStatus:any = [{ id:1, is_active:true, status:'Active' },{ id:2, is_active:false, status:'In-Active' }];
  userMailStatus = [{ 'id':1, 'active':true, 'status':'Enabled' },{ 'id':2, 'active':false, 'status':'Disabled' }];
  usrGender:any = [{ 'gender':'M', 'info':'Male' },{ 'gender':'F', 'info':'Female' }];

  ngOnInit(): void {
    this.getUserDetails();
  }

  getUserDetails(){
    this.loadingVisible = true;
    this.api.getUserInfo().subscribe({
      next: (response) => {
        this.usrDetails = response;
        this.loadingVisible = false;
      },error: (err) => {
        this.loadingVisible = false;
        this.errorToast(err);
      },
    })
  }

  updateUserStatus(event:any){
    this.api.updateUserStatus({"user_id":event.id}).subscribe({
      next:(data)=>{
        let userInfo = this.usrDetails.find((items:any)=> items.id == event.id)
        if(userInfo){
          userInfo.is_active = data.is_active;
          let userActive = data.is_active;
          var timeshtStatus = userInfo.timeshtlist_sts;
          if(userActive==false && timeshtStatus==true){
            this.api.updateTimeSheetSts({"usr_id":userInfo.id }).subscribe({
              next:(response)=>{
                userInfo.timeshtlist_sts = response.timeshtlist_sts;
              }
            })
          }
        }
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'User active status successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  moveToUsrCreatePage(){
    let object={
      formStatus: 'Create',
      formDetails: null
    }
    this.router.navigate(['/home/admin/users/Create-User'],{state: {formInfo:object} })
  }

  moveToUsrEditPage(event:any){
    let object={
      formStatus: 'Edit',
      formDetails: event
    }
    this.router.navigate(['/home/admin/users/Create-User'],{state: {formInfo:object} })
  }

  //reload
  reload(){
    this.getUserDetails();
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
