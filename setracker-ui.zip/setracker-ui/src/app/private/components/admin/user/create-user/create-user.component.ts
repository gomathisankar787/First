import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as bootstrap from 'bootstrap';
import { DatePipe, Location } from '@angular/common';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent {

  //*New User Form Fields*//
  pageHeader:string = "Create New User";
  btnEventName:string = "Submit";
  userForm!:FormGroup;
  usrGender:string = 'M';
  usrAvatar:any = "assets/img/user/ava_male_2.svg";

  userDeptList:any = [];
  biometricList:any = [];
  userWorkShifts:any = [];
  userRoleDetails:any = [];

  biometFlag:boolean = false;
  IsUserUpdate:boolean = false;
  Spinsubmitted:boolean = false;
  isPwdChange:boolean = true;
  isDatedifferent:boolean = false;

  acCreatedDate:any;
  today:Date = new Date();
  startTime:Date = new Date(this.today.getFullYear()+'/'+(this.today.getMonth()+1)+'/'+this.today.getDate() + ' ' +'10:00 AM');
  endTime:Date = new Date(this.today.getFullYear()+'/'+(this.today.getMonth()+1)+'/'+this.today.getDate() + ' ' +'7:00 PM');
  
  constructor(private fb: FormBuilder,private api:ApiPrivateService, private toast:ToastService, private router:Router,private location: Location){
    this.userForm = this.fb.group({
      id:[null],
      first_name:['',Validators.required],
      last_name:['',Validators.required],
      role:[null,Validators.required],
      dept:[null,Validators.required],
      shift:[null,Validators.required],
      bm_usr_id:[null],
      timeshtlist_sts:[true],
      email:['',[Validators.required, Validators.email]],
      username:['',Validators.required],
      password:['',Validators.required],
      pseudo_name:['']
    });
  }

  //*Form Validations*//
  get f() {
    return this.userForm.controls;
  }

  get email() {
    return this.userForm.get('email');
  }

  validateEmail(event:any){
    // if(this.IsUserUpdate == false){
    //   this.userForm.get('email')?.valueChanges.subscribe(email => {
    //     // Update the username field with email substring
    //     if (this.userForm.get('email')?.valid) {
    //       const emailSubstring = email.split('@')[0];
    //       this.userForm.patchValue({ username: emailSubstring });
  
    //       let randomPwd = this.getRandomPassword();
    //       this.userForm.get("password")?.setValue(String(randomPwd));
    //     }
    //   });
    // }
  }

  emailChange(event:any){
    let email = event.target.value;
    if(!email){
      return;
    }
    if(this.IsUserUpdate == false){
      if (this.userForm.get('email')?.valid) {
        const emailSubstring = email.split('@')[0];
        this.userForm.patchValue({ username: emailSubstring });
        let randomPwd = this.getRandomPassword();
        this.userForm.get("password")?.setValue(String(randomPwd));
      }
    }
  }

  getRandomPassword(){
    return Math.floor(100000 + Math.random() * 900000);
  }

  formControlNamesMapping:any = {
    id:'ID',
    first_name:'First Name',
    last_name:'Last Name',
    role:'Application Role',
    dept:'Department',
    shift:'Work Shift',
    bm_usr_id:'Biometric',
    timeshtlist_sts:'Timesheet Reminder',
    email:'Email',
    username:'User Name',
    password:'Password',
    pseudo_name:'Pseudo Name',
  };

  getFieldName(fieldName: string): string {
    return this.formControlNamesMapping[fieldName] || fieldName;
  }

  ngOnInit(): void {
    let pageState:any = this.location.getState();
    if (pageState.formInfo){
      this.fetchUserDetails(pageState.formInfo)
    } else{
      this.router.navigate(['/home/admin/users']);
    }

    this.api.getUserRoles().subscribe({next:(response)=>{
      this.userRoleDetails = response;
    }})

    this.api.getWorkShifts().subscribe({
      next:(response)=>{
        this.userWorkShifts = response;
      }
    })

    this.api.getDepartmentInfo().subscribe({
      next:(response)=>{
        this.userDeptList = response;
      }
    })
  }

  userDetails:any = [];
  fetchUserDetails(event:any){
    let userDetails = event.formDetails;
    this.userDetails = event.formDetails;
    this.pageHeader = (event.formStatus=='Create')? 'Create New User': 'Edit User Details';
    this.btnEventName = (event.formStatus=='Create')? 'Submit': 'Update User';
    this.IsUserUpdate = (event.formStatus=='Edit') ? true:false;
    this.isPwdChange = (event.formStatus=='Edit') ? false:true;
    
    this.acCreatedDate = (event.formStatus=='Create')? new Date(): userDetails.date_joined;

    //*Biometric Details*//
    let userCreationflag = (event.formStatus=='Create')? true : false ;
    this.api.getUserBiometricInfo({"user_creation_flag":userCreationflag}).subscribe({
      next:(data)=>{
        this.biometricList = data;
        this.biometricList.map((item:any) => item.user = `${item.id} - ${item.name}`);
      }
    })

    if(event.formStatus=="Edit"){
      this.userForm.patchValue(userDetails);

      this.userForm.get("role")?.setValue(userDetails.role_id);
      this.userForm.get("shift")?.setValue(userDetails.shift_id);
      this.userForm.get("dept")?.setValue(userDetails.dept_id);

      let userBiometId = (userDetails.bm_usr_id!=0)? userDetails.bm_usr_id : null;
      this.userForm.get("bm_usr_id")?.setValue(userBiometId);
      this.biometFlag = userBiometId? true : false;

      this.acCreatedDate = this.convert(userDetails.date_joined);
      this.startTime = new Date(this.today.getFullYear()+'/'+(this.today.getMonth()+1)+'/'+this.today.getDate() + ' ' +userDetails.shift_frm);
      this.endTime = new Date(this.today.getFullYear()+'/'+(this.today.getMonth()+1)+'/'+this.today.getDate() + ' ' +userDetails.shift_to);

      this.usrGender = userDetails.gender;
      this.avatarclick(this.usrGender,Number(userDetails.user_info));
      if(this.usrGender=='F'){
        let rdoGender = <HTMLInputElement>document.getElementById('crGenderF');
        rdoGender.checked = true;
      }
    }
  }

  avatarIndex:any=1;
  changeGender(event:any){
    this.usrGender = event.target.value;
    this.avatarIndex=1;
  }

  avatarclick(event:any,index:number){
    this.avatarIndex = index;
  }

  getShiftTiming(event:any){
    var today = new Date();
    this.startTime = new Date(today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate() + ' ' + event.shift_timing_from );
    this.endTime = new Date(today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate() + ' ' + event.shift_timing_to );
  }

  startTimerange(event:any){
    this.startTime = event.value;
  }

  endTimerange(event:any){
    this.endTime = event.value;
  }

  getBiometricDate(event:any){
    this.api.getUserBiometricDate({"biomet_id": event.id}).subscribe({
      next:(response)=>{
        this.acCreatedDate = response.date;
      }
    })
  }

  emailTrigger(event:any){
    if(this.IsUserUpdate==true){
      if(this.userDetails.is_active==false){
        let sheetSts = <HTMLInputElement>document.getElementById('flexSwitchCheckChecked-N');
        sheetSts.checked = false;
        let obj={
          "Type":2,
          "Title":'Warning',
          "Message":'Invalid request: User is In-active,You can'+"'"+'t change timesheet reminder!'
        }
        this.toast.warning(obj)
        return;
      }
    }
  }

  resetPassword(eve:any){
    this.isPwdChange = (eve.target.checked == true)? true:false;
    this.userForm.get("password")?.setValue(null);
  }

  onSubmit(){
    this.Spinsubmitted = true;
    let formInfo = this.userForm.value;
    if(this.IsUserUpdate){
      this.updateUser(formInfo);
    }else{
      if (this.userForm.valid) {//*Valid Form*//
        this.createUser(formInfo);
      }else {//*Invalid Form*//

        const controls = this.userForm.controls;
        for (const name in controls) {
          if (controls[name].errors?.['required']) {
            let errorObj:any={
              'Type':2,
              'Title':'Warning',
              'Message':'Invalid Request: '+ '"'+this.getFieldName(name)+'"' +' is required; please double-check your input!',
              'autoClose':false
            }
            this.toast.warning(errorObj);
            this.Spinsubmitted = false;
            return
          }
        }
      }
    }
  }

  createUser(event:any){
    this.Spinsubmitted = true;
    let formData = event;
    const datepipe: DatePipe = new DatePipe('en-US')
    let fromDate = datepipe.transform(this.startTime, 'h:mm a')
    let toDate = datepipe.transform(this.endTime, 'h:mm a')
    var joinedDate = this.convert(this.acCreatedDate);//new Date(this.acCreatedDate).toISOString();
    this.biometFlag = (formData.bm_usr_id)? true : false;

    let object={
      "first_name": formData.first_name,
      "last_name": formData.last_name,
      "gender": this.usrGender,
      "user_info": String(this.avatarIndex),
      "pseudo_name": formData.pseudo_name,
      "dept":formData.dept,
      "role": formData.role,
      "timeshtlist_sts": formData.timeshtlist_sts,
      "shift": formData.shift,
      "shift_frm": fromDate,
      "shift_to": toDate,
      "bm_usr_id":formData.bm_usr_id,
      "date_joined":joinedDate,
      "bio_date_flag": this.biometFlag,
      "email": formData.email,
      "username": formData.username,
      "password": btoa(formData.password) //random password
    }
    this.api.createUserInfo(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Successfully user created...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.Spinsubmitted = false;
        this.resetFormDetails();
      },error:(err)=>{
        this.Spinsubmitted = false;
        this.errorToast(err);
      }
    })
  }

  updateUser(event:any){
    this.Spinsubmitted = true;

    let formData = event;
    const datepipe: DatePipe = new DatePipe('en-US')
    let fromDate = datepipe.transform(this.startTime, 'h:mm a')
    let toDate = datepipe.transform(this.endTime, 'h:mm a')
    let userPassword = this.isPwdChange? btoa(formData.password):"";
    this.biometFlag = (formData.bm_usr_id)? true : false;

    if(this.isPwdChange){
      const controls = this.userForm.controls;
      for (const name in controls) {
        if (controls[name].errors?.['required']) {
          let errorObj:any={
            'Type':2,
            'Title':'Warning',
            'Message':'Invalid Request: '+ '"'+this.getFieldName(name)+'"' +' is required; please double-check your input!',
            'autoClose':false
          }
          this.toast.warning(errorObj);
          this.Spinsubmitted = false;
          return
        }
      }
    }else{
      if(this.userForm.controls["first_name"].invalid ||this.userForm.controls["last_name"].invalid||this.userForm.controls["email"].invalid){
        const controls = this.userForm.controls;
        for (const name in controls) {
          if (controls[name].invalid) {
            let objj={
              'Type':2,
              'Title':'Warning',
              'Message':'Invalid Request: '+ '"'+this.getFieldName(name)+'"' +' cannot be left blank; please double-check your input!',
              'autoClose':false
            }
            this.toast.warning(objj);
            this.Spinsubmitted = false;
            return;
          }
        }
      }
    }

    let object={
      "id": formData.id,
      "first_name": formData.first_name,
      "last_name": formData.last_name,
      "role": formData.role,
      "gender": this.usrGender,
      "dept": formData.dept,
      "user_info": String(this.avatarIndex),
      "pseudo_name": formData.pseudo_name,
      "timeshtlist_sts": formData.timeshtlist_sts,
      "shift": formData.shift,
      "shift_frm": fromDate,
      "shift_to": toDate,
      "bm_usr_id": formData.bm_usr_id,
      "bio_date_flag": this.biometFlag,
      "email": formData.email,
      "username": formData.username,
      "pwd_flag": this.isPwdChange,
      "password": userPassword
    }
    this.api.updateUserInfo(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.Spinsubmitted = false;
        this.resetUpdateformDetails();
      },error:(err)=>{
        this.Spinsubmitted = false;
        this.errorToast(err);
      }
    })
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  gotoUserPage(){
    this.router.navigate(['/home/admin/users']);
  }

  //*Other Events*//
  resetFormDetails(){
    this.userForm.reset();
    this.usrGender = "M";
    this.avatarIndex = 1;

    let genderRadioM = <HTMLInputElement>document.getElementById("crGenderM")
    genderRadioM.checked = true;

    let genderRadioF = <HTMLInputElement>document.getElementById("crGenderF")
    genderRadioF.checked = false;

    if(!this.IsUserUpdate){
      this.userForm.get('timeshtlist_sts')?.setValue(true);
    }

    var today = new Date();
    this.startTime = new Date(today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate() + ' ' +'10:00 AM');
    this.endTime = new Date(today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate() + ' ' +'7:00 PM');
  }

  resetUpdateformDetails(){
    this.isPwdChange = false;
    this.userForm.get("password")?.setValue(null);
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchRole(event:any,ngRole:any){
    ngRole.filter(event.target.value)
  }

  searchShift(event:any,ngShift:any){
    ngShift.filter(event.target.value)
  }

  searchBiomet(event:any,ngBiomet:any){
    ngBiomet.filter(event.target.value);
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
