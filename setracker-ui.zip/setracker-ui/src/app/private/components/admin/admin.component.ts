import { Component, OnInit } from '@angular/core';
import { ApiPrivateService } from '../../http/api-private.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
