import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { UsrProjectsComponent } from './usr-projects/usr-projects.component';
import { UsrDeptComponent } from './usr-dept/usr-dept.component';
import { DxDataGridModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AdminComponent,
    UsrProjectsComponent,
    UsrDeptComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class AdminModule { }
