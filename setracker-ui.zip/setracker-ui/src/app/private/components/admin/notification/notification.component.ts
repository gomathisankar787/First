import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService){}

  notificationDetails:any = [];
  tabId:any=1;
  activeTabIndex: number = 0;
  tabTitleHeader:any;
  istimeSheet:boolean = false;
  resourcesList:any = [];

  //email config
  corresName:any;
  emailStsTrigger:boolean = true;
  departmentUsers:any = [];

  //email TO
  emailToUsers:any;
  emailTOLoader:boolean = false;
  toDeptList:any = [];
  toResourceList:any = [];

  //email CC
  emailCCUsers:any;
  emailCCLoader:boolean = false;
  ccDeptList:any = [];
  ccResourceList:any = [];

  ngOnInit():void{
    this.api.getNotificationLists().subscribe({
      next:(response)=>{
        this.notificationDetails = response.sort((a:any,b:any) => a.order_id>b.order_id? 1 : -1);
        this.corresName = this.notificationDetails[0].correspondance_name;
        this.emailToUsers = this.notificationDetails[0].to_list;
        this.emailCCUsers = this.notificationDetails[0].cc_list;
        this.emailStsTrigger = this.notificationDetails[0].status;
        let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
        let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
        // console.log(this.emailStsTrigger)
        emailStatusA.checked = (this.emailStsTrigger== true) ? true: false;
        emailStatusB.checked = (this.emailStsTrigger== false) ? true: false;

        this.istimeSheet = this.notificationDetails[0].is_to_list;
      },error:(err)=>{
        this.errorToast(err);
      }
    })

    this.api.getDepartmentInfo().subscribe({
      next:(response)=>{
        this.toDeptList = response;
        this.ccDeptList = response;
      }
    })

    this.api.getDeptUserInfo().subscribe({
      next:(response)=>{
        this.departmentUsers = response;
      }
    })
  }

  openNewtab(id: number, displayName: string, isToList: boolean, index: number): void {
    this.activeTabIndex = index; // Update the active tab index

    this.tabId = id; this.tabTitleHeader = displayName; this.istimeSheet = isToList;
    this.CCDepartmentId = null; this.TODepartmentId = null;
    let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
    let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
    this.emailToUsers = []; 
    //CC List
    this.CCResourceId = null;
    this.ccResourceList = []; this.emailCCUsers = [];

    this.api.getNotificationLists().subscribe({
      next:(response)=>{
        this.notificationDetails = response.sort((a:any,b:any) => a.order_id>b.order_id? 1 : -1);
        let currentNotification = this.notificationDetails.find((items:any) => items.id == this.tabId);
        if(currentNotification){
          this.corresName = currentNotification.correspondance_name;
          this.emailToUsers = currentNotification.to_list;
          this.emailCCUsers = currentNotification.cc_list;
          this.emailStsTrigger = currentNotification.status;
          
          emailStatusA.checked = this.emailStsTrigger ? true: false;
          emailStatusB.checked = this.emailStsTrigger ? false: true;
          this.istimeSheet = currentNotification.is_to_list;
        }
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  //Email Trigger
  emailTriggerMdl:any;
  changeStatus(event:any){
    this.emailTriggerMdl = new (window as any).bootstrap.Modal(document.getElementById('TriggerModel')!)
    this.emailTriggerMdl.show();
    this.emailStsTrigger = event.target.value;
  }

  updateEmailStatus(){
    let emailTabId = this.notificationDetails.find((items:any) => items.id == this.tabId)
    let emailToRef:any;
    let emailCCRef:any = [];

    //emailTrigger
    let emailsts = <HTMLInputElement>document.getElementById('inlineRadio1');
    this.emailStsTrigger = (emailsts.checked==true)? true:false;

    //to list
    this.emailToUsers = this.emailToUsers? this.emailToUsers : "";
    emailToRef = this.istimeSheet ? JSON.stringify(this.emailToUsers): this.emailToUsers;

    //cc list
    if(this.emailCCUsers){
      for(var i=0;i<this.emailCCUsers.length;i++){
        let obj={
          "id":i+1,
          "email":this.emailCCUsers[i].email,
          "usr_id":this.emailCCUsers[i].usr_id,
          "name":this.emailCCUsers[i].name
        }
        emailCCRef.push(obj)
      }
    }else{
      emailCCRef = []
    }

    let object={
      "id": emailTabId.id,
      "status": this.emailStsTrigger,
      "cc_list": emailCCRef,
      "to_list": emailToRef,
      "correspondance_name": this.corresName
    }
    this.api.updateNotification(object).subscribe({
      next:(response)=>{
        this.emailStsTrigger = response.status;
        let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
        let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
        emailStatusA.checked = this.emailStsTrigger ? true: false;
        emailStatusB.checked = this.emailStsTrigger ? false: true;
        this.emailTriggerMdl.hide();

        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.closeStsModel();
        this.errorToast(err);
      }
    })
  }

  closeStsModel(){
    this.emailTriggerMdl.hide();
    //check if email trigger sts changed
    this.api.getNotificationLists().subscribe({
      next:(response)=>{
        this.notificationDetails = response.sort((a:any,b:any) => a.order_id>b.order_id? 1 : -1);
        let currentNotification = this.notificationDetails.find((items:any) => items.id == this.tabId);
        if(currentNotification){
          this.corresName = currentNotification.correspondance_name;
          this.emailToUsers = currentNotification.to_list;
          this.emailCCUsers = currentNotification.cc_list;
          this.emailStsTrigger = currentNotification.status;
          let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
          let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
          emailStatusA.checked = this.emailStsTrigger ? true: false;
          emailStatusB.checked = this.emailStsTrigger ? false: true;
          this.istimeSheet = currentNotification.is_to_list;
        }
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  //Email TO Configuration
  TODepartmentId:any;
  TOResourceId:any;
  emailTOReference:any = [];
  selectToDepartment(event:any){
    // this.TODepartmentId = event.target.value;
    this.TOResourceId = null;  this.toResourceList = [];
    let deptUsers = this.departmentUsers.filter((items:any)=> items.id == this.TODepartmentId)
    if(deptUsers){
      let Users:any = deptUsers[0].user_info;
      if(Users.length>0){
        this.toResourceList = Users.filter((data:any)=> data.is_active == true);
        this.toResourceList.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
        this.toResourceList.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
      }else{
        let resourceA = <HTMLSelectElement>document.getElementById("iptResourceA");
        resourceA.value = "0";
        let objj={
          "Type":2,
          "Title":'Warning',
          "Message":'Invalid Data: Selected department does not have any resource,Please select valid department!',
          "autoClose":false
        }
        this.toast.warning(objj);
        this.toResourceList = [];
        return;
      }
    }else{
      this.toResourceList = [];
    }
  }

  selectToResource(event:any){
    if(!this.TODepartmentId){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Data: Department is undefined, Please select department!',
        "autoClose":false
      }
      this.toast.warning(objj)
      return;
    }

    // let resourceId = event.target.value;
    this.emailTOReference = [];
    var resource = this.toResourceList.find((data:any) => data.id == this.TOResourceId)
    if(resource){
      let obj={ 
        'usr_id':resource.id,
        'name':resource.first_name+' '+resource.last_name,
        'email':resource.email
      }
      this.emailTOReference.push(obj);
    }
  }

  addTOUserList(){
    this.emailTOLoader = true;
    if(this.emailTOReference==undefined||this.emailTOReference==""||this.emailTOReference==null){
      let objj={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: Resource Not Defined; Please Specify a Resource!',
        'autoCloase':false
      }
      this.toast.warning(objj);
      this.emailTOLoader = false;
      return
    }

    let emailTOKeyID = this.notificationDetails.find((items:any) => items.id == this.tabId)
    let emailToRef:any = []; let emailCCRef:any = [];

    //TO List
    if(this.emailToUsers){
      let emailName = this.emailToUsers.find((element:any)=> element.email == this.emailTOReference[0].email)
      if(emailName){
        let objj={
          'Type':2,
          'Title':'Warning',
          'Message':'Email is already exists...,Please try different email!',
          'autoCloase':false
        }
        this.toast.warning(objj)
        this.emailTOLoader =false;
        return
      }
      this.emailToUsers.push(this.emailTOReference[0])
    }else{
      this.emailToUsers = []
      this.emailToUsers.push(this.emailTOReference[0]);
    }

    for(let ki=0;ki<this.emailToUsers.length;ki++){
      let obj={
        "id":ki+1,
        "email":this.emailToUsers[ki].email,
        "usr_id":this.emailToUsers[ki].usr_id,
        "name":this.emailToUsers[ki].name,
      }
      emailToRef.push(obj)
    }

    //CC List
    if(this.emailCCUsers){
      for(var i=0;i<this.emailCCUsers.length;i++){
        let obj={
          "id":i+1,
          "email":this.emailCCUsers[i].email,
          "usr_id":this.emailCCUsers[i].usr_id,
          "name":this.emailCCUsers[i].name
        }
        emailCCRef.push(obj)
      }
    }else{
      emailCCRef = [];
    }

    let object={
      'id': emailTOKeyID.id,
      'to_list':emailToRef,
      'cc_list':emailCCRef,
      'status':this.emailStsTrigger,
      'correspondance_name':this.corresName
    }
    this.api.updateNotification(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.emailTOLoader = false;
        this.reloadEmailTOConfigData();
      },error:(err)=>{
        this.errorToast(err);
        this.emailTOLoader = false;
      }
    })
  }

  reloadEmailTOConfigData(){
    this.emailTOReference = []; this.toResourceList = [];
    this.TODepartmentId = null; this.TOResourceId = null;

    //check if email trigger sts changed
    this.api.getNotificationLists().subscribe({
      next:(response)=>{
        this.notificationDetails = response.sort((a:any,b:any) => a.order_id>b.order_id? 1 : -1);
        let currentNotification = this.notificationDetails.find((items:any) => items.id == this.tabId);
        if(currentNotification){
          this.corresName = currentNotification.correspondance_name;
          this.emailToUsers = currentNotification.to_list;
          this.emailCCUsers = currentNotification.cc_list;
          this.emailStsTrigger = currentNotification.status;
          let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
          let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
          emailStatusA.checked = this.emailStsTrigger ? true: false;
          emailStatusB.checked = this.emailStsTrigger ? false: true;
          this.istimeSheet = currentNotification.is_to_list;
        }
      },error:(err)=>{
        this.errorToast(err);
      }
    })

    // this.api.getNotificationById({"id":this.tabId}).subscribe(data=>{
    //   this.correspondanceName = data[0].correspondance_name;
    //   this.emailTo = data[0].to_list;
    //   if(this.istimeSheet==true && this.emailTo){
    //     this.emailTo.forEach((element:any,i:number) => {
    //       var user = this.userList.find((data:any) => data.id ===this.emailTo[i].usr_id)
    //       if(user){
    //         this.emailTo[i]['email'] = user.email
    //       }
    //     });
    //     this.toList = this.emailTo;
    //   }

    //   this.userEmail = data[0].cc_list;
    //   this.userEmail.forEach((element:any,i:number) => { //new change
    //     var user = this.userList.find((data:any) => data.id === this.userEmail[i].usr_id)
    //     if(user){
    //       this.userEmail[i]['email'] = user.email
    //     }
    //   });

    // })
  }

  //Remove TO Llist
  emailRemoveMdlA:any;
  selEmailTOInfo:any;
  openRemModelA(event:any){
    this.emailRemoveMdlA = new (window as any).bootstrap.Modal(document.getElementById('TORemoveModel')!)
    this.emailRemoveMdlA.show();
    this.selEmailTOInfo = event;
  }

  updateEmailTO(){
    this.emailTOLoader = true;
    let emailCCRef:any = []; let emailTORef:any = [];
    let emailCCKeyID = this.notificationDetails.find((items:any) => items.id == this.tabId)

    if(this.emailToUsers){
      var index = this.emailToUsers.findIndex((elem:any) => elem.id == this.selEmailTOInfo.id);
      if(index>=0){
        this.emailToUsers.splice(index,1);
        for(var i=0;i<this.emailToUsers.length;i++){
          let obj={
            "id":i+1,
            "email":this.emailToUsers[i].email,
            "usr_id":this.emailToUsers[i].usr_id,
            "name":this.emailToUsers[i].name,
            "timeshtlist_sts":this.emailToUsers[i].timeshtlist_sts
          }
          emailTORef.push(obj)
        }
      }
    }else{
      emailTORef='';
    }

    if(this.emailCCUsers){
      for(var i=0;i<this.emailCCUsers.length;i++){
        let obj={
          "id":i+1,
          "email":this.emailCCUsers[i].email,
          "usr_id":this.emailCCUsers[i].usr_id,
          "name":this.emailCCUsers[i].name
        }
        emailCCRef.push(obj)
      }
    }else{
      emailCCRef = [];
    }

    let object = {
      'id': emailCCKeyID.id,
      'to_list': JSON.stringify(emailTORef),
      'cc_list': emailCCRef,
      'status': this.emailStsTrigger,
      'correspondance_name': this.corresName
    }
    this.api.updateNotification(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.emailTOLoader = false;
        this.emailRemoveMdlA.hide();
      },error:(err)=>{
        this.emailTOLoader = false;
        this.emailRemoveMdlA.hide();
        this.errorToast(err);
      }
    })
  }

  closeRemModelA(){
    this.emailRemoveMdlA.hide();
  }

  //Email CC Configuration
  CCDepartmentId:any;
  CCResourceId:any;
  emailCCReference:any = [];
  selectCcDepartment(event:any){
    // this.CCDepartmentId = event.target.value;
    this.CCResourceId = null; this.ccResourceList = [];
    let deptUsers = this.departmentUsers.filter((items:any)=> items.id == this.CCDepartmentId)
    if(deptUsers){
      let Users:any = deptUsers[0].user_info;
      if(Users.length>0){
        this.ccResourceList = Users.filter((data:any)=> data.is_active == true);
        this.ccResourceList.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
        this.ccResourceList.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
      }else{
        let resourceB = <HTMLSelectElement>document.getElementById("iptResourceB");
        resourceB.value = "0";
        let objj={
          "Type":2,
          "Title":'Warning',
          "Message":'Invalid Data: Selected department does not have any resource,Please select valid department!',
          "autoClose":false
        }
        this.toast.warning(objj);
        this.ccResourceList = [];
        return;
      }
    }else{
      this.ccResourceList = [];
    }
  }

  selectCcResource(event:any){
    if(!this.CCDepartmentId){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Data: Department is undefined, Please select department!',
        "autoClose":false
      }
      this.toast.warning(objj)
      return;
    }

    // let resourceId = event.target.value;
    this.emailCCReference = [];

    var resource = this.ccResourceList.find((data:any) => data.id == this.CCResourceId)
    if(resource){
      let obj={ 
        'usr_id':resource.id,
        'name': resource.first_name +' '+resource.last_name,
        'email':resource.email
      }
      this.emailCCReference.push(obj);
    }
  }

  addCCUserList(){
    this.emailCCLoader = true;
    if(this.emailCCReference==undefined||this.emailCCReference==""||this.emailCCReference==null){
      let objj={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: Resource Not Defined; Please Specify a Resource!',
        'autoCloase':false
      }
      this.toast.warning(objj);
      this.emailCCLoader = false;
      return
    }
    
    let emailCCKeyID = this.notificationDetails.find((items:any) => items.id == this.tabId)
    let emailToRef = this.istimeSheet? JSON.stringify(this.emailToUsers): this.emailToUsers;
    let emailCCRef:any = [];

    if(this.emailCCUsers){
      let emailName = this.emailCCUsers.find((element:any)=> element.email == this.emailCCReference[0].email)
      if(emailName){
        this.emailCCLoader = false;
        let objj={
          'Type':2,
          'Title':'Warning',
          'Message':'Email is already exists...,Please try different email!',
          'autoCloase':false
        }
        this.toast.warning(objj)
        return
      }
      this.emailCCUsers.push(this.emailCCReference[0])
    }else{
      this.emailCCUsers = this.emailCCReference[0];
    }

    for(var i=0;i<this.emailCCUsers.length;i++){
      let obj={
        "id":i+1,
        "email":this.emailCCUsers[i].email,
        "usr_id":this.emailCCUsers[i].usr_id,
        "name": this.emailCCUsers[i].name
      }
      emailCCRef.push(obj)
    }

    let object={
      'id': emailCCKeyID.id,
      'to_list':emailToRef,
      'cc_list':emailCCRef,
      'status':this.emailStsTrigger,
      'correspondance_name':this.corresName
    }
    this.api.updateNotification(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.emailCCLoader = false;
        this.reloadEmailCCConfigData();
      },error:(err)=>{
        this.errorToast(err);
        this.emailCCLoader = false;
      }
    })
  }

  reloadEmailCCConfigData(){
    this.emailCCReference = []; this.ccResourceList = [];
    this.CCDepartmentId = null; this.CCResourceId = null;
    this.emailCCUsers = [];

    //check if email trigger sts changed
    this.api.getNotificationLists().subscribe({
      next:(response)=>{
        this.notificationDetails = response.sort((a:any,b:any) => a.order_id>b.order_id? 1 : -1);
        let currentNotification = this.notificationDetails.find((items:any) => items.id == this.tabId);
        if(currentNotification){
          this.corresName = currentNotification.correspondance_name;
          this.emailToUsers = currentNotification.to_list;
          this.emailCCUsers = currentNotification.cc_list;
          this.emailStsTrigger = currentNotification.status;
          let emailStatusA = <HTMLInputElement>document.getElementById("inlineRadio1");
          let emailStatusB = <HTMLInputElement>document.getElementById("inlineRadio2");
          emailStatusA.checked = this.emailStsTrigger ? true: false;
          emailStatusB.checked = this.emailStsTrigger ? false: true;
          this.istimeSheet = currentNotification.is_to_list;
        }
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  //Remove CC Llist
  emailRemoveMdlB:any;
  selEmailCCInfo:any;
  openRemModelB(event:any){
    this.emailRemoveMdlB = new (window as any).bootstrap.Modal(document.getElementById('CCRemoveModel')!)
    this.emailRemoveMdlB.show();
    this.selEmailCCInfo = event;
  }

  updateEmailCC(){
    this.emailCCLoader = true;
    let emailCCRef:any = [];
    let emailCCKeyID = this.notificationDetails.find((items:any) => items.id == this.tabId)
    let emailTORef = this.istimeSheet? JSON.stringify(this.emailToUsers): this.emailToUsers;

    if(this.emailCCUsers!=null||this.emailCCUsers!=undefined||this.emailCCUsers!=""){
      var index = this.emailCCUsers.findIndex((elem:any) => elem.id == this.selEmailCCInfo.id)
      if(index>=0){
        this.emailCCUsers.splice(index,1);
        for(var i=0;i<this.emailCCUsers.length;i++){
          let obj={
            "id":i+1,
            "email":this.emailCCUsers[i].email,
            "usr_id":this.emailCCUsers[i].usr_id,
            "name":this.emailCCUsers[i].name
          }
          emailCCRef.push(obj)
        }
      }
    }

    if(emailCCRef==undefined||emailCCRef==""||emailCCRef==null){
      emailCCRef = [];
    }

    let object = {
      'id': emailCCKeyID.id,
      'to_list': emailTORef,
      'cc_list': emailCCRef,
      'status': this.emailStsTrigger,
      'correspondance_name': this.corresName
    }
    this.api.updateNotification(object).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":true
        }
        this.toast.info(objj);
        this.emailCCLoader = false;
        this.emailRemoveMdlB.hide();
      },error:(err)=>{
        this.emailCCLoader = false;
        this.emailRemoveMdlB.hide();
        this.errorToast(err);
      }
    })
  }

  closeRemModelB(){
    this.emailRemoveMdlB.hide();
  }

  //Other Events
  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
