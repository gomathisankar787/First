import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NotificationRoutingModule } from './notification-routing.module';
import { NotificationComponent } from './notification.component';
import { DxDataGridModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    NotificationComponent
  ],
  imports: [
    CommonModule,
    NotificationRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule
  ]
})
export class NotificationModule { }
