import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { UsrDeptComponent } from './usr-dept/usr-dept.component';
import { UsrProjectsComponent } from './usr-projects/usr-projects.component';

const routes: Routes = [
  // { path: '', component: AdminComponent },
  { path:'', redirectTo:'/users',pathMatch:'full' },
  { path:'projects', component:UsrProjectsComponent },
  { path:'user-Dept', component:UsrDeptComponent },
  { path: 'users', loadChildren: () => import('./user/user.module').then(m => m.UserModule) },
  { path: 'settings', loadChildren: () => import('./settings/settings.module').then(m => m.SettingsModule) },
  { path: 'notification', loadChildren: () => import('./notification/notification.module').then(m => m.NotificationModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
