import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-usr-projects',
  templateUrl: './usr-projects.component.html',
  styleUrls: ['./usr-projects.component.scss']
})
export class UsrProjectsComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService){}

  projLoader:boolean = false;
  projectDetails:any = [];
  projectActiveStatus:any = [{ id:1, status:true, name:'Active' },{ id:2, status:false, name:'In-Active' }];
  searchText:any = "";

  projectName:any;
  projectDesc:any;

  ngOnInit():void{
    this.getProjectDetails();
  }

  getProjectDetails(){
    this.projLoader = true;
    this.api.getProjectInfo().subscribe({
      next:(response)=>{
        this.projectDetails = response;
        this.projLoader = false;
      },error:(err)=>{
        this.projLoader = false;
        this.errorToast(err);
      }
    })
  }

  //Project Creation
  projCreateMdl:any;
  createSpinner:boolean = false;
  openProjectModal(){
    this.projCreateMdl = new (window as any).bootstrap.Modal(document.getElementById('projCreateModel')!)
    this.projCreateMdl.show();
  }

  createProject(){
    this.createSpinner = true;

    if(!this.projectName?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Project Name Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.createSpinner = false;
      return
    }

    if(!this.projectDesc?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Description Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.createSpinner = false;
      return
    }

    let object={
      "name": this.projectName,
      "desc": this.projectDesc,
      "status": true
    }
    this.api.createProject(object).subscribe({
      next:(response)=>{
        this.createSpinner = false;
        this.closeProjectModal();
        this.getProjectDetails();
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  closeProjectModal(){
    this.projCreateMdl.hide();
    this.projectName = null;
    this.projectDesc = null;
  }

  //Project Updation
  projUpdateMdl:any;
  updProjectInfo:any = [];
  updateProjectName:any;
  updateProjectDesc:any;
  updateSpinner:boolean = false;
  openUpdProjModal(event:any){
    this.projUpdateMdl = new (window as any).bootstrap.Modal(document.getElementById('projUpdateModel')!)
    this.projUpdateMdl.show();
    this.updProjectInfo = event;
    this.updateProjectName = event.name;
    this.updateProjectDesc = event.desc;
  }

  updateProject(){
    this.updateSpinner = true;

    if(!this.updateProjectName?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Project Name Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.updateSpinner = false;
      return
    }

    if(!this.updateProjectDesc?.trim()){
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Description Is Undefined,Please enter a valid data!",
        "autoClose":false
      }
      this.toast.warning(objj);
      this.updateSpinner = false;
      return
    }

    let object={
      "id": this.updProjectInfo.id,
      "name": this.updateProjectName,
      "desc": this.updateProjectDesc,
      "status": this.updProjectInfo.status
    }
    this.api.updateProject(object).subscribe({
      next:(response)=>{
        this.updateSpinner = false;
        this.closeUpdProjModal();
        let gridInfo = this.projectDetails.find((data:any)=> data.id == response.id)
        if(gridInfo){
          gridInfo.name = response.name,
          gridInfo.desc = response.desc,
          gridInfo.status = response.status
        }
        let objj={
          "Type":1,
          "Title":"Info",
          "Message":"Your request has been successfully updated...",
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.updateSpinner = false;
        this.errorToast(err);
      }
    })
  }

  closeUpdProjModal(){
    this.projUpdateMdl.hide();
    this.updProjectInfo = [];
    this.updateProjectName = null;
    this.updateProjectDesc = null;
  }

  updateProjStatus(event:any){
    let object={
      "id": event.id,
      "name": event.name,
      "desc": event.desc,
      "status": !event.status
    }
    this.api.updateProject(object).subscribe({
      next:(response)=>{
        let gridInfo = this.projectDetails.find((data:any)=> data.id == response.id)
        if(gridInfo){
          gridInfo.name = response.name,
          gridInfo.desc = response.desc,
          gridInfo.status = response.status
        }
        let objj={
          "Type":1,
          "Title":"Info",
          "Message":"Your request has been successfully updated...",
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  reload(){
    this.getProjectDetails();
  }

  //Toast event
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
