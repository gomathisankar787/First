import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { DxDataGridModule, DxDateBoxModule, DxLoadPanelModule } from 'devextreme-angular';
import { CreateTaskComponent } from './create-task/create-task.component';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    HomeComponent,
    CreateTaskComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    DxDateBoxModule
  ],
  providers:[DatePipe]
})
export class HomeModule { }
