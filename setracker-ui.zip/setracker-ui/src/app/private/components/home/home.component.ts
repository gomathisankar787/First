import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/core/services/user.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import { ApiPrivateService } from '../../http/api-private.service';
import { CreateTaskComponent } from './create-task/create-task.component';
import * as bootstrap from 'bootstrap';
import { DatePipe } from '@angular/common';
import CustomStore from 'devextreme/data/custom_store';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  @ViewChild(CreateTaskComponent) childComponent!: CreateTaskComponent;

  constructor(private api:ApiPrivateService,private toast:ToastService,private userServ:UserService,public datepipe:DatePipe) {
  }

  userInfo:any;
  tabHeader:any = "Today";
  taskDate:any = new Date();

  //*Today Tasks*//
  todayTasks:any = [];
  loadingVisibleA:boolean = false;
  isTaskUpdate:boolean = false;

  //*Prior Tasks*//
  priorTasks:any = [];
  loadingVisibleB:boolean = false;
  isPriorTaskUpdate:boolean = false;
  priorDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');

  //*All Tasks*//
  loadingVisibleC:boolean = false;
  userTasks:any = [];
  userTasksList:any = [];
  taskStartDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  taskEndDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');

  ngOnInit(): void {
    this.userInfo = this.userServ.getUser();
    this.getUserTodayTasks(); 
  }

  switchTab(tab:any){
    this.tabHeader = tab;
    (this.tabHeader=='Today') ? this.getUserTodayTasks() :  (this.tabHeader=='Prior'? this.getUserPriorTasks(): this.getUserTasks());
  }

  //*TODAY*//
  getUserTodayTasks(){
    this.loadingVisibleA = true;
    this.api.getTodayTaskDate().subscribe({
      next:(response)=>{        
        this.taskDate = response.today_date;
      }
    })

    this.api.getTodayTasks({"user_id":this.userInfo.id}).subscribe({
      next:(response)=>{
        this.todayTasks = response;
        this.loadingVisibleA = false;
      },error:(err)=>{
        this.loadingVisibleA = false;
        this.errorToast(err);
      }
    })
  }

  selTaskInfo:any = [];
  IsBtnClick:boolean = false;
  removeTaskMdl:any;
  openTodayModal(event:any){
    this.selTaskInfo = event;
    this.removeTaskMdl = new (window as any).bootstrap.Modal(document.getElementById('removeTodayModal')!)
    this.removeTaskMdl.show();
  }

  removeTodayTask(){
    this.IsBtnClick = true;
    this.api.deleteUsrTasks({ "prod_id": this.selTaskInfo.id }).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":false
        }
        this.toast.info(objj);
        this.todayTasks = this.removeItemById(this.todayTasks,this.selTaskInfo.id);
        this.closeTodayModal(); 
        return
      },error:(err)=>{
        this.IsBtnClick = false;
        this.errorToast(err);
      }
    })
  }

  closeTodayModal(){
    this.selTaskInfo = [];
    this.IsBtnClick = false;
    this.removeTaskMdl.hide();
  }

  //*PRIOR*//
  getUserPriorTasks(){
    this.loadingVisibleB = true;
    this.api.getPriorTaskDate({"user_id":this.userInfo.id}).subscribe({
      next:(response)=>{
        this.taskDate = new Date(response.last_work_date);
        this.priorDate = this.datepipe.transform(new Date(response.last_work_date).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
        this.api.getPriorTasks().subscribe({
          next:(response)=>{
            this.priorTasks = response;
            this.loadingVisibleB = false;
          },error:(err)=>{
            this.loadingVisibleB = false;
            this.errorToast(err);
          }
        })
      },error:(err)=>{
        this.loadingVisibleB = false;
        this.errorToast(err);
      }
    })
  }

  selPriorTaskInfo:any = [];
  IsPriorBtnClick:boolean = false;
  removePriorTaskMdl:any;
  openPriorModal(event:any){
    this.selPriorTaskInfo = event;
    this.removePriorTaskMdl = new (window as any).bootstrap.Modal(document.getElementById('removePriorModal')!)
    this.removePriorTaskMdl.show();
  }

  removePriorTask(){
    this.IsPriorBtnClick = true;
    this.api.deleteUsrTasks({ "prod_id": this.selPriorTaskInfo.id }).subscribe({
      next:(response)=>{
        this.priorTasks = this.removeItemById(this.priorTasks,this.selPriorTaskInfo.id);
        this.closePriorModal(); 
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":false
        }
        this.toast.info(objj);
        return
      },error:(err)=>{
        this.IsPriorBtnClick = false;
        this.errorToast(err);
      }
    })
  }

  closePriorModal(){
    this.selPriorTaskInfo = [];
    this.IsPriorBtnClick = false;
    this.removePriorTaskMdl.hide();
  }

  //*ALL TASKS*//
  getUserTasks(){
    this.loadingVisibleC = true;
    let object = {
      "date_range": {
        "start_date": this.convert(this.taskStartDate),
        "end_date": this.convert(this.taskEndDate)
      },
      "status": []
    }
    this.loadPageUsrFilterData(object);
  }

  previewUsrtasks(){
    this.loadingVisibleC = true;
    
    if(!this.taskStartDate || !this.taskEndDate){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.taskStartDate,this.taskEndDate)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.taskStartDate,this.taskEndDate);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    let object = {
      "date_range": {
        "start_date": this.convert(this.taskStartDate),
        "end_date": this.convert(this.taskEndDate)
      },
      "status": []
    }
    this.loadPageUsrFilterData(object);
  }

  selUsrTaskInfo:any = [];
  IsUsrBtnClick:boolean = false;
  removeUsrTaskMdl:any;
  openUsrModal(event:any){
    this.selUsrTaskInfo = event;
    this.removeUsrTaskMdl = new (window as any).bootstrap.Modal(document.getElementById('removeUsrModal')!)
    this.removeUsrTaskMdl.show();
  }

  removeUsrTasks(){
    this.IsUsrBtnClick = true;
    this.api.deleteUsrTasks({ "prod_id": this.selUsrTaskInfo.id }).subscribe({
      next:(response)=>{
        this.previewUsrtasks(); this.closeUsrModal();
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":false
        }
        this.toast.info(objj);
        return
      },error:(err)=>{
        this.IsUsrBtnClick = false;
        this.errorToast(err);
      }
    })
  }

  closeUsrModal(){
    this.IsUsrBtnClick = false;
    this.removeUsrTaskMdl.hide();
    this.selUsrTaskInfo = [];
  }

  //*Tasks Events*//
  modalHeader:string = "CREATE NEW TASK";
  taskMdlView:any;
  openTaskModal(){
    this.modalHeader = "CREATE NEW TASK";
    this.taskMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdrop')!)
    this.taskMdlView.show();
    this.isTaskUpdate = false;
  }

  closeTaskModal(){
    this.taskMdlView.hide();
    if (this.childComponent) {
      this.childComponent.clearTaskInfo();
    }
    this.isTaskUpdate = false;
  }

  openTaskUpdModal(event:any){
    this.modalHeader = "UPDATE TASK";
    this.taskMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdrop')!)
    this.taskMdlView.show();
    this.isTaskUpdate = true;
    if (this.childComponent) {
      let object={
        formDetails:event,
        formStatus:'Edit'
      }
      this.childComponent.fetchTaskDetails(object);
    }
  }

  //*Task Sheet Form Events*//
  isFormSubmit:boolean = false;
  submitChildForm() {
    if (this.childComponent) {
      this.isFormSubmit = true;
      this.childComponent.onSubmit();
    }
  }

  onFormSubmitted(event:any) {
    this.isFormSubmit = false;
    let tskType = event.task_type;
    let tskDetails = event.task_details;
    if(tskType=='Create'){
      (this.tabHeader=='Today') ? this.getUserTodayTasks() :  (this.tabHeader=='Prior'? this.getUserPriorTasks(): this.getUserTasks());
    }else if(tskType=='Edit'){
      this.taskMdlView.hide();
      (this.tabHeader=='Today') ? this.getUserTodayTasks() :  (this.tabHeader=='Prior'? this.getUserPriorTasks(): this.getUserTasks());
      // (this.tabHeader=='Today') ? this.updateTodayItem(tskDetails.id, tskDetails) :  this.updatePriorItem(tskDetails.id, tskDetails);
    }

    // this.taskMdlView.show();
    // (this.tabHeader=='Today') ? this.getUserTodayTasks() :  (this.tabHeader=='Prior'? this.getUserPriorTasks(): this.getUserTasks());
  }

  // updateTodayItem(id: number, updatedData: any): void {
  //   this.todayTasks = this.todayTasks.map((item:any) => {
  //       if (item.id === id) {
  //           // Merge existing item with updatedData
  //           return { ...item, ...updatedData };
  //       } else {
  //           return item;
  //       }
  //   });
  // }

  // updatePriorItem(id: number, updatedData: any): void {
  //   console.log("updated:",updatedData)
  //   this.priorTasks = this.priorTasks.map((item:any) => {
  //       if (item.id === id) {
  //         // Merge existing item with updatedData
  //         return { ...item, ...updatedData };
  //       } else {
  //         return item;
  //       }
  //   });
  // }

  toastEvent(event:any) {
    this.toast.warning(event);
    this.isFormSubmit = false;
  }

  resetForm(){
    if (this.childComponent) {
      this.childComponent.clearTaskInfo();
    }
  }

  //*General Events*//
  removeItemById = (array: any, id: number): any => {
    return array.filter((item:any) => item.id !== id);
  };

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  calculateTime(rowData:any){
    var Totalminutes = rowData.total_time;
    var Hours = Math.floor(Totalminutes/60);
    var Minutes = Totalminutes % 60;
    return Hours.toString().padStart(2,'0') + ' : ' + Minutes.toString().padStart(2,'0')
  }

  StatementHeader(rowData:any){
    let reviewSts = rowData.peer_review_sts;
    let peerReview = (reviewSts==true)? 'Yes' : ((reviewSts==false)? 'No' : 'N/A');
    return peerReview;
  }

  CodeHeader(rowData:any){
    let codeCommit = rowData.code_commited;
    let commitStatus = (codeCommit==true)? 'Yes' : ((codeCommit==false)? 'No' : 'N/A');
    return commitStatus;
  }

  CommentHeader(rowData:any){
    let codeComment = rowData.code_comments;
    let commentStatus = (codeComment==true)? 'Yes' : ((codeComment==false)? 'No' : 'N/A');
    return commentStatus;
  }

  StandardHeader(rowData:any){
    let codeStd = rowData.coding_standards;
    let codingStdSts = (codeStd==true)? 'Yes' : ((codeStd==false)? 'No' : 'N/A');
    return codingStdSts;
  }

  isStartDateGreaterThanEndDate = (startDateStr: string, endDateStr: string): boolean => {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    return startDate > endDate;
  };

  dateRangeValidator(start:any,end:any){
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
      const timeDiff = endDate.getTime() - startDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      if (daysDiff > 30) {
        return true//{ 'dateRangeExceeded': true };
      }
    }
    return false
  }

  loadPageUsrFilterData(pageInfo:any){
    this.userTasksList = []
    const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
    this.userTasks = new CustomStore ({
      load: (loadOptions:any) => {    
        this.loadingVisibleC=true;      
        let params: HttpParams = new HttpParams();
        [   
          'filter',
          'group', 
          'groupSummary',
          'parentIds',
          'requireGroupCount',
          'requireTotalCount',
          'searchExpr',
          'searchOperation',
          'searchValue',
          'select',
          'sort',
          'skip',     
          'take',
          'totalSummary', 
          'userData'
        ].forEach(function(i) {
          if(i in loadOptions && isNotEmpty(loadOptions[i])) {
            params = params.set(i, JSON.stringify(loadOptions[i]));
          }else{
          }
        });
        return this.api.getOtherTasks(pageInfo,params)
          .toPromise()
            .then((response:any) => {
              this.loadingVisibleC=false;
              this.userTasksList = response.data;
                return {
                  data: response.data,
                  totalCount: response.totalCount,
                  summary: response.summary,
                  groupCount: response.groupCount
                };
            })
            .catch(() => { this.loadingVisibleC=false; throw 'Data loading error' });
      },
      update: (values:any) => {
        return this.userTasksList;
      },
    });
  }

  reload(){
    (this.tabHeader=='Today') ? this.getUserTodayTasks() :  this.getUserPriorTasks();
  }

  reloadUsrTasks(){
    this.loadingVisibleC = true;
    if(!this.taskStartDate || !this.taskEndDate){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.taskStartDate,this.taskEndDate)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.taskStartDate,this.taskEndDate);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisibleC = false;
      return;
    }

    let object = {
      "date_range": {
        "start_date": this.convert(this.taskStartDate),
        "end_date": this.convert(this.taskEndDate)
      },
      "status": []
    }
    this.loadPageUsrFilterData(object);
  }

  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }
}
