import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportsComponent } from './reports.component';

const routes: Routes = [{ path: '', component: ReportsComponent },
  { path: 'timesheet', loadChildren: () => import('./admin/timesheet/timesheet.module').then(m => m.TimesheetModule) },
  { path: 'attendance', loadChildren: () => import('./admin/attendance/attendance.module').then(m => m.AttendanceModule) },
  { path: 'production', loadChildren: () => import('./admin/production/production.module').then(m => m.ProductionModule) },
  { path: 'usr_timesheet', loadChildren: () => import('./user/timesheet/timesheet.module').then(m => m.TimesheetModule) },
  { path: 'usr_attendance', loadChildren: () => import('./user/attendance/attendance.module').then(m => m.AttendanceModule) },
  { path: 'usr_production', loadChildren: () => import('./user/production/production.module').then(m => m.ProductionModule) }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
