import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-usr-production',
  templateUrl: './production.component.html',
  styleUrls: ['./production.component.scss']
})
export class ProductionComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService,public datepipe:DatePipe){}

  startDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  loadingVisible:boolean = false;
  productionInfo:any = [];

  ngOnInit():void{
    this.getProductionReport();
  }

  getProductionReport(){
    this.loadingVisible = true;
    let object={
      "date_range": {
        "start_date": this.convert(this.startDate),
        "end_date": this.convert(this.endDate)
      }
    }
    this.api.getUserProdReport(object).subscribe({
      next:(response)=>{
        this.loadingVisible = false;
        response.forEach((response:any, index:number) => {
          response.order_id = index + 1;
        });
        this.productionInfo = response;
      },error:(err)=>{
        this.loadingVisible = false;
        this.errorToast(err);
      }
    })
  }

  previewReport(){
    this.loadingVisible = true;
    if(!this.startDate || !this.endDate){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date is undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDate,this.endDate)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDate,this.endDate);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    this.getProductionReport();
  }

  //*General Events*//
  expandedRowKey:any;
  usrProdData:any=[];
  onRowExpanding(e:any){
    if(this.expandedRowKey){
      e.component.collapseAll(-1);
    }
    this.expandedRowKey = e.key;

    this.api.getProdDetails({ "req_date":this.convert(this.expandedRowKey.task_date) }).subscribe({
      next:(response)=>{
        this.usrProdData = response;
        e.component.refresh()
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  reload(){
    if(!this.startDate || !this.endDate){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date is undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDate,this.endDate)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDate,this.endDate);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    this.getProductionReport();
  }

  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  isStartDateGreaterThanEndDate = (startDateStr: string, endDateStr: string): boolean => {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    return startDate > endDate;
  };

  dateRangeValidator(start:any,end:any){
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
      const timeDiff = endDate.getTime() - startDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      if (daysDiff > 30) {
        return true//{ 'dateRangeExceeded': true };
      }
    }
    return false
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }
}
