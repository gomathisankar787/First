import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { TimesheetRoutingModule } from './timesheet-routing.module';
import { TimesheetComponent } from './timesheet.component';
import { DxDataGridModule, DxLoadPanelModule } from 'devextreme-angular';
import { NgSelectModule } from '@ng-select/ng-select';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    TimesheetComponent
  ],
  imports: [
    CommonModule,
    TimesheetRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    NgSelectModule,
    ToastModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers:[DatePipe]
})
export class TimesheetModule { }
