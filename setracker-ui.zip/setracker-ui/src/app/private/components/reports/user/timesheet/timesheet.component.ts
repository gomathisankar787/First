import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import CustomStore from 'devextreme/data/custom_store';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.scss']
})
export class TimesheetComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService,public datepipe: DatePipe,private fb:FormBuilder){}

  loadingVisible:boolean = false;
  usrTimesheetInfo:any = [];
  selTasksts:any;
  taskStatusList:any = [];
  startDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');

  ngOnInit():void{
    this.api.getTaskStatusInfo().subscribe({
      next:(response)=>{
        this.taskStatusList = response;
        this.selTasksts = this.taskStatusList.map((i:any) => i.id);
      }
    })
    this.getTimesheetDetails();
  }

  getTimesheetDetails(){
    this.loadingVisible = true;
    let object={
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      },
      "sts_list": this.selTasksts ? this.selTasksts : []
    }
    this.loadPageFilterData(object);
    // this.api.getUserTimesheetInfo(object).subscribe({
    //   next:(response)=>{
    //     this.usrTimesheetInfo = response;
    //     this.loadingVisible = false;
    //   },error:(err)=>{
    //     this.loadingVisible = false;
    //     this.errorToast(err);
    //   }
    // })
  }

  previewReport(){
    this.loadingVisible = true;

    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date is undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selTasksts || !this.selTasksts.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Status undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    this.getTimesheetDetails();
  }

  addNewTimesheet(){

  }

  //*General Events*//
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }

  reload(){
    this.loadingVisible = true;

    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date is undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selTasksts || !this.selTasksts.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Status undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.getTimesheetDetails();
  }

  searchTaskSts(event:any,ngTaskSts:any){
    ngTaskSts.filter(event.target.value)
  }

  StatementHeader(rowData:any){
    let reviewSts = rowData.peer_review_sts;
    let peerReview = (reviewSts==true)? 'Yes' : ((reviewSts==false)? 'No' : 'N/A');
    return peerReview;
  }

  CodeHeader(rowData:any){
    let codeCommit = rowData.code_commited;
    let commitStatus = (codeCommit==true)? 'Yes' : ((codeCommit==false)? 'No' : 'N/A');
    return commitStatus;
  }

  CommentHeader(rowData:any){
    let codeComment = rowData.code_comments;
    let commentStatus = (codeComment==true)? 'Yes' : ((codeComment==false)? 'No' : 'N/A');
    return commentStatus;
  }

  StandardHeader(rowData:any){
    let codeStd = rowData.coding_standards;
    let codingStdSts = (codeStd==true)? 'Yes' : ((codeStd==false)? 'No' : 'N/A');
    return codingStdSts;
  }

  calculateTime(rowData:any){
    var Totalminutes = rowData.total_time;
    var Hours = Math.floor(Totalminutes/60);
    var Minutes = Totalminutes % 60;
    return Hours.toString().padStart(2,'0') + ' : ' + Minutes.toString().padStart(2,'0')
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  isStartDateGreaterThanEndDate = (startDateStr: string, endDateStr: string): boolean => {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    return startDate > endDate;
  };

  dateRangeValidator(start:any,end:any){
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
      const timeDiff = endDate.getTime() - startDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      if (daysDiff > 30) {
        return true//{ 'dateRangeExceeded': true };
      }
    }
    return false
  }

  //*Pagination*//
  loadPageFilterData(pageInfo:any){
    const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
    this.usrTimesheetInfo = new CustomStore ({
      load: (loadOptions:any) => {    
        this.loadingVisible = true;      
        let params: HttpParams = new HttpParams();
        [   
          'filter',
          'group', 
          'groupSummary',
          'parentIds',
          'requireGroupCount',
          'requireTotalCount',
          'searchExpr',
          'searchOperation',
          'searchValue',
          'select',
          'sort',
          'skip',     
          'take',
          'totalSummary', 
          'userData'
        ].forEach(function(i) {
          if(i in loadOptions && isNotEmpty(loadOptions[i])) {
            params = params.set(i, JSON.stringify(loadOptions[i]));
          }else{
          }
        });
        return this.api.getUserTimesheetInfo(pageInfo,params)
          .toPromise()
            .then((response:any) => {
              this.loadingVisible = false;
                return {
                  data: response.data,
                  totalCount: response.totalCount,
                  summary: response.summary,
                  groupCount: response.groupCount
                };
            })
            .catch(() => { this.loadingVisible = false; throw 'Data loading error' });
      },
      update: (values:any) => {
        return  values;
      },
    });
  }
}
