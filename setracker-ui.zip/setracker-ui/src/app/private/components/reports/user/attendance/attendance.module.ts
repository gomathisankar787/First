import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AttendanceRoutingModule } from './attendance-routing.module';
import { AttendanceComponent } from './attendance.component';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { DxDataGridModule, DxDateBoxModule, DxLoadPanelModule } from 'devextreme-angular';


@NgModule({
  declarations: [
    AttendanceComponent
  ],
  imports: [
    CommonModule,
    AttendanceRoutingModule,
    ToastModule,
    DxDataGridModule,
    DxDateBoxModule,
    DxLoadPanelModule
  ],
  providers:[DatePipe]
})
export class AttendanceModule { }
