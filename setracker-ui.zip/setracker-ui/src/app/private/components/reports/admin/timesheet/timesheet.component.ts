import { DatePipe } from '@angular/common';
import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';
import * as bootstrap from 'bootstrap';
import { HttpParams, HttpResponse } from '@angular/common/http';
import CustomStore from 'devextreme/data/custom_store';
import { CrTaskComponent } from './cr-task/cr-task.component';
import DataSource from 'devextreme/data/data_source';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.scss']
})
export class TimesheetComponent {

  @ViewChild(CrTaskComponent) childComponent!: CrTaskComponent;

  constructor(private api:ApiPrivateService,private toast:ToastService,private router:Router,public datepipe: DatePipe){}

  //child component
  taskDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');

  TimesheetInfo:any = [];
  loadingVisible:boolean = false;
  startDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  selUsrDept:any;
  departmentList:any = [];
  selDeptUsr:any;
  departmentUsers:any = [];
  selTasksts:any;
  taskStatusList:any = [];

  modalHeader:string = "CREATE NEW TASK";

  ngOnInit(): void{
    this.getTimesheetDetails();

    this.api.getDeptUserInfo().subscribe({
      next:(response)=>{
        this.departmentList = response;
        let obj={'id':0,'name':'All Departments'}
        this.departmentList.push(obj);
        this.departmentList.sort((a:any, b:any) => (a.id<b.id? -1 : 1));
        this.selUsrDept = 0;
      }
    })

    this.api.getActiveUsers().subscribe({
      next:(response)=>{
        // this.departmentUsers = response.map((i:any) => { i.is_active == true; return i; });
        this.departmentUsers = response.filter((i:any) => i.is_active === true);
        this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
        this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
        this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
      }
    })

    this.api.getTaskStatusInfo().subscribe({
      next:(response)=>{
        this.taskStatusList = response;
        this.selTasksts = this.taskStatusList.map((i:any) => i.id);
      }
    })
  }

  getTimesheetDetails(){
    this.loadingVisible = true;
    let object={
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      },
      "user_lst": this.selDeptUsr ? this.selDeptUsr : [],
      "status": this.selTasksts ? this.selTasksts : []
    }
    this.loadPageFilterData(object);
  }

  //*Preview Events*//
  getUserDepartment(event:any){
    if(event){
      this.selDeptUsr = null;
      let deptId = event.id;
      this.childComponent.getResources(deptId);
      if(deptId!=0){
        let deptUsers = this.departmentList.filter((items:any)=> items.id == deptId);
        let Users:any = deptUsers[0].user_info;
        if(Users.length){
          this.departmentUsers = Users.filter((data:any)=> data.is_active === true);
          this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
          this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
          this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
        }else{
          let objj={
            "Type":2,
            "Title":'Warning',
            "Message":'Invalid Data: Selected department does not have any resource, Please select valid department!',
            "autoClose":false
          }
          this.toast.warning(objj);
          this.departmentUsers = [];
          return;
        }
      }else if(deptId==0){
        this.api.getActiveUsers().subscribe({
          next:(response)=>{
            // this.departmentUsers = response.map((i:any) => { i.is_active == true; return i; });
            this.departmentUsers = response.filter((i:any)=> i.is_active === true);
            this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
            this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
            this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
          }
        })
      }
    }else{
      this.departmentUsers = [];
      this.selDeptUsr = null;
    }
  }

  previewReport(){
    this.loadingVisible = true;
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selTasksts || !this.selTasksts.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Status undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.getTimesheetDetails();
  }

  //*Task Sheet Form Events*//
  taskMdlView:any;
  isTaskUpdate:boolean = false;
  isMdlOpen:boolean = false;
  openTaskModal(){
    if (this.selUsrDept !== 0) {
      // Open your modal popup here
      this.modalHeader = "CREATE NEW TASK";
      this.taskMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdrop')!)
      this.taskMdlView.show();
      this.isTaskUpdate = false;
    } else {
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Please select exactly one department for task creation!',
        "autoClose":false
      }
      this.toast.warning(objj);
    }

    // this.modalHeader = "CREATE NEW TASK";
    // this.taskMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdrop')!)
    // this.taskMdlView.show();
    // this.isTaskUpdate = false;
  }

  closeTaskModal(){
    this.taskMdlView.hide();
    this.isTaskUpdate = false;
    if (this.childComponent) {
      this.childComponent.resetTimesheetInfo();
    }
  }

  openTaskUpdModal(event:any){
    this.modalHeader = "UPDATE TASK";
    this.taskMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdrop')!)
    this.taskMdlView.show();
    this.isTaskUpdate = true;
    if (this.childComponent) {
      let object={
        formDetails:event,
        formStatus:'Edit'
      }
      this.childComponent.fetchTaskDetails(object);
    }
  }

  isFormSubmit:boolean = false;
  submitChildForm() {
    if (this.childComponent) {
      this.isFormSubmit = true;
      this.childComponent.onSubmit();
    }
  }

  onFormSubmitted(event:any) {
    this.isFormSubmit = false;
    if(event.task_type == 'Create'){
      this.taskMdlView.show();
      var store = this.TimesheetInfo.store();
      this.TimesheetInfo.reload();
      store.insert(event.task_details)
    }else if(event.task_type == 'Edit'){
      let taskInfo = event.task_details;
      var store = this.TimesheetInfo.store();
      store.update(taskInfo.id,taskInfo)
      this.TimesheetInfo.reload();
      this.closeTaskModal();
    }
  }

  toastEvent(event:any) {
    this.toast.warning(event);
    this.isFormSubmit = false;
  }

  resetForm(){
    if (this.childComponent) {
      this.childComponent.resetTimesheetInfo();
    }
  }

  // addNewTimesheet(){
  //   this.modalHeader = "CREATE NEW TASK";
  //   let object={
  //     formStatus: 'Create',
  //     formDetails: null
  //   }
  //   this.router.navigate(['/home/reports/timesheet/create'],{state: {formInfo:object} })
  // }

  // updateTimesheet(event:any){
  //   this.modalHeader = "UPDATE TASK";
  //   let object={
  //     formStatus: 'Edit',
  //     formDetails: event
  //   }
  //   this.router.navigate(['/home/reports/timesheet/create'],{state: {formInfo:object} })
  // }

  exportTimesheet(){
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selTasksts || !this.selTasksts.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Status undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let object={
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      },
      "user_lst": this.selDeptUsr ? this.selDeptUsr : [],
      "status": this.selTasksts ? this.selTasksts : []
    }
    this.api.adminExportTimesheet(object).subscribe({
      next:(data)=>{
        let filename: string = this.getFileName(data)
        var binaryData:any = [];
        binaryData.push(data.body);
        let downloadLink = document.createElement('a');
        downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: 'blob' }));
        downloadLink.setAttribute('download', filename);
        document.body.appendChild(downloadLink);
        downloadLink.click();
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Preview report successfully downloaded...!',
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  selTaskInfo:any = [];
  IsBtnClick:boolean = false;
  removeTaskMdl:any;
  openModal(event:any){
    this.selTaskInfo = event;
    this.removeTaskMdl = new (window as any).bootstrap.Modal(document.getElementById('removeModal')!)
    this.removeTaskMdl.show();
  }

  removeTask(){
    this.IsBtnClick = true;
    this.api.adminDeleteusrTasks({ "prod_id": this.selTaskInfo.id }).subscribe({
      next:(response)=>{
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Your request has been successfully updated...',
          "autoClose":false
        }
        this.toast.info(objj);
        this.getTimesheetDetails();
        this.closeModal(); 
        return
      },error:(err)=>{
        this.IsBtnClick = false;
        this.errorToast(err);
      }
    })
  }

  closeModal(){
    this.selTaskInfo = [];
    this.IsBtnClick = false;
    this.removeTaskMdl.hide();
  }

  //*General Events*//
  removeItemById = (array: any, id: number): any => {
    return array.filter((item:any) => item.id !== id);
  };

  getFileName(response: HttpResponse<Blob>) {
    let filename: string;
    try {
      const contentDisposition: string = response.headers.get('content-disposition')!;
      filename = contentDisposition.split('filename=')[1].split(';')[0];
    }
    catch (e) {
      filename = 'Timesheet.xlsx'
    }
    return filename
  }

  StatementHeader(rowData:any){
    let reviewSts = rowData.peer_review_sts;
    let peerReview = (reviewSts==true)? 'Yes' : ((reviewSts==false)? 'No' : 'N/A');
    return peerReview;
  }

  CodeHeader(rowData:any){
    let codeCommit = rowData.code_commited;
    let commitStatus = (codeCommit==true)? 'Yes' : ((codeCommit==false)? 'No' : 'N/A');
    return commitStatus;
  }

  CommentHeader(rowData:any){
    let codeComment = rowData.code_comments;
    let commentStatus = (codeComment==true)? 'Yes' : ((codeComment==false)? 'No' : 'N/A');
    return commentStatus;
  }

  StandardHeader(rowData:any){
    let codeStd = rowData.coding_standards;
    let codingStdSts = (codeStd==true)? 'Yes' : ((codeStd==false)? 'No' : 'N/A');
    return codingStdSts;
  }

  calculateTime(rowData:any){
    var Totalminutes = rowData.total_time;
    var Hours = Math.floor(Totalminutes/60);
    var Minutes = Totalminutes % 60;
    return Hours.toString().padStart(2,'0') + ' : ' + Minutes.toString().padStart(2,'0')
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  isStartDateGreaterThanEndDate = (startDateStr: string, endDateStr: string): boolean => {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    return startDate > endDate;
  };

  dateRangeValidator(start:any,end:any){
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
      const timeDiff = endDate.getTime() - startDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      if (daysDiff > 30) {
        return true//{ 'dateRangeExceeded': true };
      }
    }
    return false
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  onResrOpen(deptSelect:any){
    setTimeout(() => {
      if (deptSelect?.dropdownPanel) {
        deptSelect.dropdownPanel.scrollElementRef.nativeElement.scrollTop = 0;
      }
    }, 0);
  }

  searchTaskSts(event:any,ngTaskSts:any){
    ngTaskSts.filter(event.target.value)
  }

  reload(){
    this.loadingVisible = true;
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selTasksts || !this.selTasksts.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Task status undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.getTimesheetDetails();
  }

  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }

  loadPageFilterData(pageInfo:any){
    const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
    this.TimesheetInfo = new DataSource ({
      store: new CustomStore({
      key: "id",
        load: (loadOptions:any) => {
          this.loadingVisible = true;
          let params: HttpParams = new HttpParams();
          [
            'filter',
            'group', 
            'groupSummary',
            'parentIds',
            'requireGroupCount',
            'requireTotalCount',
            'searchExpr',
            'searchOperation',
            'searchValue',
            'select',
            'sort',
            'skip',
            'take',
            'totalSummary',
            'userData'
          ].forEach((i) => {
            if(i in loadOptions && isNotEmpty(loadOptions[i])) {
              params = params.set(i, JSON.stringify(loadOptions[i]));
            }else{ }
          });
          return this.api.getAdminTimesheetInfo(pageInfo,params)
            .toPromise()
            .then((response:any) => {
              this.loadingVisible=false;
                return {
                  data: response.data,
                  totalCount: response.totalCount,
                  summary: response.summary,
                  groupCount: response.groupCount
                };
            })
            .catch(() => { this.loadingVisible=false; throw 'Data loading error' });
        },
        insert:(values:any) =>{
          return values
        },
        update: (key:any, values:any) =>{
          return values
        },
        remove: (key:any) =>{
          return this.TimesheetInfo
        }
      }),
    }); 
  }
}
