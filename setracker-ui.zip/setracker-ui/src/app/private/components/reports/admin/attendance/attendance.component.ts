import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss']
})
export class AttendanceComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService,public datepipe: DatePipe){}

  currentYear = new Date(new Date().getFullYear()-1,6,1);//new Date();
  currentDate = new Date();
  selUsrDept:any;
  departmentList:any = [];
  selDeptUsr:any;
  departmentUsers:any = [];

  loadingVisible:boolean = false;
  attendanceInfo:any = [];
  searchText:any = '';

  startRange:any = new Date(new Date().getFullYear()-1,6,1); // July 01,2023
  endRange:any = new Date(new Date(this.startRange).getFullYear()+1, 5, 1); // June 01,2024

  ngOnInit():void{
    this.api.getDeptUserInfo().subscribe({
      next:(response)=>{
        this.departmentList = response;
        let obj={'id':0,'name':'All Departments'}
        this.departmentList.push(obj);
        this.departmentList.sort((a:any, b:any) => (a.id<b.id? -1 : 1));
        this.selUsrDept = 0;
      }
    })

    this.api.getActiveUsers().subscribe({
      next:(response)=>{
        this.departmentUsers = response.filter((i:any) => i.is_active === true);
        this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
        this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
        this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
      }
    })

    this.getAttendanceReport();
  }

  getAttendanceReport(){
    this.loadingVisible = true;
    let object={
      "year": this.currentYear.getFullYear(),
      "user_list": []
    }
    this.api.getAttendanceInfo(object).subscribe({
      next:(response)=>{
        this.loadingVisible = false;
        this.attendanceInfo = this.formatAttendance(response);
      },error:(err)=>{
        this.loadingVisible = false;
        this.errorToast(err);
      }
    })
  }

  selectAssesmentYear(event:any){
    this.currentYear = new Date(event.value);
  }

  selectUserDepartment(event:any){
    if(event){
      this.selDeptUsr = null;
      let deptId = event.id;
      if(deptId!=0){
        let deptUsers = this.departmentList.filter((items:any)=> items.id == deptId);
        let Users:any = deptUsers[0].user_info;
        if(Users.length){
          this.departmentUsers = Users.filter((data:any)=> data.is_active === true);
          this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
          this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
          this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
        }else{
          let objj={
            "Type":2,
            "Title":'Warning',
            "Message":'Invalid Data: Selected department does not have any resource, Please select valid department!',
            "autoClose":false
          }
          this.toast.warning(objj);
          this.departmentUsers = [];
          return;
        }
      }else if(deptId==0){
        this.api.getActiveUsers().subscribe({
          next:(response)=>{
            this.departmentUsers = response.filter((i:any) => i.is_active === true);
            this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
            this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
            this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
          }
        })
      }
    }else{
      this.departmentUsers = [];
      this.selDeptUsr = null;
    }
  }

  previewReport(){
    this.loadingVisible = true;
    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.startRange = new Date(this.currentYear.getFullYear(), 6, 1)
    this.endRange = new Date(this.currentYear.getFullYear()+1, 5, 1)

    let object={
      "year": this.currentYear.getFullYear(),
      "user_list": this.selDeptUsr
    }
    this.api.getAttendanceInfo(object).subscribe({
      next:(response)=>{
        this.loadingVisible = false;
        this.attendanceInfo = this.formatAttendance(response);
      },error:(err)=>{
        this.loadingVisible = false;
        this.errorToast(err);
      }
    })
  }

  //*General Events*//
  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }

  reload(){
    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      return;
    }

    this.loadingVisible = true;
    let object={
      "year": this.currentYear.getFullYear(),
      "user_list": this.selDeptUsr
    }
    this.api.getAttendanceInfo(object).subscribe({
      next:(response)=>{
        this.loadingVisible = false;
        this.attendanceInfo = this.formatAttendance(response);
      },error:(err)=>{
        this.loadingVisible = false;
        this.errorToast(err);
      }
    })
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  onResrOpen(deptSelect:any){
    setTimeout(() => {
      if (deptSelect?.dropdownPanel) {
        deptSelect.dropdownPanel.scrollElementRef.nativeElement.scrollTop = 0;
      }
    }, 0);
  }

  onContentReady(e:any) {
    document.querySelector('.dx-datagrid-rowsview')?.before(document.querySelector('.dx-datagrid-total-footer')!)
  }

  onRowPrepared(e:any) {
    if (e.rowType == 'totalFooter') {  
      e.rowElement.style.backgroundColor = '#705cf008'//'aliceblue';   //'#f7f7f8'//
      e.rowElement.className = e.rowElement.className.replace("dx-row-alt", "");  
    }
  }

  customizeText(data:any){
    return 'Total:'
  }  

  customizeTotal(data:any){
    var Totalminutes = data.value;
    var Hours = Math.floor(Totalminutes/60);
    var Minutes = Totalminutes % 60;
    return Hours.toString().padStart(2,'0') + ':' + Minutes.toString().padStart(2,'0');
  }

  customizeTotalLeaves(data:any){
    return data.value
  }

  formatAttendance(inputData:any) { //KRA Dashboard
    var transformedData:any = [];
    for (const user of inputData){
      var transformedUser:any = {
        id:user.user_id,
        user_id:user.user_id,
        user_fname: user.user_fname,
        user_lname: user.user_lname,
        dept_name:user.dept_name,
        date_joined:user.date_joined,
        total_leaves:'',
        total_hours:'',
        total_wh:''
      };

      for (let dateData of user.data) {
        let userAttendance = user.data;
        let totHours = 0;  let totLeaves = 0; let totWHDays = 0; let totWHDates = 0;

        for(let i=0;i<userAttendance.length ;i++){
          totLeaves += userAttendance[i]['leave_days'];
          totHours += userAttendance[i]['tot_hrs_diff'];
          totWHDays += userAttendance[i]['woh_days_cnt'];
          totWHDates += userAttendance[i]['woh_dates'];
          // transformedUser['total_hours'] = totHours;
        }

        transformedUser['total_leaves'] = totLeaves;
        transformedUser['total_hours'] = totHours;
        transformedUser['total_wh'] = totWHDays;

        //for Total
        var Totalminutes = totHours;
        var Hours = Math.floor(Totalminutes/60);
        var Minutes = Totalminutes % 60;
        transformedUser['total_hours'] = Hours.toString().padStart(2,'0') + ':' + Minutes.toString().padStart(2,'0');

        //for monthly total
        var minutes = dateData['tot_hrs_diff']
        var hours = Math.floor(minutes/60);
        var prodMins = minutes % 60;
        let prodMonthHrs = dateData['tot_hrs_diff']? hours.toString().padStart(2,'0') + ':' + prodMins.toString().padStart(2,'0') : null

        var convertDate:any = new Date(dateData["month"]).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })
        var formattedDate:any = this.datepipe.transform(new Date(convertDate), "MMMM")

        //check joined date
        let joinedMonth:any = this.datepipe.transform(new Date(transformedUser['date_joined']).toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }),"MMMM,yyyy")
        let displayMonth:any =  this.datepipe.transform(new Date(convertDate), "MMMM,yyyy")
        let isJoinMonth = (displayMonth==joinedMonth)? true : false;

        transformedUser[formattedDate]={
          leave_days: dateData['leave_days'],
          leave_date: dateData['leave_dates'],
          woh_days_cnt: dateData['woh_days_cnt'],
          woh_dates: dateData['woh_dates'],
          hrs_diff: prodMonthHrs,
          tot_hrs_diff: dateData['tot_hrs_diff'],
          hrsIsHigh: (dateData['tot_hrs_diff']>240)? true : false,
          is_joined_month: isJoinMonth,
          extra_hrs: dateData['extra_hrs'],
        }
      }
      transformedData.push(transformedUser);
    }
    return transformedData;
  }

}
