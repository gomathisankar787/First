import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CrTaskComponent } from './cr-task/cr-task.component';
import { TimesheetComponent } from './timesheet.component';

const routes: Routes = [{ path: '', component: TimesheetComponent },
  { path:'create', component: CrTaskComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TimesheetRoutingModule { }
