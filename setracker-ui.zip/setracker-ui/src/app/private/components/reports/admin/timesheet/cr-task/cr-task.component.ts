import { DatePipe, Location } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import CustomStore from 'devextreme/data/custom_store';
import DataSource from 'devextreme/data/data_source';
import { UserService } from 'src/app/core/services/user.service';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-cr-task',
  templateUrl: './cr-task.component.html',
  styleUrls: ['./cr-task.component.scss']
})
export class CrTaskComponent {

  @Output() formSubmitted = new EventEmitter<void>(); // Event to notify form submission
  @Output() toastEvent = new EventEmitter<void>();
  @Input() taskDate: any;

  userInfo:any;
  timesheetForm!:FormGroup;
  formHeader:string = " CREATE NEW TASK";
  startDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  dueDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  allResources:any = [];
  projectList:any = [];
  peerersList:any = [];
  assignerList:any = [];
  taskStatusList:any = [];
  IsTaskUpdate:boolean = false;
  searchTask:any = "";
  taskLists:any = [];
  taskListsFilter:any = [];
  taskCaptured:boolean = false;
  taskData:boolean = false;
  taskFocus:boolean=false;
  searchText:any = '';

  constructor(private api:ApiPrivateService,private fb:FormBuilder,private toast:ToastService,public datepipe: DatePipe,private location: Location,private userServ:UserService,private router:Router){
    this.timesheetForm = this.fb.group({
      id:[null],
      old_task_id:[null],
      user: [null,Validators.required],
      project: [null,Validators.required],
      task_name: ['',Validators.required],
      task_summary: ['',Validators.required],
      task_assigned_by: [null,Validators.required],
      task_status: [null,Validators.required],
      prod_percent: ['',[Validators.max(100), Validators.min(0),Validators.required]],
      total_hrs: ['',[Validators.max(8), Validators.min(0),Validators.required]],
      total_mins: [0,[Validators.max(59), Validators.min(0),Validators.required]],
      task_meeting: [null,Validators.required], //boolean
      start_date: [this.startDateRange,Validators.required],
      end_date: [this.endDateRange,Validators.required],
      due_date: [this.dueDateRange,Validators.required],
      skills_used: ['',Validators.required],
      peer_review_sts: ['',Validators.required],
      peer_review_by: [null],
      code_commited: ['N/A'],
      code_comments: ['N/A'],
      coding_standards: ['N/A'],
      comments: [''],
      timesheet_status: [true],
      created_by:[null]
    },{ validators: [this.totalTimeValidator,this.userRequiredValidator('peer_review_sts','peer_review_by')] });
  }

  ngOnInit():void{
    this.userInfo = this.userServ.getUser();

    this.api.getActiveProjects().subscribe({
      next:(response)=>{
        this.projectList = response;
      }
    })

    this.api.getTaskStatusInfo().subscribe({
      next:(response)=>{
        this.taskStatusList = response;
      }
    })

    this.api.getActiveUsers().subscribe({
      next:(response)=>{
        response.map((i:any) => { i.full_name = i.first_name + ' ' + i.last_name; return i; });
        this.peerersList = response;
        this.assignerList = response;
        this.allResources = response;
      }
    })

    let pageState:any = this.location.getState();
    if (pageState.formDetails){
      this.fetchTaskDetails(pageState.formDetails)
    } else{
      this.router.navigate(['/home/reports/timesheet']);
    }
  }

  get f(){
    return this.timesheetForm.controls;
  }

  formControlNamesMapping:any = {
    id: 'ID',
    user: 'Resource',
    // dept_name:'Department',
    project: 'Project',
    task_name: 'Task Name',
    task_summary: 'Task Summary',
    task_assigned_by: 'Task Assigned By',
    task_status: 'Task Status',
    prod_percent: 'Production',
    total_hrs: 'Hours',
    total_mins: 'Minutes',
    task_meeting: 'Task Meeting',
    start_date: 'Start Date',
    end_date: 'End Date',
    due_date: 'Due Date',
    skills_used: 'Skills Used',
    peer_review_sts: 'Peer Review',
    peer_review_by: 'Peer Review By',
    code_commited: 'Code Committed',
    code_comments: 'Code Comments',
    coding_standards: 'Coding Standards',
    comments: 'Notes',
    timesheet_status: 'Timesheet Status'
  };

  getFieldName(fieldName: string): string {
    return this.formControlNamesMapping[fieldName] || fieldName;
  }

  changeTskStatus(event:any){
    let taskSts = event.target.value;
    if(taskSts=='Completed'){
      this.timesheetForm.get('prod_percent')?.setValue(100);
    }else{
      this.timesheetForm.get('prod_percent')?.setValue(null);
    }
  }

  changeReviewStatus(event:any){
    let peerRev = event.target.value;
    if(peerRev !== 'Yes'){
      this.timesheetForm.get('peer_review_by')?.setValue(null);
    }
  }

  getResources(deptId:any){
    this.api.getActiveUsers().subscribe({
      next:(response)=>{
        response.map((i:any) => { i.full_name = i.first_name + ' ' + i.last_name; return i; });
        this.allResources = response.filter((i:any) => i.dept_id === deptId);
      }
    })
  }

  onSubmit(){
    if (this.timesheetForm.valid) {   //*Valid Form*//
      this.createORupdateTasks(this.timesheetForm.value);
    }else {   //*Invalid Form*//
      const controls = this.timesheetForm.controls;
      for (const name in controls) {
        if (controls[name].errors?.['required']) {
          let errorObj:any={
            'Type':2,
            'Title':'Warning',
            'Message':'Invalid Request: '+ '"'+this.getFieldName(name)+'"' +' is required; please double-check your input!',
            'autoClose':false
          }
          this.toastEvent.emit(errorObj);
          return
        }else if(controls[name].errors?.['max']){
          let errorObj = this.showMaximuError(name)
          this.toastEvent.emit(errorObj);
          return
        }else if(controls[name].errors?.['min']){
          let errorObj = this.showMinimumError(name)
          this.toastEvent.emit(errorObj);
        }
      }
    }
  }

  createORupdateTasks(event:any){
    let formData = event;
    let hours = formData.total_hrs || 0;
    let minutes = formData.total_mins || 0;
    let totalTime = hours * 60 + minutes;

    formData.project = (formData.project > 0) ? Number(formData.project) : null;
    formData.task_assigned_by = (formData.task_assigned_by > 0) ? Number(formData.task_assigned_by) : null;
    formData.peer_review_by =  (formData.peer_review_by > 0) ? Number(formData.peer_review_by) : null; //formData.peer_review_sts? ((formData.peer_review_by > 0) ? Number(formData.peer_review_by) : null) : null; //(formData.peer_review_by > 0) ? Number(formData.peer_review_by) : null;    
    let tskStatus = this.taskStatusList.find((item:any)=> item.name == formData.task_status);
    let previewSts = (formData.peer_review_sts == 'N/A')? null : ((formData.peer_review_sts=='Yes')?true:false)
    let previewUser = (formData.peer_review_sts == 'N/A')? null : ((formData.peer_review_sts=='Yes')? formData.peer_review_by:null)
    let codeCommit = (formData.code_commited == 'N/A')? null : ((formData.code_commited=='Yes')?true:false)
    let codeComment = (formData.code_comments == 'N/A')? null : ((formData.code_comments=='Yes')?true:false)
    let codeStandard = (formData.coding_standards == 'N/A')? null : ((formData.coding_standards=='Yes')?true:false);

    if(!formData.id){ //Task Create
      let object={
        "project": formData.project,
        "task_name": formData.task_name,
        "task_summary": formData.task_summary,
        "task_assigned_by": formData.task_assigned_by,
        "task_meeting": formData.task_meeting,
        "start_date": this.convert(formData.start_date),
        "end_date": this.convert(formData.end_date),
        "due_date": this.convert(formData.due_date),
        "total_time": totalTime,
        "task_status": tskStatus.id,
        "comments": formData.comments,
        "timesheet_status": formData.timesheet_status,
        "user": formData.user,
        "prod_percent": formData.prod_percent,
        "skills_used": formData.skills_used,
        "peer_review_sts": previewSts,
        "peer_review_by": previewUser,//formData.peer_review_by,
        "code_commited": codeCommit,
        "code_comments": codeComment,
        "coding_standards": codeStandard,
        "task_date": this.convert(this.taskDate),
        "old_task_id":formData.old_task_id,
        "created_by":this.userInfo.id,
        "updated_by":null
      }
      this.api.adminCreateUsrTasks(object).subscribe({
        next:(response)=>{
          let Message:any = {
            task_type:'Create',
            task_details:response
          }
          this.formSubmitted.emit(Message);

          let objj:any={
            "Type":1,
            "Title":'Info',
            "Message":'Your request has been successfully created...',
            "autoClose": true
          }
          this.toastEvent.emit(objj);
          this.resetTimesheetInfo();
          return
        },error:(err)=>{
          this.errorToast(err);
        }
      })
    }else{ //Task Update
      let object={
        "id": formData.id,
        "project": formData.project,
        "task_name": formData.task_name,
        "task_summary": formData.task_summary,
        "task_assigned_by": formData.task_assigned_by,
        "task_meeting": formData.task_meeting,
        "start_date": this.convert(formData.start_date),
        "end_date": this.convert(formData.end_date),
        "due_date": this.convert(formData.due_date),
        "total_time": totalTime,
        "task_status": tskStatus.id,
        "comments": formData.comments,
        "timesheet_status": formData.timesheet_status,
        "user": formData.user,
        "prod_percent": formData.prod_percent,
        "skills_used": formData.skills_used,
        "peer_review_sts": previewSts,
        "peer_review_by": previewUser,
        "code_commited": codeCommit,
        "code_comments": codeComment,
        "coding_standards": codeStandard,
        "task_date": this.convert(this.taskDate),
        "old_task_id":formData.old_task_id,
        "created_by":formData.created_by,
        "updated_by":this.userInfo.id
      }
      this.api.adminUpdateUsrTasks(object).subscribe({
        next:(response)=>{
          let Message:any = {
            task_type:'Edit',
            task_details:response
          }
          this.formSubmitted.emit(Message);
          let objj:any={
            "Type":1,
            "Title":'Info',
            "Message":'Your request has been successfully updated...',
            "autoClose": true
          }
          this.toastEvent.emit(objj);
          this.resetTimesheetInfo();
          return
        },error:(err)=>{
          this.errorToast(err);
        }
      })
    }
  }

  resetTimesheetInfo(){
    this.taskLists = [];
    this.taskListsFilter = [];
    this.taskData = false;
    this.taskDate = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
    this.timesheetForm.reset();
    this.timesheetForm.get('start_date')?.setValue(this.startDateRange);
    this.timesheetForm.get('end_date')?.setValue(this.endDateRange);
    this.timesheetForm.get('due_date')?.setValue(this.dueDateRange);
  }

  //*fetch timesheet details*//
  fetchTaskDetails(event:any){
    let taskDetails = event.formDetails;
    this.IsTaskUpdate = (event.formStatus=='Edit') ? true:false;
    this.formHeader = (event.formStatus=='Edit') ? 'UPDATE TASK':'CREATE NEW TASK';
    this.timesheetForm.patchValue(taskDetails);

    //custom selection - update
    if(this.IsTaskUpdate){
      this.taskDate = taskDetails.task_date;
      this.timesheetForm.get('project')?.setValue(taskDetails.project_id);
      this.timesheetForm.get('task_assigned_by')?.setValue(taskDetails.task_assigned_by_id);
      this.timesheetForm.get('peer_review_by')?.setValue(taskDetails.peer_review_by_id);
      this.timesheetForm.get('user')?.setValue(taskDetails.user_id);
      this.timesheetForm.get('created_by')?.setValue(taskDetails.created_by_id);

      let previewSts = (taskDetails.peer_review_sts===true)? 'Yes' : ((taskDetails.peer_review_sts===false)? 'No' : 'N/A')
      this.timesheetForm.get('peer_review_sts')?.setValue(previewSts);

      let codeCommit = (taskDetails.code_commited===true)? 'Yes' : ((taskDetails.code_commited===false)? 'No' : 'N/A');
      this.timesheetForm.get('code_commited')?.setValue(codeCommit);

      let codeComment = (taskDetails.code_comments===true)? 'Yes' : ((taskDetails.code_comments===false)? 'No' : 'N/A');
      this.timesheetForm.get('code_comments')?.setValue(codeComment);

      let codeStandard = (taskDetails.coding_standards===true)? 'Yes' : ((taskDetails.coding_standards===false)? 'No' : 'N/A');
      this.timesheetForm.get('coding_standards')?.setValue(codeStandard);

      let time = this.convertMinHours(taskDetails.total_time);
      this.timesheetForm.get('total_hrs')?.setValue(time.hours);
      this.timesheetForm.get('total_mins')?.setValue(time.minutes);

      this.api.getTaskStatusInfo().subscribe({
        next:(response)=>{
          this.taskStatusList = response;
          let tskStatus = this.taskStatusList.find((item:any)=> item.id == taskDetails.task_status_id)
          this.timesheetForm.get('task_status')?.setValue(tskStatus.name);
        }
      })

      if(taskDetails.old_task_id){
        this.getOldTask(taskDetails)
      }
    }
  }

  //*General Events*//
  totalTimeValidator(form: FormGroup) {
    const hours = form.get('total_hrs')?.value || 0;
    const minutes = form.get('total_mins')?.value || 0;
    const totalMinutes = hours * 60 + minutes;
    return totalMinutes > 1440 ? { over24Hours: true } : null;
  }

  userRequiredValidator(statusField: string, userField: string): ValidatorFn {
    return (form: AbstractControl): { [key: string]: any } | null => {
      const status = form.get(statusField)?.value;
      const userControl = form.get(userField);
  
      if (status=='Yes' && !userControl?.value) {
        userControl?.setErrors({ required: true });
        return { userRequired: true };
      } else {
        userControl?.setErrors(null);
        return null;
      }
    };
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  convertMinHours(totalMinutes: number): { hours: number, minutes: number } {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return { hours, minutes };
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  searchProject(event:any,ngProj:any){
    ngProj.filter(event.target.value)
  }

  searchAssigner(event:any,ngAssign:any){
    ngAssign.filter(event.target.value)
  }

  searchPeer(event:any,ngPeer:any){
    ngPeer.filter(event.target.value)
  }

  gotoTasks(){
    this.router.navigate(['/home/reports/timesheet']);
  }

  cancelTasks(){
    this.router.navigate(['/home/reports/timesheet']);
  }

  showMaximuError(event:any){
    if(event=="total_hrs"){
      let errorObj:any={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: '+ '"'+this.getFieldName(event)+'"' +' must be 0 to 8.',
        'autoClose':false
      }
      return errorObj
    }else if(event=="total_mins"){
      let errorObj:any={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: '+ '"'+this.getFieldName(event)+'"' +' must be 0 to 59 ',
        'autoClose':false
      }
      return errorObj
    }
  }

  showMinimumError(event:any){
    if(event=="total_hrs"){
      let errorObj:any={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: '+ '"'+this.getFieldName(event)+'"' +' must be 0 to 8.',
        'autoClose':false
      }
      return errorObj
    }else if(event=="total_mins"){
      let errorObj:any={
        'Type':2,
        'Title':'Warning',
        'Message':'Invalid Request: '+ '"'+this.getFieldName(event)+'"' +' must be 0 to 59 ',
        'autoClose':false
      }
      return errorObj
    }
  }

  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj:any={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toastEvent.emit(objj);
      return
    }else{
      let objj:any={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toastEvent.emit(objj);
      return
    }
  }

  getOldTask(event:any){
    let object={
      "user_id": event.user_id,
      "req_data": event.task_name,
      "project_id": event.project_id
    }
    this.api.adminSearchInTasks(object).subscribe({
      next:(reponse)=>{
        this.taskLists = reponse;
        this.taskCaptured = true; // disable input textbox
        this.timesheetForm.get("old_task_id")?.setValue(reponse[0].id);
        this.timesheetForm.get("task_name")?.setValue(reponse[0].task_name);
        // this.timesheetForm.get("task_summary")?.setValue(reponse[0].task_summary);
        // this.timesheetForm.get("task_assigned_by")?.setValue(reponse[0].task_assigned_by);
      }
    })
  }

  resourceId:any;
  getUserID(event:any){
    this.resourceId = event;
  }

  projectId:any;
  pendingTaskLists:any = [];
  loadingVisibleC:boolean = false;
  projectName:any;
  getProject(event:any){
    this.projectId = event;
    let project = this.projectList.find((item:any)=> item.id==this.projectId)
    this.projectName = project?.name;
    if(this.taskCaptured){
      this.taskCaptured = false;
      this.taskLists = [];
      this.taskListsFilter = [];
      this.taskData = false;
      this.timesheetForm.get("old_task_id")?.setValue(null);
      this.timesheetForm.get("task_name")?.setValue(null);
      this.timesheetForm.get("task_summary")?.setValue(null);
      this.timesheetForm.get("task_assigned_by")?.setValue(null);
    }
    this.loadPageFilterData({ "user_id": this.resourceId,"project_id": this.projectId })
  }

  getProjectTask(event:any){
    this.searchTask = event;
    if(this.searchTask){
      this.searchTask = event.toLowerCase();//.target.value;
      if(this.searchTask.length > 4){
        if(!this.taskData){
          this.taskData = true;
          // API call
          let object={
            "user_id": this.timesheetForm.get("user")?.value,
            "req_data": this.searchTask,
            "project_id": this.timesheetForm.get("project")?.value
          }
          this.api.adminSearchInTasks(object).subscribe({
            next:(reponse)=>{
              this.taskLists = reponse;
            }
          })
        }
        this.taskListsFilter = this.taskLists.filter((task:any) => task.task_name.toLowerCase().includes(this.searchTask));
      }else{
        this.taskLists = [];
        this.taskListsFilter = [];
        this.taskData = false;
      }
    }
  }

  cancelTask(){
    this.taskCaptured = false; // enable input textbox
    this.taskLists = [];
    this.taskListsFilter = [];
    this.taskData = false;
    this.timesheetForm.get("old_task_id")?.setValue(null);
    this.timesheetForm.get("task_name")?.setValue(null);
    this.timesheetForm.get("task_summary")?.setValue(null);
    this.timesheetForm.get("task_assigned_by")?.setValue(null);
    this.selectedRow = null;
  }

  selectedRow: any = null; // To track selected row
  selectedRowDetails:any;
  onRowSelectionChanged(event: any) {
    if (event.selectedRowsData.length) {
      this.selectedRow = event.selectedRowsData[0].id; // Update the selected row ID
      // this.taskSelection( event.selectedRowsData[0])
      this.selectedRowDetails = event.selectedRowsData[0];
    }
  }

  taskSelection(task:any){
    this.taskCaptured = true; // disable input textbox
    this.timesheetForm.get("old_task_id")?.setValue(task.id);
    this.timesheetForm.get("task_name")?.setValue(task.task_name);
    this.timesheetForm.get("task_summary")?.setValue(task.task_summary);
    this.timesheetForm.get("task_assigned_by")?.setValue(task.task_assigned_by);
  }

  focusTask(){
    this.taskFocus = true;
  }

  taskMdown(event:any){
    event.preventDefault();
  }

  foutTask(){
    if(!this.taskCaptured){
      this.taskFocus = false;
    }
  //   setTimeout(() => {
  //     if(!this.taskCaptured){
  //       this.taskFocus = false;
  //     }
  //   }, 100);
  }

  taskListMdlView:any;
  openTasksModal(){
    this.taskListMdlView = new (window as any).bootstrap.Modal(document.getElementById('staticBackdropB')!)
    this.taskListMdlView.show();
    this.selectedRow = null;
    this.selectedRowDetails = null;
  }

  CancelTaskInfo(){
    this.taskListMdlView.hide();
  }

  SelectTaskInfo(){
    if(this.selectedRowDetails){
      this.taskSelection(this.selectedRowDetails);
      this.taskListMdlView.hide();
    }else{
      let objj:any={
        "Type":2,
        "Title":"Warning",
        "Message":"Invalid Request: Data is not found, Please check your input!",
        "autoClose":false
      }
      this.toastEvent.emit(objj);
    }
  }

  //In-Prgress/Hold Task Lists
  loadPageFilterData(pageInfo:any){
    const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
    this.pendingTaskLists = new DataSource ({
      store: new CustomStore({
      key: "id",
        load: (loadOptions:any) => {
          this.loadingVisibleC = true;
          let params: HttpParams = new HttpParams();
          [
            'filter',
            'group', 
            'groupSummary',
            'parentIds',
            'requireGroupCount',
            'requireTotalCount',
            'searchExpr',
            'searchOperation',
            'searchValue',
            'select',
            'sort',
            'skip',
            'take',
            'totalSummary', 
            'userData'
          ].forEach((i) => {
            if(i in loadOptions && isNotEmpty(loadOptions[i])) {
              params = params.set(i, JSON.stringify(loadOptions[i]));
            }else{ }
          });
          return this.api.getPendingTasks(pageInfo,params)
            .toPromise()
            .then((response:any) => {
              this.loadingVisibleC = false;
              this.selectedRow = null;
                return {
                  data: response.data,
                  totalCount: response.totalCount,
                  summary: response.summary,
                  groupCount: response.groupCount
                };
            })
            .catch(() => { this.loadingVisibleC=false; throw 'Data loading error' });
        },
        insert:(values:any) =>{
          return values
        },
        update: (key:any, values:any) =>{
          return values
        },
        remove: (key:any) =>{
          return this.pendingTaskLists
        }
      }),
    }); 
  }
}
