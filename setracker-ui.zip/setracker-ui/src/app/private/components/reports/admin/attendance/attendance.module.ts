import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { AttendanceRoutingModule } from './attendance-routing.module';
import { AttendanceComponent } from './attendance.component';
import { DxDataGridModule, DxDateBoxModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    AttendanceComponent
  ],
  imports: [
    CommonModule,
    AttendanceRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    DxDateBoxModule
  ],
  providers:[DatePipe]
})
export class AttendanceModule { }
