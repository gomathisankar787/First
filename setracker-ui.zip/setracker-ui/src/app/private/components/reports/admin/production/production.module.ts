import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { ProductionRoutingModule } from './production-routing.module';
import { ProductionComponent } from './production.component';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { DxDataGridModule, DxLoadPanelModule } from 'devextreme-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  declarations: [
    ProductionComponent
  ],
  imports: [
    CommonModule,
    ProductionRoutingModule,
    ToastModule,
    DxDataGridModule,
    DxLoadPanelModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  providers:[DatePipe]
})
export class ProductionModule { }
