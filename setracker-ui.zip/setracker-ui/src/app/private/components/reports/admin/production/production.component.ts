import { DatePipe } from '@angular/common';
import { HttpParams, HttpResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import CustomStore from 'devextreme/data/custom_store';
import { ApiPrivateService } from 'src/app/private/http/api-private.service';
import { ToastService } from 'src/app/shared/services/toast.service';

@Component({
  selector: 'app-production',
  templateUrl: './production.component.html',
  styleUrls: ['./production.component.scss']
})
export class ProductionComponent {

  constructor(private api:ApiPrivateService,private toast:ToastService,public datepipe:DatePipe){}

  startDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  currentDate:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  endDateRange:any = this.datepipe.transform(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }), 'yyyy-MM-dd');
  departmentList:any = [];
  selUsrDept:any;
  departmentUsers:any = [];
  selDeptUsr:any;
  loadingVisible:boolean = false;
  productionInfo:any = [];

  ngOnInit():void{
    this.getProductionReport();

    this.api.getDeptUserInfo().subscribe({
      next:(response)=>{
        this.departmentList = response;
        let obj={'id':0,'name':'All Departments'}
        this.departmentList.push(obj);
        this.departmentList.sort((a:any, b:any) => (a.id<b.id? -1 : 1));
        this.selUsrDept = 0;
      }
    })

    this.api.getUserInfo().subscribe({
      next:(response)=>{
        // this.departmentUsers = response.map((i:any) => { i.is_active == true; return i; });
        this.departmentUsers = response.filter((i:any) => i.is_active === true);
        this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
        this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
        this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
      }
    })
  }

  getProductionReport(){
    this.loadingVisible = true;
    let object={
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      },
      "usr_list": this.selDeptUsr ? this.selDeptUsr : [],
      "usr_active_flag": true    //if true for active user else inactive user
    }
    this.loadPageFilterData(object);
  }

  getUserDepartment(event:any){
    if(event){
      this.selDeptUsr = null;
      let deptId = event.id;
      if(deptId!=0){
        let deptUsers = this.departmentList.filter((items:any)=> items.id == deptId);
        let Users:any = deptUsers[0].user_info;
        if(Users.length){
          this.departmentUsers = Users.filter((data:any)=> data.is_active === true);
          this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
          this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
          this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
        }else{
          let objj={
            "Type":2,
            "Title":'Warning',
            "Message":'Invalid Data: Selected department does not have any resource, Please select valid department!',
            "autoClose":false
          }
          this.toast.warning(objj);
          this.departmentUsers = [];
          return;
        }
      }else if(deptId==0){
        this.api.getUserInfo().subscribe({
          next:(response)=>{
            // this.departmentUsers = response.map((i:any) => { i.is_active == true; return i; });
            this.departmentUsers = response.filter((i:any) => i.is_active === true);
            this.departmentUsers.sort((a:any, b:any) => (a.first_name<b.first_name? -1 : 1));
            this.departmentUsers.map((i:any) => { i.fullName = i.first_name + ' ' + i.last_name; return i; });
            this.selDeptUsr = this.departmentUsers.map((i:any) => i.id);
          }
        })
      }
    }else{
      this.departmentUsers = [];
      this.selDeptUsr = null;
    }
  }

  onDeptOpen(deptSelect:any){
    setTimeout(() => {
      if (deptSelect?.dropdownPanel) {
        deptSelect.dropdownPanel.scrollElementRef.nativeElement.scrollTop = 0;
      }
    }, 0);
  }

  previewReport(){
    this.loadingVisible = true;
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.getProductionReport();
  }

  exportProduction(){
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let object={
      "date_range": {
        "start_date": this.convert(this.startDateRange),
        "end_date": this.convert(this.endDateRange)
      },
      "usr_list": this.selDeptUsr ? this.selDeptUsr : [],
    }
    this.api.adminExportProduction(object).subscribe({
      next:(data)=>{
        let filename: string = this.getFileName(data)
        var binaryData:any = [];
        binaryData.push(data.body);
        let downloadLink = document.createElement('a');
        downloadLink.href = window.URL.createObjectURL(new Blob(binaryData, { type: 'blob' }));
        downloadLink.setAttribute('download', filename);
        document.body.appendChild(downloadLink);
        downloadLink.click();
        let objj={
          "Type":1,
          "Title":'Info',
          "Message":'Preview report successfully downloaded...!',
          "autoClose":true
        }
        this.toast.info(objj);
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  reload(){
    if(!this.startDateRange || !this.endDateRange){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Date fields are undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(this.isStartDateGreaterThanEndDate(this.startDateRange,this.endDateRange)){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Date: Start date is greater than end date, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    let IsDateRangeValid = this.dateRangeValidator(this.startDateRange,this.endDateRange);
    if(IsDateRangeValid){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Date range is restricted between 30 days,Please select date range within 30 days!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }

    if(!this.selDeptUsr || !this.selDeptUsr.length){
      let objj={
        "Type":2,
        "Title":'Warning',
        "Message":'Invalid Request: Resource undefined, Please check your input!',
        "autoClose":false
      }
      this.toast.warning(objj);
      this.loadingVisible = false;
      return;
    }
    this.getProductionReport();
  }

  //*General Events*//
  expandedRowKey:any;
  usrProdData:any=[];
  onRowExpanding(e:any){
    if(this.expandedRowKey){
      e.component.collapseAll(-1);
    }
    this.expandedRowKey = e.key;

    let object={
      "user_id":this.expandedRowKey.user_id,
      "req_date":this.convert(this.expandedRowKey.task_date)
    }
    this.api.getUserProdDetails(object).subscribe({
      next:(response)=>{
        this.usrProdData = response;
        e.component.refresh()
      },error:(err)=>{
        this.errorToast(err);
      }
    })
  }

  getFileName(response: HttpResponse<Blob>) {
    let filename: string;
    try {
      const contentDisposition: string = response.headers.get('content-disposition')!;
      filename = contentDisposition.split('filename=')[1].split(';')[0];
    }
    catch (e) {
      filename = 'Production.xlsx'
    }
    return filename
  }

  isStartDateGreaterThanEndDate = (startDateStr: string, endDateStr: string): boolean => {
    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);
    return startDate > endDate;
  };

  dateRangeValidator(start:any,end:any){
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (!isNaN(startDate.getTime()) && !isNaN(endDate.getTime())) {
      const timeDiff = endDate.getTime() - startDate.getTime();
      const daysDiff = timeDiff / (1000 * 3600 * 24);
      
      if (daysDiff > 30) {
        return true//{ 'dateRangeExceeded': true };
      }
    }
    return false
  }

  errorToast(err:any){
    if(err.status!=500){
      var errData:any;
      for (let key in err.error) {
        errData = key +' : '+err.error[key]
      }
      let objj={
        "Type":2,
        "Title":"Warning",
        "Message":errData,
        "autoClose":false
      }
      this.toast.warning(objj)
      return
    }else{
      let objj={
        "Type":3,
        "Title":"Error",
        "Message":"Failed to process your request...",
        "autoClose":false
      }
      this.toast.error(objj)
      return
    }
  }

  convert(dateObj:any) { //date convertion
    var date = new Date(dateObj),
    mnth = ("0" + (date.getMonth() + 1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  searchDept(event:any,ngDept:any){
    ngDept.filter(event.target.value)
  }

  searchDeptUser(event:any,ngDeptUsr:any){
    ngDeptUsr.filter(event.target.value)
  }

  //Pagination Implementation
  // loadPageData(pageInfo:any){
  //   this.inflowList = [];
  //   const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
  //   this.InflowTodo = new CustomStore ({
  //     load: (loadOptions:any) => {
  //       this.loadingVisible=true;
  //       let params: HttpParams = new HttpParams();
  //       [
  //         'filter',
  //         'group',
  //         'groupSummary',
  //         'parentIds',
  //         'requireGroupCount',
  //         'requireTotalCount',
  //         'searchExpr',
  //         'searchOperation',
  //         'searchValue',
  //         'select',
  //         'sort',
  //         'skip',
  //         'take',
  //         'totalSummary',
  //         'userData'
  //       ].forEach(function(i) {
  //         if(i in loadOptions && isNotEmpty(loadOptions[i])) {
  //           params = params.set(i, JSON.stringify(loadOptions[i]));
  //         }else{
  //         }
  //       });
  //       return this.api.getTodosbyId(pageInfo,params)
  //         .toPromise()
  //           .then((response:any) => {
  //             this.loadingVisible=false;
  //             this.inflowList = response.data;
  //               return {
  //                 data: response.data,
  //                 totalCount: response.totalCount,
  //                 summary: response.summary,
  //                 groupCount: response.groupCount
  //               };
  //           })
  //           .catch(() => { this.loadingVisible=false; throw 'Data loading error' });
  //     },
  //     update: (values:any) => {
  //       return this.inflowList;
  //     }
  //   });
  // }

  loadPageFilterData(pageInfo:any){
    // this.inflowList = []
    const isNotEmpty = (value:any) => value !== undefined && value !== null && value !== '';
    this.productionInfo = new CustomStore ({
      load: (loadOptions:any) => {
        this.loadingVisible=true;
        let params: HttpParams = new HttpParams();
        [
          'filter',
          'group', 
          'groupSummary',
          'parentIds',
          'requireGroupCount',
          'requireTotalCount',
          'searchExpr',
          'searchOperation',
          'searchValue',
          'select',
          'sort',
          'skip',
          'take',
          'totalSummary', 
          'userData'
        ].forEach(function(i) {
          if(i in loadOptions && isNotEmpty(loadOptions[i])) {
            params = params.set(i, JSON.stringify(loadOptions[i]));
          }else{
          }
        });
        return this.api.getAdminProdReport(pageInfo,params)
          .toPromise()
            .then((response:any) => {
              this.loadingVisible=false;
              // this.inflowList = response.data;
              let data = response.data;
                data.forEach((response:any, index:number) => {
                  response.order_id = index + 1;
                });
                return {
                  data: response.data,
                  totalCount: response.totalCount,
                  summary: response.summary,
                  groupCount: response.groupCount
                };
            })
            .catch(() => { this.loadingVisible=false; throw 'Data loading error' });
      },
      update: (values:any) => {
        return  values //this.inflowList;
      },
    });
  }
}
