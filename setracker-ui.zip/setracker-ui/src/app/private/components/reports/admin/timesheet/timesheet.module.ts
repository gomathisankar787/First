import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { TimesheetRoutingModule } from './timesheet-routing.module';
import { TimesheetComponent } from './timesheet.component';
import { DxDataGridModule, DxLoadPanelModule } from 'devextreme-angular';
import { ToastModule } from 'src/app/shared/components/toast/toast.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { CrTaskComponent } from './cr-task/cr-task.component';


@NgModule({
  declarations: [
    TimesheetComponent,
    CrTaskComponent
  ],
  imports: [
    CommonModule,
    TimesheetRoutingModule,
    DxDataGridModule,
    DxLoadPanelModule,
    ToastModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule
  ],
  providers:[DatePipe]
})
export class TimesheetModule { }
