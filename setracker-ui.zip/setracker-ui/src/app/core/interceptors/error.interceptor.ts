import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';

import { catchError } from 'rxjs/operators'
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

  constructor(private loginService:LoginService,private router:Router) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(request).pipe(catchError(err => {
      if([401].indexOf(err.status) !== -1){
        this.loginService.logout();
        this.router.navigate(['/login']);
      }
      // else if([404].indexOf(err.status) !== -1){
      //   this.loginService.logout();
      //   this.router.navigate(['/home']);
      // }
      const error = err.error || err.error.message || err.statusText ;
      return throwError(err);
    }))
  }
}
