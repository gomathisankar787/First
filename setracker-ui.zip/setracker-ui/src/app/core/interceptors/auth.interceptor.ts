import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { TokenService } from '../services/token.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private auth:AuthService,private tknService:TokenService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    // return next.handle(request);
    const isApiUrl = request.url.startsWith(environment.api_server);
    if(this.auth.isLoggedIn() && isApiUrl){
      var usrToken = this.tknService.getToken();
      request = request.clone({
        setHeaders: {
          Authorization: `Token ${usrToken}`
        }
    });
    }
    return next.handle(request);
  }
}
