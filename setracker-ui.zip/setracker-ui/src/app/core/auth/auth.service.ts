import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { LoginService } from '../services/login.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  isLogin:boolean = false;
  roleInfo:string = '';
  constructor(private login:LoginService) { }
  isLoggedIn(){
    const loggedIn = localStorage.getItem('state');
    if (loggedIn == 'true'){
      this.isLogin = true;
    }else{
      this.isLogin = false;
    }
    return this.isLogin;
  }
  getRoles(){
    // const role = localStorage.getItem('info') != null ? localStorage.getItem('info') : '';
    const role = this.login.getUserInfo();
    if(role == '') return '';
    this.roleInfo = role!;
    const usr_info = JSON.parse(window.atob(role!)); //updated
    var usr_role = usr_info.role != null ? usr_info.role : ''
    var roles = usr_role;// usr_role.split(',');//Split the roles with , and make array
    return roles;
  }
}
