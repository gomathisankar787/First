import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
// import { ActivatedRouteSnapshot,Router, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { lastValueFrom } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { LoginService } from '../services/login.service';

export const RoleGuard:CanActivateFn = async (route,state) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const login = inject(LoginService);

  if(auth.isLoggedIn()){
    var roles = auth.getRoles();
    if(roles == ''){
      var rlData=null;
      try{
        rlData = await lastValueFrom(login.getServerInfo());
      }catch{
        rlData = null;
      }
      // let rlData = await lastValueFrom(login.getServerInfo())
      if(rlData != null){
        login.setUserInfo(rlData);
        roles = auth.getRoles();
      }
    }
    if(route.data['roles'] && route.data['roles'].indexOf(roles) === -1){
      router.navigate(['/login']);
      login.logout();
      return false;
    }
    return true;
  }else{
    router.navigate(['/login']);
    login.logout();
    return false
  }
}
// @Injectable({
//   providedIn: 'root'
// })
// export class RoleGuard implements CanActivate {
//   constructor(private auth: AuthService, private router: Router){
//   }
//   canActivate(
//     route: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
//       if(this.auth.isLoggedIn()){
//         const roles = this.auth.getRoles();
//         if(route.data['roles'] && route.data['roles'].indexOf(roles) === -1){
//           this.router.navigate(['/login']);
//           return false;
//         }
//       }
//     return true;
//   }

// }
