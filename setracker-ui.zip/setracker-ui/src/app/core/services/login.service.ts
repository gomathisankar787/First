import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { UserModel } from 'src/app/shared/models/user.model';
import { TokenService } from './token.service'
import { ApiSharedService } from 'src/app/shared/http/api-shared.service';
// import { UserService } from './user.service'

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  isLogin:boolean = false;
  roleInfo:string = '';

  constructor(private tkns: TokenService,private api:ApiSharedService) { }

  updateUser(value:any){
    var hashed = window.btoa(value);
    this.roleInfo = hashed;
    // localStorage.setItem('info',this.roleInfo);
  }

  login(value:any,usr_info:UserModel){
    this.isLogin = true;
    this.roleInfo = value.info;
    var sessval = Math.random().toString();
    localStorage.setItem('state','true');
    // localStorage.setItem('info',this.roleInfo);
    localStorage.setItem('session',sessval)
    sessionStorage.setItem('session',sessval);
    this.tkns.setToken(value.token);
    return of({ 'sucess': this.isLogin,'info': this.roleInfo,'user':usr_info});
  }

  logout(){
    this.isLogin = false;
    this.roleInfo = '';
    localStorage.clear()
    sessionStorage.clear();
    this.tkns.clearToken();
    return of({ 'sucess': this.isLogin,'info': '','user':''});
  }

  getUserInfo(){
    return this.roleInfo != null ? this.roleInfo : '';
  }

  setUserInfo(info:any){
    this.isLogin = true;
    this.roleInfo = info;
    return 'sucess' //of({ 'sucess': this.isLogin,'info': this.roleInfo});
  }

  getServerInfo(){
    const token = this.tkns.getToken();
    if(token==null){
      return of(null)
    }else{
      return this.api.getUserInfo({"token": token})
    }
  }
}
