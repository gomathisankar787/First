import { Injectable } from '@angular/core';
import { UserModel } from 'src/app/shared/models/user.model'
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private login:LoginService) { }

  getUser(){
    // const user = localStorage.getItem('info') != null ? localStorage.getItem('info') : '';
    const user = this.login.getUserInfo();
    const usr_info = JSON.parse(window.atob(user!));
    var usr_model:UserModel = <UserModel>usr_info;
    usr_model.avatar = 1;
    if (usr_info.user_info){
      let ava_id = usr_info.user_info;
      if (ava_id > 0){
        usr_model.avatar = ava_id;
      }
    }    
    return usr_model;
  }
}
