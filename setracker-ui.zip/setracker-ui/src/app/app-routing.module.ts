import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PreloadAllModules } from '@angular/router';

import { AuthGuard } from './core/guards/auth.guard';

const routes: Routes = [
  { path: 'login', loadChildren: () => import('./public/components/login/login/login.module').then(m => m.LoginModule) },
  { path: '', redirectTo:'/login',pathMatch:'full'},
  { path: 'home', canActivate:[AuthGuard], loadChildren: () => import('./private/private.module').then(m => m.PrivateModule) },
  { path: 'pagenotfound', loadChildren: () => import('./shared/components/error/pagenotfound/pagenotfound.module').then(m => m.PagenotfoundModule) },
  { path: '**',redirectTo:'/pagenotfound',pathMatch:'full'},
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes,
    {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
