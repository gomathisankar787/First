from rest_framework import serializers,validators
from openpyxl import load_workbook
from django.db import transaction
import os,pandas as pd
from django.core.files.storage import default_storage
from .models import *


class OhprofitSerializer(serializers.Serializer):
    input_excel = serializers.FileField()
    sheet_name = serializers.CharField()
    effective_from = serializers.DateField(required=False)
    source = serializers.CharField(required=False)
    base = serializers.CharField(required=False)
    remarks = serializers.CharField(required=False)

    def clean_value(self, value):
        if value is None:
            return 0.0
        if isinstance(value, (int, float)):
            return float(value)
        val = str(value).strip()
        if val.endswith("%"):
            return float(val.rstrip("%")) / 100   # convert % to decimal
        return float(val)
    
    def clean_base_value(self,value,int_flag):
        if value is None and int_flag is True:
            return 0
        if value is None and int_flag is False:
            return None
        if isinstance(value,str):
            value = value.replace("\xa0","").strip()
            if value == "" and int_flag is False:
                return None
            if value == "" and int_flag is True:
                return 0
            try:
                return float(value)
            except:
                return value
        if isinstance(value,(int,float)):
            # print('val',value)
            if value == None and int_flag is True:
                return 0
            return value
        return value


    def create(self, validated_data):
        try:
            excel_file = validated_data.pop("input_excel")
            sheet_name = validated_data.pop("sheet_name")

            file_name = default_storage.save(excel_file.name, excel_file)
            file_path = default_storage.path(file_name)

            if file_path.lower().endswith(".csv"):
                df = pd.read_csv(file_path)
                xlsx_path = file_path.rsplit(".", 1)[0] + ".xlsx"
                df.to_excel(xlsx_path, index=False)
                file_path = xlsx_path

            book = load_workbook(file_path, data_only=True)
            default_storage.delete(file_name)
            # print('sheetname',book.sheetnames)
            if sheet_name not in book.sheetnames:
                raise serializers.ValidationError(
                    {"sheet_name": f"Sheet '{sheet_name}' not found"}
                )

            sheet = book[sheet_name]
            rows = list(sheet.rows)

            if not rows or len(rows) < 2:
                raise serializers.ValidationError("Excel sheet is empty")
            
            final_data = []
            if sheet_name == "OH,Profit & Other Base":
                
                for row in rows[1:]:
                    if all(cell.value is None for cell in row):
                        break

                    args = [cell.value for cell in row]

                    temp = {
                        "process_type": args[0],
                        "icc_rm": self.clean_value(args[1]),
                        "icc_conv": self.clean_value(args[2]),
                        "icc_bof": self.clean_value(args[3]),
                        "rej_rm": self.clean_value(args[4]),
                        "rej_conv": self.clean_value(args[5]),
                        "rej_bof": self.clean_value(args[6]),
                        "inspection_rm": self.clean_value(args[7]),
                        "inspection_conv": self.clean_value(args[8]),
                        "inspection_bof": self.clean_value(args[9]),
                        "tmc_rm": self.clean_value(args[10]),
                        "tmc_conv": self.clean_value(args[11]),
                        "tmc_bof": self.clean_value(args[12]),
                        "design_cost_rm": self.clean_value(args[13]),
                        "design_cost_conv": self.clean_value(args[14]),
                        "design_cost_bof": self.clean_value(args[15]),
                        "oh_rm": self.clean_value(args[16]),
                        "oh_conv": self.clean_value(args[17]),
                        "oh_bof": self.clean_value(args[18]),
                        "profit_rm": self.clean_value(args[19]),
                        "profit_conv": self.clean_value(args[20]),
                        "profit_bof": self.clean_value(args[21]),
                        "warranty_cost": self.clean_value(args[22]),
                        "inbound_logistics": self.clean_value(args[23]),
                        "effective_from": validated_data["effective_from"],
                        "source": validated_data["source"],
                        "base": validated_data["base"],
                        "remarks": validated_data["remarks"],
                        "updated_by": os.environ.get("USERNAME", "").lower(),
                    }

                    final_data.append(temp)

                print("Parsed data:", final_data)

                with transaction.atomic():
                    for item in final_data:
                        OH_ProfitData.objects.create(**item)

            if sheet_name == "RM Base":
                for row in rows[2:]:
                    if all(cell.value is None for cell in row):
                        break

                    args = [cell.value for cell in row]

                    temp ={
                        "category": self.clean_base_value(args[2],False),
                        "material_grade": self.clean_base_value(args[3],False),
                        "rm_rate": self.clean_base_value(args[4],True),
                        "scrap_rate": self.clean_base_value(args[10],True),
                        "uom": self.clean_base_value(args[5],False),
                        "updated_on":self.clean_base_value(args[8],False),
                        "effective_from":self.clean_base_value(args[7],False),
                        "source": self.clean_base_value(args[6],False),
                        "remarks":self.clean_base_value(args[9],False),
                        "base":validated_data["base"],
                        "updated_by": os.environ.get("USERNAME", "").lower()
                    }
                    final_data.append(temp)
                print("Parsed data:", final_data)

                with transaction.atomic():
                    for item in final_data:
                        RMbase.objects.create(**item)

            if sheet_name == 'Process Base':
                for row in rows[2:]:
                    if all(cell.value is None for cell in row):
                        break

                    args = [cell.value for cell in row]

                    temp ={
                        "process_category": self.clean_base_value(args[2],False),
                        "process_description": self.clean_base_value(args[3],False),
                        "norms": self.clean_base_value(args[5],True),
                        "uom": self.clean_base_value(args[6],False),
                        "updated_on":self.clean_base_value(args[9],False),
                        "effective_from":self.clean_base_value(args[8],False),
                        "source": self.clean_base_value(args[7],False),
                        "remarks":validated_data["remarks"],
                        "base":validated_data["base"],
                        "updated_by": os.environ.get("USERNAME", "").lower()
                    }
                    final_data.append(temp)
                # print("Parsed data:", final_data)

                with transaction.atomic():
                    for item in final_data:
                        Processbase.objects.create(**item)

            return {
                "total_rows": len(final_data),
                "parsed_data": final_data,
            }

        except Exception as e:
            raise serializers.ValidationError(str(e))

class SmMaterialCalculationSerializer(serializers.Serializer):
    material_grade = serializers.CharField(required=False)
    length = serializers.FloatField(required=False)
    width = serializers.FloatField(required=False)
    thickness = serializers.FloatField(required=False)
    cutting_process = serializers.CharField(required=False)
    sheet_length = serializers.FloatField(required=False)
    sheet_width = serializers.FloatField(required=False)
    no_of_blanks = serializers.IntegerField(required=False)
    finish_weight = serializers.FloatField(required=False)

class CacheUpdateWeldingValuesSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    process_description = serializers.CharField(required=False)
    cutting_len_formula = serializers.CharField(required=False)
    no_of_operations = serializers.CharField(required=False)
    parts_per_cycle = serializers.CharField(required=False)
    remarks = serializers.CharField(required=False)

class CacheUpdateAssemblyValuesSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    process_description = serializers.CharField(required=False)
    cycle_time = serializers.CharField(required=False)
    MHR = serializers.CharField(required=False)
    no_of_labour = serializers.CharField(required=False)
    labour_type = serializers.CharField(required=False)
    remarks = serializers.CharField(required=False)

class FetchAssemblyDetailsSerializer(serializers.Serializer):
    bom_id = serializers.IntegerField()

class WeldingProcessSerializer(serializers.ModelSerializer):
    class Meta:
        model = SMProcess
        fields = "__all__"

class AssemblyCostSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(required=False,allow_null=True)
    class Meta:
        model = AssemblyCost
        fields = "__all__"
        extra_kwargs = {
            'bom': {'required': False,'allow_null':True},
            'process_description': {'required': False,'allow_null':True},
            'cycle_time': {'required': False,'allow_null':True},
            'MHR': {'required': False,'allow_null':True},
            'machine_cost': {'required': False,'allow_null':True},
            'no_of_labour': {'required': False,'allow_null':True},
            'labour_type': {'required': False,'allow_null':True},
            'labour_rates': {'required': False,'allow_null':True},
            'labour_cost': {'required': False,'allow_null':True},
            'assembly_cost_per_unit': {'required': False,'allow_null':True},
            'remarks': {'required': False,'allow_null':True},
        }

class SaveWeldingRowSerializer(serializers.Serializer):
    bom_id=serializers.IntegerField(required=False, allow_null=True)
    id = serializers.IntegerField(required=False, allow_null=True)
    unique_csc_id = serializers.CharField(required=False, allow_null=True,allow_blank=True)
    part_no = serializers.CharField(required=False, allow_null=True,allow_blank=True)
    process_place = serializers.CharField(required=False, allow_null=True,allow_blank=True)
    cutting_len_formula = serializers.CharField(required=False,allow_null=True,allow_blank=True)
    process_description = serializers.CharField(required=False, allow_null=True,allow_blank=True)
    no_of_operations = serializers.FloatField(required=False, allow_null=True)
    parts_per_cycle = serializers.FloatField(required=False, allow_null=True)
    norms = serializers.FloatField(required=False, allow_null=True)
    process_cost_unit = serializers.FloatField(required=False, allow_null=True)
    remarks = serializers.CharField(required=False, allow_blank=True)

class DeleteBomRowsSerializer(serializers.Serializer):
    bom_id = serializers.IntegerField()

class DeleteRowsSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    type = serializers.CharField()

class BomSummaryUpdateSerializer(serializers.Serializer):
    bom_id = serializers.CharField()
    bom_type = serializers.CharField()
