from datetime import timezone,datetime
from django.db import models
    # unique_csc_id = models.CharField(max_length=100, blank=True, editable=False)  # Add field for unique CSC ID

# Create your models here.
def get_existing_versions(part_num, rev):
    existing_versions = CRCSCTBL.objects.filter(
        part_num=part_num,
        rev=rev
    ).values_list('unique_csc_id', flat=True)

    versions = []
    for id in existing_versions:
        parts = id.split('-')
        if len(parts) == 5 and parts[-1].isdigit():
            versions.append(int(parts[-1]))

    return versions

def generate_unique_csc_id(part_num, rev):
    """Generate a unique CSC ID based on the highest existing version."""
    existing_versions = get_existing_versions(part_num, rev)
    print('mxver',max(existing_versions))
    # Determine the next version
    if existing_versions:
        next_version = max(existing_versions) + 1
    else:
        next_version = 1
    
    unique_csc_id = f"KMC-CSC-{part_num}-{rev}-{next_version}"
    return unique_csc_id

class PARTTYPETBL(models.Model):
    parttype_name = models.CharField(max_length=255, unique=True)

class PROJECTLISTTBL(models.Model):
    projects_name = models.CharField(max_length=255, unique=True)

class CRCSCTBL(models.Model):
    part_num = models.CharField(max_length=100)
    rev = models.CharField(max_length=10)
    desc = models.CharField(max_length=200)
    part_typ = models.ForeignKey(PARTTYPETBL, on_delete=models.CASCADE, null=True, blank=True)  # Store the value directly
    projects = models.ForeignKey(PROJECTLISTTBL, on_delete=models.CASCADE, null=True, blank=True)  # Store the value directly
    rm_base = models.CharField(max_length=100)
    process_base = models.CharField(max_length=100)
    oh_profit_base = models.CharField(max_length=100)
    remarks = models.CharField(max_length=100)
    updated_on = models.DateTimeField(auto_now_add=True)
    updated_by = models.CharField(max_length=100)
    unique_csc_id = models.CharField(max_length=100, blank=True, editable=False)
    csc_status = models.CharField(max_length=100, null=True, blank=True)
    total_cost = models.FloatField(null=True, blank=True)
    rejected_reason = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.part_num

    def save(self, *args, **kwargs):
        if not self.unique_csc_id:  # Only generate a new ID if it doesn't already exist
            self.unique_csc_id = generate_unique_csc_id(self.part_num, self.rev)
        super().save(*args, **kwargs)


def get_existing_versions(part_no, revision):
    existing_versions = BOMSheet.objects.filter(
        part_no=part_no,
        revision=revision
    ).values_list('unique_csc_id', flat=True)

    versions = []
    for id in existing_versions:
        parts = id.split('-')
        if len(parts) == 5 and parts[-1].isdigit():
            versions.append(int(parts[-1]))

    return versions

def generate_unique_csc_id(part_no, revision):
    """Generate a unique CSC ID based on the highest existing version."""
    existing_versions = get_existing_versions(part_no, revision)
    # Determine the next version
    if existing_versions:
        next_version = max(existing_versions) + 1
    else:
        next_version = 1
    current_month_year = datetime.now().strftime("%b-%y")

    unique_csc_id = f"{part_no}-{revision}-{next_version}-{current_month_year}"
    return unique_csc_id

class BOMSheet(models.Model):
    part_no = models.CharField(max_length=50)
    level = models.FloatField()
    revision = models.CharField(max_length=20)
    part_description = models.TextField()
    qty = models.FloatField()
    process_type = models.CharField(max_length=50)
    scope = models.CharField(max_length=50)
    method = models.CharField(max_length=50)
    is_nesting_needed = models.CharField(max_length=10)
    unique_csc_id = models.CharField(max_length=100)

    # Persistent order field
    order_index = models.PositiveIntegerField(default=0, db_index=True)

    class Meta:
        ordering = ['order_index', 'id']


    # def save(self, *args, **kwargs):
    #     if not self.unique_csc_id:  # Only generate a new ID if it doesn't already exist
    #         self.unique_csc_id = generate_unique_csc_id(self.part_no, self.revision)
    #     super().save(*args, **kwargs)


class OH_ProfitData(models.Model):
    process_type = models.CharField(max_length=100)
    icc_rm = models.FloatField()
    icc_conv = models.FloatField()
    icc_bof = models.FloatField()
    rej_rm = models.FloatField()
    rej_conv = models.FloatField()
    rej_bof = models.FloatField()
    inspection_rm = models.FloatField()
    inspection_conv = models.FloatField()
    inspection_bof = models.FloatField()
    tmc_rm = models.FloatField()
    tmc_conv = models.FloatField()
    tmc_bof = models.FloatField()
    design_cost_rm = models.FloatField()
    design_cost_conv = models.FloatField()
    design_cost_bof = models.FloatField()
    oh_rm = models.FloatField()
    oh_conv = models.FloatField()
    oh_bof = models.FloatField()
    profit_rm = models.FloatField()
    profit_conv = models.FloatField()
    profit_bof = models.FloatField()
    warranty_cost = models.FloatField()
    inbound_logistics = models.FloatField()
    updated_on = models.DateField(auto_now=True)
    effective_from = models.DateField()
    source = models.CharField(max_length=100,default='default_value')
    base = models.CharField(max_length=100, default='default_value')
    remarks = models.TextField(null=True, blank=True)
    updated_by = models.CharField(max_length=100)

    def __str__(self):
        return self.process_type

class OH_ProfitData_child(models.Model):
    process_type = models.CharField(max_length=100,null=True,blank=True)
    icc_rm = models.FloatField(null=True,blank=True)
    icc_conv = models.FloatField(null=True,blank=True)
    icc_bof = models.FloatField(null=True,blank=True)
    rej_rm = models.FloatField(null=True,blank=True)
    rej_conv = models.FloatField(null=True,blank=True)
    rej_bof = models.FloatField(null=True,blank=True)
    inspection_rm = models.FloatField(null=True,blank=True)
    inspection_conv = models.FloatField(null=True,blank=True)
    inspection_bof = models.FloatField(null=True,blank=True)
    tmc_rm = models.FloatField(null=True,blank=True)
    tmc_conv = models.FloatField(null=True,blank=True)
    tmc_bof = models.FloatField(null=True,blank=True)
    design_cost_rm = models.FloatField(null=True,blank=True)
    design_cost_conv = models.FloatField(null=True,blank=True)
    design_cost_bof = models.FloatField(null=True,blank=True)
    oh_rm = models.FloatField(null=True,blank=True)
    oh_conv = models.FloatField(null=True,blank=True)
    oh_bof = models.FloatField(null=True,blank=True)
    profit_rm = models.FloatField(null=True,blank=True)
    profit_conv = models.FloatField(null=True,blank=True)
    profit_bof = models.FloatField(null=True,blank=True)
    warranty_cost = models.FloatField(null=True,blank=True)
    inbound_logistics = models.FloatField(null=True,blank=True)
    updated_on = models.DateField(auto_now=True,null=True,blank=True)
    effective_from = models.DateField(null=True,blank=True)
    source = models.CharField(max_length=100,default='default_value',null=True,blank=True)
    base = models.CharField(max_length=100, default='default_value',null=True,blank=True)
    remarks = models.TextField(null=True, blank=True)
    updated_by = models.CharField(max_length=100,null=True,blank=True)
    bom = models.ForeignKey(BOMSheet, on_delete=models.CASCADE, null=True, blank= True)
    unique_csc_id = models.CharField(null=True,blank=True)

    def __str__(self):
        return self.process_type



class Processbase(models.Model):
    process_category = models.CharField(max_length=100,null=True,blank=True)
    process_description = models.CharField(max_length=255,null=True,blank=True)
    norms = models.FloatField()
    uom = models.CharField(max_length=50,null=True,blank=True)
    updated_on = models.DateField(auto_now_add=True)
    effective_from = models.DateField(null=True,blank=True)
    source = models.CharField(max_length=100,null=True,blank=True)
    base = models.CharField(max_length=100, default='default_value',null=True,blank=True)
    remarks = models.TextField(null=True, blank=True)
    updated_by = models.CharField(max_length=100)

    def __str__(self):
        return self.process_category


class RMbase(models.Model):
    category = models.CharField(max_length=100)
    material_grade = models.CharField(max_length=200)
    rm_rate  = models.FloatField()
    scrap_rate = models.FloatField()
    uom = models.CharField(max_length=100,null=True,blank=True)
    updated_on = models.DateField(auto_now_add=True)
    effective_from = models.DateField(null=True,blank=True)
    source = models.CharField(null=True,blank=True)
    base=models.CharField(max_length=100, default='default_value')
    UTS = models.IntegerField(null=True, blank=True)
    Density = models.FloatField(null=True, blank=True)
    scrap_recovery = models.FloatField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    updated_by = models.CharField(max_length=100)

    def save(self, *args, **kwargs):
        if self.scrap_recovery is not None:
            # Convert percentage to fraction
            self.scrap_recovery = self.scrap_recovery / 100
        super().save(*args, **kwargs)

    def __str__(self):
        return self.category

class SMMaterial(models.Model):
    part_no = models.CharField(max_length=100)
    part_description = models.CharField(max_length=255,null=True,blank=True)
    estimation_mthd = models.CharField(max_length=100,null=True,blank=True)
    material_grade = models.CharField(max_length=100,null=True,blank=True)
    rm_price_per_kg = models.FloatField(null=True,blank=True)
    length = models.FloatField(null=True,blank=True)
    length_formula = models.CharField(max_length=250,null=True,blank=True)
    width = models.FloatField(null=True,blank=True)
    width_formula = models.CharField(max_length=250,null=True,blank=True)
    thickness = models.FloatField(null=True,blank=True)
    sheet_length = models.FloatField(null=True,blank=True)
    sheet_width = models.FloatField(null=True,blank=True)
    cutting_process = models.CharField(max_length=100,null=True,blank=True)
    sheet_weight = models.FloatField(null=True,blank=True)
    no_of_blanks = models.IntegerField(null=True,blank=True)
    blank_weight = models.FloatField(null=True,blank=True)
    input_weight = models.FloatField(null=True,blank=True)
    finish_weight = models.FloatField(null=True,blank=True)
    finish_weight_formula = models.CharField(max_length=250,null=True,blank=True)
    yield_value = models.FloatField(null=True,blank=True)
    surface_area_part = models.FloatField(null=True,blank=True)
    scrap_weight = models.FloatField(null=True,blank=True)
    scrap_price = models.FloatField(null=True,blank=True)
    recovery_perc = models.FloatField(null=True,blank=True)
    price_per_unit = models.FloatField(null=True,blank=True)
    direct_rm_cost = models.FloatField(null=True,blank=True)
    allowance_cost = models.FloatField(null=True,blank=True)
    remarks = models.TextField(null=True,blank=True)
    updated_on = models.DateField(null=True,blank=True)
    updated_by = models.CharField(max_length=100,null=True,blank=True)
    unique_csc_id = models.CharField(max_length=100,null=True,blank=True)
    no_of_operations = models.IntegerField(null=True,blank=True)
    def save(self, *args, **kwargs):
        if not self.unique_csc_id:  # Only generate a new ID if it doesn't already exist
            self.unique_csc_id = self.generate_unique_csc_id()
        super().save(*args, **kwargs)

    def generate_unique_csc_id(self):
        """Generate a unique CSC ID based on the highest existing version."""
        existing_versions = BOMSheet.objects.filter(
            part_no=self.part_no,
            revision=self.revision
        ).values_list('unique_csc_id', flat=True)

        versions = []
        for id in existing_versions:
            parts = id.split('-')
            if len(parts) == 5:
                versions.append(int(parts[-1]))

        # Determine the next version
        next_version = max(versions, default=0) + 1
        current_month_year = datetime.now().strftime("%b-%y")

        unique_csc_id = f"{self.part_no}-{self.revision}-{next_version}-{current_month_year}"
        return unique_csc_id

class SMProcess(models.Model):
    part_no = models.CharField(max_length=100)
    process_type = models.CharField()
    part_description = models.CharField(null=True,blank=True)
    process_description = models.CharField()
    thickness  = models.CharField(default=0,null=True,blank=True)
    mechanical_hydraulic = models.CharField(null=True,blank=True)
    cutting_formula = models.CharField(null=True,blank=True)
    cutting_forminglength = models.FloatField(null=True,blank=True)
    press_forcecutting = models.FloatField(null=True,blank=True)
    press_forceforming = models.FloatField(null=True,blank=True)
    machinetype = models.CharField(null=True,blank=True)
    no_of_operations = models.FloatField(null=True,blank=True)
    parts_per_cycle = models.BigIntegerField(null=True,blank=True)
    norms = models.FloatField(null=True,blank=True)
    process_cost_unit = models.FloatField(null=True,blank=True)
    uts = models.FloatField(null=True,blank=True)
    remarks = models.CharField(null=True,blank=True)
    unique_csc_id = models.CharField(default=0)

class AssemblyCost(models.Model):
    bom = models.ForeignKey(BOMSheet, on_delete=models.CASCADE, null=True, blank=True)
    process_description = models.CharField(max_length=255,null=True,blank=True)
    cycle_time = models.FloatField(null=True,blank=True)
    MHR = models.FloatField(null=True,blank=True)
    machine_cost = models.FloatField(null=True,blank=True)
    no_of_labour = models.FloatField(null=True,blank=True)
    labour_type = models.CharField(max_length=255,null=True,blank=True)
    labour_rates = models.FloatField(null=True,blank=True)
    labour_cost = models.FloatField(null=True,blank=True)
    assembly_cost_per_unit = models.FloatField(null=True,blank=True)
    remarks = models.CharField(null=True,blank=True)

class BomSummary(models.Model):
    bom = models.ForeignKey(BOMSheet, on_delete=models.CASCADE, null=True, blank=True)
    direct_rm = models.FloatField(null=True,blank=True)
    allowance = models.FloatField(null=True,blank=True)
    process_cost = models.FloatField(null=True,blank=True)
    surface_finish_cost = models.FloatField(null=True,blank=True)
    oh_and_others = models.FloatField(null=True,blank=True)
    profit = models.FloatField(null=True,blank=True)
    cpu = models.FloatField(null=True,blank=True)
    cpa =models.FloatField(null=True,blank=True)
    weight = models.FloatField(null=True,blank=True)
    total_weight = models.FloatField(null=True,blank=True)
    rate_kg = models.FloatField(null=True,blank=True)
